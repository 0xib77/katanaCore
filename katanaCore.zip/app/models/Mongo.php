<?php

use MongoDB\Client;

class Mongo extends Model
{
    private
        $conf,
        $jcp_users,
        $jcp_documents,
        $users,
        $login_history,
        $api_calls,
        $discord_attempts,
        $user_activities,

        $socket_connections,
        $dead_links,
        $discord_hooks,

        $clients,
        $resources,
        $interaction_updates,

        $http_origin,
        $app_origin,

        $client;

    public function __construct()
    {
        parent::__construct();
        $this->conf = config_item('MongoDB');
        $this->client = new Client("mongodb://{$this->conf['host']}:{$this->conf['port']}");

        $this->socket_connections = $this->client
            ->selectDatabase('bdo_dash')
            ->selectCollection('socket_connections');

        $this->dead_links = $this->client
            ->selectDatabase('bdo_dash')
            ->selectCollection('dead_links');

        $this->discord_hooks = $this->client
            ->selectDatabase('bdo_dash')
            ->selectCollection('discord_hooks');

        $this->jcp_users = $this->client
            ->selectDatabase('jcp_users')
            ->selectCollection('users');

        $this->jcp_documents = $this->client
            ->selectDatabase('jcp_users')
            ->selectCollection('jcp_documents');

        $this->users = $this->client
            ->selectDatabase('xjutsu')
            ->selectCollection('users');

        $this->login_history = $this->client
            ->selectDatabase('xjutsu')
            ->selectCollection('login_history');

        $this->api_calls = $this->client
            ->selectDatabase('xjutsu')
            ->selectCollection('api_calls');

        $this->user_activities = $this->client
            ->selectDatabase('xjutsu')
            ->selectCollection('user_activities');

        $this->discord_attempts = $this->client
            ->selectDatabase('xjutsu')
            ->selectCollection('discord_attempts');

        $this->clients = $this->client
            ->selectDatabase('blackOps')
            ->selectCollection('clients');

        $this->resources = $this->client
            ->selectDatabase('blackOps')
            ->selectCollection('resources');

        $this->interaction_updates = $this->client
            ->selectDatabase('bdo_dash')
            ->selectCollection('interaction_updates');

        $env = config_item('ENVIRONMENT');
        $site = config_item('website')[$env];
        $this->app_origin = rtrim($site['base_url'], '/');

        $this->http_origin = $_SERVER['HTTP_ORIGIN'] ?? (Sessions::pull('HTTP_ORIGIN') ?? $this->app_origin);


    }

    public function fetch_hooks() {

        return $this->mongo_out($this->discord_hooks->findOne([
            'user' => Sessions::pull('user')['id'] ?? 2077,
            'origin' => $this->app_origin
        ]));
    }

    public function save_hooks($list) {
        $user = Sessions::pull('user')['id'] ?? 2077;

        $settings = [
            'origin' => $this->app_origin,
            'user' => $user,
            'updated' => date(config_item('time_stamp_format')),
            'list' => $list
        ];
        $save = $this->discord_hooks->updateOne(
            [
                'user' => $user,
                'origin' => $this->app_origin,
            ],
            ['$set' => $settings],
            ['upsert' => true]
        );
        return $save->getUpsertedId() ?? ($save->getModifiedCount() ?? $save->getMatchedCount());
    }

    public function dead_link($link, $status) {
        $settings = [
            'link' => $link,
            'sig' => md5($link),
            'status' => $status
        ];
        $log = $this->dead_links->updateOne(
            $settings,
            ['$set' => $settings],
            ['upsert' => true]
        );
    }

    public function fetch_links($origin) {
        $links = $this->mongo_out(($this->socket_connections)->find([
            'origin'=>$origin
        ]));
//        return $links;
        $stored_links = [];
        foreach ($links as $i => $l) {
            if (isset($l['lists']) && is_array($l['lists'])) {
                foreach ($l['lists'] as $k) {
                    if (!in_array($k, $stored_links, true)) {
                        // check if not dead
                        $check = ($this->dead_links)->findOne(['sig'=>md5($k)]);
                        if (!isset($check['link'])) {
                            $stored_links[] = $k;
                        }
                    }
                }
            }
        }
        return $stored_links;
    }

    public function fetch_global_socket_connections() {
        $cursor = $this->socket_connections->find([
            'origin' => $this->app_origin
        ], ['projection' => ['lists' => 1, '_id' => 0]]);
        $links = [];
        foreach ($cursor as $document) {
            if (isset($document['lists'])) {
                foreach ($document['lists'] as $link) {
                    if (!in_array($link, $links, true)) {
                        $check = ($this->dead_links)->findOne(['sig'=>md5($link)]);
                        if (!isset($check['link'])) {
                            $links[] = $link;
                        }
                    }
                }
            }
        }
        return $links;
    }

    public function fetch_validated_logs($origin) {
        $validated_logs = $this->mongo_out(($this->resources)->find([
            'status'=>'validated',
            'origin'=>$origin
        ]));
        foreach ($validated_logs as $i => $log) {
            if (isset($log['key'])) {
                $validated_logs[$i]['client'] = $this->fetch_client_logs($log['key']);
            }
        }
        return $validated_logs;
    }

    public function fetch_client_logs($key) {
        return $this->mongo_out(($this->clients)->findOne(['key'=>$key]));
    }

    public function fetch_interaction_logs($key) {
        return $this->mongo_out(($this->interaction_updates)->findOne(['key'=>$key]));
    }

    public function fetch_input_logs($key) {
        return $this->mongo_out(($this->resources)->findOne(['key'=>$key]));
    }

    public function fetch_socket_connections() {
        $fetch = $this->mongo_out($this->socket_connections->findOne([
            'origin' => $this->http_origin,
            'user' => Sessions::pull('user')['id'] ?? 2077
        ]));

        if (isset($fetch['lists'])) {
            $links = [];
            $deadLinks = [];
            foreach ($fetch['lists'] as $link) {
                $check = ($this->dead_links)->findOne(['sig'=>md5($link)]);
                if (!isset($check['link'])) {
                    $links[] = $link;
                } else {
                    $deadLinks[] = $link;
                }
            }
            $fetch['lists'] = $links;
            $fetch['dead_lists'] = $deadLinks;
        }
        return $fetch;
    }

    public function update_socket_connections($lists) {
        $user = Sessions::pull('user');
        $date = date(config_item('time_stamp_format'));
        $ip = real_ip();

        $user = Sessions::pull('user')['id'] ?? 2077;
        $insert_config = [
            'user' => $user,
            'origin' => $this->http_origin,
            'lists' => $lists,
            'last_updated' => $date,
            'update_history' => []
        ];

        $user_history = [
            'user' => $user,
            'date' => $date,
            'ip' => $ip
        ];

        $settings = $this->socket_connections->findOne(['origin'=>$this->http_origin,'user'=>$user]);
        if (isset($settings['origin'])) {
            // update
            unset($settings['_id']);
            $settings['lists'] = $lists;
            $settings['update_history'][] = $user_history;
            $exec = $this->socket_connections->updateOne(
                [
                    'origin' => $settings['origin'],
                    'user' => $user
                ],
                ['$set' => $settings],
                ['upsert' => true]
            );
            $status = $exec->getMatchedCount();
        } else {
            // insert
            $insert_config['update_history'][] = $user_history;
            $exec = $this->socket_connections->insertOne($insert_config);
            $status = $exec->getInsertedCount();
        }

        if ($status) {
            return [
                'status' => 'success',
                'lists' => $lists
            ];
        }   return [
                'status' => 'fail',
                'info' => "modified count: {$exec->getModifiedCount()}"
        ];
    }

    public function jc_docs($id) {
        return $this->mongo_out($this->jcp_documents->findOne(['id' => $id]));
    }

    public function log_jc_docs($info) {
        $log = $this->jcp_documents->insertOne($info);
        return $log->getInsertedId();
    }

    public function api_logs($info) {
        $log = $this->api_calls->insertOne($info);
        return $log->getInsertedId();
    }

    public function activity_logs($info) {
        $log = $this->user_activities->insertOne($info);
        return $log->getInsertedId();
    }

    public function log_history($username, $type='login') {
        $log = $this->log_event($username, $type);
    }

    private function log_event($username, $event='login') {

        $info = [
            'date' => date('r'),
            'user' => $username,
            'event' => $event,
            'ip_address' => real_ip()
        ];
        switch (strtolower($info['event'])) {
            case 'logout':
            case 'login':
                $log = $this->login_history->insertOne($info);
                return $log->getInsertedId();
                break;
        }
    }

    private function convertBSONToArray($obj) {
        if ($obj instanceof \MongoDB\Model\BSONDocument || $obj instanceof \MongoDB\Model\BSONArray) {
            $obj = $obj->getArrayCopy();
        } elseif ($obj instanceof \MongoDB\BSON\ObjectId) {
            $obj = (string)$obj;
        }

        if (is_array($obj) || is_object($obj)) {
            foreach ($obj as $key => &$value) {
                $value = $this->convertBSONToArray($value);
            }
        }

        return $obj;
    }

    private function mongo_out($data) {
        return $this->convertBSONToArray(iterator_to_array($data ?? []));
    }

    public function get_discord($user_id) {
        return $this->mongo_out($this->discord_attempts->findOne(['profile.id' => $user_id]));
    }

    public function update_password($new_pass) {
        $user_id = Sessions::pull('authenticated');
        $get_user = $this->users->findOne(['id' => $user_id]);

        if ($get_user) {
            $get_user['password'] = password_hash($new_pass, PASSWORD_BCRYPT);
            return $this->users->updateOne(
                ['id' => $user_id],
                ['$set' => ['password' => $get_user['password']]]
            );
        } else {
            return null; // or handle the case where the user was not found
        }
    }

    public function has_pass($username) {
        $check = $this->users->findOne(['username' => $username]);
        if (isset($check['password'])) {
            return true;
        }
        return false;
    }

    public function update_user($user) {
        if (!isset($user['username'])) {
            return ['error' => 'invalid user'];
        }

        $check = $this->users->findOne(['username' => $user['username']]);

        if (isset($check['_id'], $check['username'])) {
            // update
            $update = [
                'last_login' => date('r')
            ];
            $status = $this->users->updateOne(
                ['_id' => $check['_id']],
                ['$set' => $update]
            );
        } else {
            // insert
            $user['last_login'] = date('r');
            $status = $this->users->insertOne($user);
        }

        // log update/login
        $this->log_history($user['username']);
        return $status;
    }

    public function log_discord_attempts($info) {
        $info = is_array($info) ? $info : ['info' => $info];
        $info['time_stamp'] = date('r');
        return $this->discord_attempts->insertOne($info);
    }

    public function insert_user($u='raven', $p='!@#2077KatanaXYZ') {
        $user = [
            'username' => $u,
            'password' => password_hash($p, PASSWORD_BCRYPT),
        ];
        return $this->users->insertOne($user)->getInsertedId();
    }

    public function verify_user($user, $pass) {
        $check = $this->users->findOne(['username' => $user]);
        if (isset($check['_id'], $check['username'], $check['password']) && password_verify($pass, $check['password'])) {

            // log login
            $log = $this->log_event($user);
            return $this->mongo_out($check);
        }
        return false;
    }

//    JCP Codes below

    public function get_jc_cards($page, $itemsPerPage = 10) {

        $offset = ($page - 1) * $itemsPerPage;

        $filter = [
            '$and' => [
                ['account_id' => ['$ne' => null]],
                ['account_id' => ['$ne' => '']],
                ['info.user_info.cardno' => ['$ne' => 'none']],
            ]
        ];
        $cursor = $this->jcp_users->find($filter, [
            'projection' => ['account_id' => 1, 'info.user_info.cardno' => 1, '_id' => 0],
            'skip' => $offset,
            'limit' => $itemsPerPage,
            'sort' => ['balance' => -1]
        ]);
        $records = $this->mongo_out($cursor);
        $totalRecords = $this->jcp_users->countDocuments($filter);
        return [
            'totalRecords' => $totalRecords,
            'records' => $records
        ];
    }

    public function get_zero_users($page, $itemsPerPage = 10) {

        $offset = ($page - 1) * $itemsPerPage;

        $bal = 0;
        $filter = [
            '$and' => [
                ['account_id' => ['$ne' => null]],
                ['account_id' => ['$ne' => '']],
                ['balance' => $bal]
            ]
        ];
        $cursor = $this->jcp_users->find($filter, [
            'projection' => ['account_id' => 1, '_id' => 0],
            'skip' => $offset,
            'limit' => $itemsPerPage,
            'sort' => ['balance' => -1]
        ]);
        $records = $this->mongo_out($cursor);
        $totalRecords = $this->jcp_users->countDocuments($filter);
        return [
            'totalRecords' => $totalRecords,
            'bal_type' => "e.{$bal}",
            'records' => $records
        ];
    }

    public function get_users_ids($page, $itemsPerPage = 10) {

        $offset = ($page - 1) * $itemsPerPage;

        $bal = 1000;
        $filter = [
            '$and' => [
                ['account_id' => ['$ne' => null]],
                ['account_id' => ['$ne' => '']],
                ['balance' => ['$gte' => $bal]]
            ]
        ];
        $cursor = $this->jcp_users->find($filter, [
            'projection' => ['account_id' => 1, '_id' => 0],
            'skip' => $offset,
            'limit' => $itemsPerPage,
            'sort' => ['balance' => -1]
        ]);
        $records = $this->mongo_out($cursor);
        $totalRecords = $this->jcp_users->countDocuments($filter);
        return [
            'totalRecords' => $totalRecords,
            'bal_type' => "gte.{$bal}",
            'records' => $records
        ];
    }

    public function get_emails($page, $itemsPerPage, $sortColumn, $sortDirection, $draw, $search) {
        $offset = ($page - 1) * $itemsPerPage;

        // Base filter
        $min_bal = 1000;
        $min_bal = 0;
        $filter = [
            '$and' => [
                ['account_id' => ['$ne' => null]],
                ['account_id' => ['$ne' => '']],
                ['info.user_info.email' => ['$ne' => '']],
                ['info' => ['$exists' => true]],
                ['$or' => [
                    ['balance' => ['$gte' => $min_bal]],
                    ['balance' => ['$exists' => false]],
                    ['balance' => null]
                ]]
            ]
        ];


        // Add search filter if search is not empty
        if (strlen($search) >= 1) {
            // Ensure the search filters only apply to string fields
            $searchFilter = [
                '$or' => [
                    ['user' => is_string($search) ? ['$regex' => $search, '$options' => 'i'] : []],
                    ['account_id' => is_string($search) ? ['$regex' => $search, '$options' => 'i'] : []],
                    // Avoid adding a regex on the balance field directly as it's numeric
                ]
            ];

            $filter['$and'][] = $searchFilter;
        }

        // Fetch the total number of records
        $totalRecords = $this->jcp_users->countDocuments($filter);

        // Fetch paginated records
        $cursor = $this->jcp_users->find($filter, [
            'sort' => [$sortColumn => $sortDirection],
            'skip' => $offset,
            'limit' => $itemsPerPage,
        ]);
        $records = $this->mongo_out($cursor);

        // Extract emails from the records
        $emails = [];
        foreach ($records as $document) {
            if (isset($document['info']['user_info']['email'])) {
                $emails[] = $document['info']['user_info']['email'];
            }
        }

        // Return response
        $response = [
            'draw' => $draw,
            'totalRecords' => $totalRecords,
            'emails' => $emails
        ];

        return $response;
    }

    public function get_users($page, $itemsPerPage, $sortColumn, $sortDirection, $draw, $search) {
        $offset = ($page - 1) * $itemsPerPage;

        // Base filter
        $min_bal = 1000;
        $min_bal = 0;
        $filter = [
            '$and' => [
                ['account_id' => ['$ne' => null]],
                ['account_id' => ['$ne' => '']],
                ['info.user_info.email' => ['$ne' => '']],
                ['info' => ['$exists' => true]],
                ['$or' => [
                    ['balance' => ['$gte' => $min_bal]],
                    ['balance' => ['$exists' => false]],
                    ['balance' => null]
                ]]
            ]
        ];


        // Add search filter if search is not empty
        if (strlen($search) >= 1) {
            // Ensure the search filters only apply to string fields
            $searchFilter = [
                '$or' => [
                    ['user' => is_string($search) ? ['$regex' => $search, '$options' => 'i'] : []],
                    ['account_id' => is_string($search) ? ['$regex' => $search, '$options' => 'i'] : []],
                    // Avoid adding a regex on the balance field directly as it's numeric
                ]
            ];

            $filter['$and'][] = $searchFilter;
        }

        // Fetch the total number of records
        $totalRecords = $this->jcp_users->countDocuments($filter);

        // Fetch paginated records
        $cursor = $this->jcp_users->find($filter, [
            'sort' => [$sortColumn => $sortDirection],
            'skip' => $offset,
            'limit' => $itemsPerPage,
        ]);
        $records = $this->mongo_out($cursor);

        // Aggregate to calculate the total balance
        $totalBalanceResult = $this->jcp_users->aggregate([
            ['$match' => $filter],
            ['$group' => ['_id' => null, 'totalBalance' => ['$sum' => '$balance']]]
        ]);

        $totalBalance = 0;
        foreach ($totalBalanceResult as $balance) {
            $totalBalance = $balance['totalBalance'];
        }

        // Return response
        $response = [
            'draw' => $draw,
            'totalBalance' => $totalBalance,
            'totalRecords' => $totalRecords,
            'records' => $records
        ];

        return $response;
    }


}