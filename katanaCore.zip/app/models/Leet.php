<?php

use SleekDB\Exceptions\InvalidConfigurationException;
use SleekDB\Exceptions\IOException;
use SleekDB\Store;

class Leet extends Model
{

    private
        $discord_attempts,
        $users,
        $login_history,
        $data_dir = APP_DIR . "/database";

    /**
     * @throws IOException
     * @throws InvalidConfigurationException
     * @throws \SleekDB\Exceptions\InvalidArgumentException
     */
    public function __construct()
    {
        parent::__construct();

        $configuration = config_item('SleekDB');
        $this->users = new Store('_users', $this->data_dir, $configuration);
        $this->discord_attempts = new Store('_discord_attempts', $this->data_dir, $configuration);
        $this->login_history = new Store('_login_history', $this->data_dir, $configuration);

    }

    private function log_history($username, $type='login') {

        $data = [
            'stamp' => date('r'),
            'username' => $username,
            'type' => $type
        ];
        $log = $this->login_history->insert($data);
    }

    public function get_discord($user_id) {
        return $this->discord_attempts->findOneBy(['profile.id','==',$user_id]);
    }

    public function update_password($new_pass) {
        $user_id = Sessions::pull('authenticated');
        $get_user = $this->users->findOneBy(['id','==',$user_id]);
        $get_user['password'] = password_hash($new_pass, PASSWORD_BCRYPT);
        return $this->users->update($get_user);
    }

    public function has_pass($username) {
        $check = $this->users->findOneBy(['username','==',$username]);
        if (isset($check['password'])) {
            return true;
        }   return false;
    }

    public function update_user($user) {
        if (!isset($user['username'])) {
            return ['error'=>'invalid user'];
        }
        $check = $this->users->findOneBy(['username','==',$user['username']]);
        if (isset($check['_id'], $check['username'])) {
            // update
            $update = [
                'last_login' => date('r')
            ];
            $status = $this->users->updateById((int)$check['_id'], $update);
        } else {
            // insert
            $user['last_login'] = date('r');
            $status = $this->users->insert($user);
        }

        // log update/login
        $this->log_history($user['username']);
        return $status;
    }

    public function log_discord_attempts($info) {
        $info = is_array($info) ? $info : ['info' => $info];
        $info['time_stamp'] = date('r');
        return $this->discord_attempts->insert($info);
    }

    public function insert_user() {
        $user = [
            'username' => 'raven',
            'password' => password_hash('qwerty', PASSWORD_BCRYPT),
        ];
        return $this->users->insert($user);
    }

    public function verify_user($user, $pass) {
        $check = $this->users->findOneBy(['username', '=', $user]);
        if (isset($check['_id'], $check['username'], $check['password']) && password_verify($pass, $check['password'])) {
            return $check;
        }   return false;
    }

}