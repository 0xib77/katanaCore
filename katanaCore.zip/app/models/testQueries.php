<?php
use SleekDB\Exceptions\InvalidConfigurationException;
use SleekDB\Exceptions\IOException;
use SleekDB\Store;
require __DIR__ . DIRECTORY_SEPARATOR . "../vendor/autoload.php";

class Tester {
    private
        $users,
        $navigations,

        $data_dir = __DIR__ . DIRECTORY_SEPARATOR . "../database";

    public function __construct()
    {

        $configuration = [
            "auto_cache" => false,
            "cache_lifetime" => null,
            "timeout" => false, // deprecated! Set it to false!
            "primary_key" => "_id",
            "folder_permissions" => 0777
        ];
        $this->users = new Store('accounts', $this->data_dir, $configuration);
        $this->navigations = new Store('navigations', $this->data_dir, $configuration);

    }

    public function test($email) {
        return $this->users->findOneBy(['email', '==', $email]) ?? false;
    }

    public function create_user($email, $username, $password, $user_type, $status)
    {
        $user = [
            'email' => $email,
            'username' => $username,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'user_type' => $user_type,
            'status' => $status,
        ];

        return $this->users->insert($user);
    }
}

$tester = new Tester();
$tester->create_user("demo@demo.com", "demo", "demo", "admin", "active");
print_r($tester->test("demo"));