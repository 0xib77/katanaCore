<?php
/*
|--------------------------------------------------------------------------
| SleekDB Config
|--------------------------------------------------------------------------
*/
$config['SleekDB'] = [
    "auto_cache" => false,
    "cache_lifetime" => null,
    "timeout" => false, // deprecated! Set it to false!
    "primary_key" => "_id",
    "folder_permissions" => 0777
];