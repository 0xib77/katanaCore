<?php
/*
| -------------------------------------------------------------------
| Discord Config
| -------------------------------------------------------------------
*/

$config['DISCORD'] = [
    'APP_ID' => '',
    'APP_SECRET' => '',
    'APP_SCOPE' => 'identify+guilds+email+connections',
    'APP_REDIRECT' => "auth/discord/verify",
    'BOT_TOKEN' => '',
    'PUBLIC_KEY' => '',
    'SERVER_ADMIN' => [
        '1296330110982553631', // KatanaSec
    ]
];