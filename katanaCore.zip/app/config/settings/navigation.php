<?php
/*
|--------------------------------------------------------------------------
| Page Navigations
|--------------------------------------------------------------------------
*/
$config['navigations'] = [

    'navigation' => [
        'dashboard' => [
            'icon' => 'bi bi-cpu',
            'permissions' => [
                // store permission on  Sessions @ permission
                'super', 'admin', 'public'
            ],
        ],
        'ongoing interactions' => [
            'icon' => 'bi bi-hdd-network',
            'permissions' => [
                // store permission on  Sessions @ permission
                'super', 'admin', 'public'
            ],
            'navs' => [
                'active_clients',
                'connections',
            ],
        ],
    ],
    'settings & administration' => [
        'connection settings' => [
            'icon' => 'bi bi-hdd-network',
            'permissions' => [
                // store permission on  Sessions @ permission
                'super', 'admin', 'public'
            ],
            'navs' => [
                'socket_connections',
                'webhooks',
            ],
        ],
        'system settings' => [
            'icon' => 'bi bi-sliders',
            'permissions' => [
                // store permission on  Sessions @ permission
                'super', 'admin', 'public'
            ],
        ],
//        'profile' => [
//            'icon' => 'bi bi-person-circle',
//            'permissions' => [
//                // store permission on  Sessions @ permission
//                'super', 'admin', 'public'
//            ],
//        ],
    ],
    'online system users' => [
        'waiting' => [
            'icon' => 'bi bi-hourglass-bottom',
            'view' => true
        ],
    ],
//    'user interactions' => [
//        'interacting users' => [
//            'icon' => 'bi bi-people-fill',
//            'view' => true,
//            'navs' => [
//                'None',
//            ],
//        ],
//    ],
    'active links' => [
        '<linkCount class=\'text-theme\'>Checking...</linkCount>' => [
            'icon' => 'bi bi-hdd-network text-theme',
            'view' => true,
        ],
    ],
];