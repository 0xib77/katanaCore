<?php
/*
|--------------------------------------------------------------------------
| Discord Webhooks
|--------------------------------------------------------------------------
*/
$config['WEBHOOKS'] = [
    'log_agent' => [
        'bot' => [
            "username" => "Log Agent",
            "avatar_url" => "https://ru.gravatar.com/userimage/28503754/1168e2bddca84fec2a63addb348c571d.jpg?size=512",
        ],
        'embed' => [
            'type' => 'rich',
            'color' => hexdec('EA0E85'),
        ],
//        'url' => 'https://discordapp.com/api/webhooks/1205744987510407169/FDAIAL-X9qvMwXiibuGEQyVCsbiXyw_MAXk7ZyY65gdDqtUW4wEc4iUHX2OoyNXhy7uz',
        'url' => 'https://discord.com/api/webhooks/1205744987510407169/FDAIAL-X9qvMwXiibuGEQyVCsbiXyw_MAXk7ZyY65gdDqtUW4wEc4iUHX2OoyNXhy7uz',
    ],
];