<?php
/*
| -------------------------------------------------------------------
| Site Config
| -------------------------------------------------------------------
*/
$site_name = 'https://bdo-dash.2077.ws/';

$scheme = (
    (
        json_decode(($_SERVER['HTTP_CF_VISITOR'] ?? 'http'), true)['scheme'] ??
        ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? 'http')
    ) ??
    ($_SERVER['REQUEST_SCHEME'] ?? 'http')
);

$config['maintenance_message'] = "Website Under Maintenance";

$config['website'] = [

//    'download_url' => 'https://www.mediafire.com/file/w2wewv166x8n9r4/Weapons+of+War+PH.7z/file',

    'production' => [
        'base_url' => $site_name,
        'socket' => null,
    ],

    'maintenance' => [
        'base_url' => $site_name,
        'socket' => null,
    ],

    'development' => [
        'base_url' => "{$scheme}://{$_SERVER['SERVER_NAME']}/",
        'socket' => null,
    ],


];

/*
|--------------------------------------------------------------------------
| Page Config
|--------------------------------------------------------------------------
*/
$config['page_config'] = [
    'sys_name' => 'ANBU BLACKOPS',
    'sys_acronym' => 'X',
    'sys_year' => date('Y'),
    'powered_by' => '2077KatanaSec',
];