<?php /** @noinspection PhpUndefinedVariableInspection */

/*
| -------------------------------------------------------------------
| Default Environment
| -------------------------------------------------------------------
| Values: maintenance, development and production
*/
// $config['ENVIRONMENT'] = 'production';
$config['ENVIRONMENT'] = 'development';
//$config['ENVIRONMENT'] = 'maintenance';
/*
| -------------------------------------------------------------------
|  Config Files
| -------------------------------------------------------------------
*/

@ini_set('memory_limit', '1536M');
$timeout = 0;
@ini_set('max_execution_time', $timeout);
@set_time_limit($timeout);
@date_default_timezone_set('Asia/Manila');
@session_name('XS_APP');
@session_start(['cookie_lifetime' => 43200, 'cookie_secure' => ($config['ENVIRONMENT'] === 'development' ? false : true), 'cookie_httponly' => true]);
//header("Expires: Tue, 03 Jul 2030 06:00:00 GMT");
//header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
//header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
//header("Pragma: no-cache");
header("Connection: close");

/*
|--------------------------------------------------------------------------
| Default Controllers and Methods
|--------------------------------------------------------------------------
*/
//$config['default_controller'] = 'Welcome';
//$config['default_method'] = 'index';
$config['default_controller'] = 'Main';
$config['default_method'] = 'index';

/*
| -------------------------------------------------------------------
| Config Loader
| -------------------------------------------------------------------
*/
if (!function_exists('configLoader')) {
    function configLoader($folderPath, $conf) {
        // Get all files with ".config.php" in the file name from the specified folder
        $configFiles = glob($folderPath . '/*.php');

        // Load/require/include each config file
        foreach ($configFiles as $configFile) {
            if (file_exists($configFile)) {
                include $configFile;
                $conf = array_merge($config, $conf);
            }
        }
        return $conf;
    }
}
$config = configLoader(__DIR__ . DIRECTORY_SEPARATOR . 'settings', $config);
$config['DISCORD']['APP_REDIRECT'] = (config_item('website')[config_item('ENVIRONMENT')]['base_url'] ?? "") . $config['DISCORD']['APP_REDIRECT'];


/*
| -------------------------------------------------------------------
| Socket Config
| -------------------------------------------------------------------
*/
$config['SOCKET'] = $config['website'][$config['ENVIRONMENT']]['socket'] ?? "";


/*
|--------------------------------------------------------------------------
| Base Site URL
|--------------------------------------------------------------------------
| WARNING: You MUST set this value!
*/

if (in_array(
    $_SERVER['REMOTE_ADDR'],
    [
        '127.0.0.1',
        '0.0.0.0',
        '1::',
    ]
)) {
    $config['base_url'] = $config['website']['production']['base_url'] = $config['website']['development']['base_url'];
} else {
    $config['base_url'] = $config['website'][$config['ENVIRONMENT']]['base_url'];
}

/*
|--------------------------------------------------------------------------
| Index File
|--------------------------------------------------------------------------
|
| If you are using mod_rewrite to remove index.php in the URL set this
| variable to blank.
|
*/
$config['index_page'] = 'main.php';

/*
|--------------------------------------------------------------------------
| Composer auto-loading
|--------------------------------------------------------------------------
|
| Enabling this setting will tell Katana2077 to look for a Composer
| package auto-loader script in app/vendor/autoload.php.
|
|	$config['composer_autoload'] = TRUE;
|
| Or if you have your vendor/ directory located somewhere else, you
| can opt to set a specific path as well:
|
|	$config['composer_autoload'] = '/path/to/vendor/autoload.php';
|
| For more information about Composer, please visit http://getcomposer.org/
|
| Note: This will NOT disable or override the Katana2077-specific
|	autoloading (app/config/autoload.php)
*/
$config['composer_autoload'] = TRUE;

/*
|--------------------------------------------------------------------------
| Allowed URL Characters
|--------------------------------------------------------------------------
|
| This lets you specify which characters are permitted within your URLs.
| When someone tries to submit a URL with disallowed characters they will
| get a warning message.
|
| As a security measure you are STRONGLY encouraged to restrict URLs to
| as few characters as possible.  By default only these are allowed: a-z 0-9~%.:_-
|
| Leave blank to allow all characters -- but only if you are insane.
|
| The configured value is actually a regular expression character group
| and it will be executed as: ! preg_match('/^[<permitted_uri_chars>]+$/i
|
| DO NOT CHANGE THIS UNLESS YOU FULLY UNDERSTAND THE REPERCUSSIONS!!
|
*/
$config['permitted_uri_chars'] = 'a-z 0-9~%.:_\-';

/*
|--------------------------------------------------------------------------
| Default Character Set
|--------------------------------------------------------------------------
|
| This config will be use html_escape function
|
*/
$config['charset'] = 'UTF-8';

/*
|--------------------------------------------------------------------------
| Error Views Directory Path
|--------------------------------------------------------------------------
|
| app/views/errors/ directory.  Use a full server path with trailing slash.
|
*/
$config['error_view_path'] = APP_DIR . 'views' . DS . 'errors' . DS;
/*
|--------------------------------------------------------------------------
| Default Language
|--------------------------------------------------------------------------
|
| This determines which set of language files should be used. Make sure
| there is an available translation if you intend to use something other
| than en-US.
|
*/
$config['language'] = 'en-US';

/*
|--------------------------------------------------------------------------
| Session                     
|--------------------------------------------------------------------------
|
| Settings for sessions
| $config['sess_save_path'] will get the session save path form php.ini
| if empty.
|
|--------------------------------------------------------------------------
*/
$config['sess_driver'] = 'file';
$config['sess_cookie_name'] = 'LLSession';
$config['sess_expiration'] = 7200;
$config['sess_save_path'] = '/';
$config['sess_match_ip'] = TRUE;
$config['sess_match_fingerprint'] = TRUE;
$config['sess_time_to_update'] = 300;
$config['sess_regenerate_destroy'] = TRUE;
$config['sess_expire_on_close'] = FALSE;

/*
|--------------------------------------------------------------------------
| Cookies                      
|--------------------------------------------------------------------------
|
|Settings for cookies.
|
|--------------------------------------------------------------------------
*/
$config['cookie_prefix'] = 'ktn_';
$config['cookie_domain'] = '';
$config['cookie_path'] = '/';
$config['cookie_secure'] = TRUE;
$config['cookie_expiration'] = 86400;
$config['cookie_httponly'] = TRUE;
$config['use_only_cookies'] = TRUE;
$config['cookie_samesite'] = 'Lax';

/*
|--------------------------------------------------------------------------
| Cache                      
|--------------------------------------------------------------------------
|
| Settings for Cache
| Set your cache directory and cache expiration time here
| Default:
|   $config['cache_dir'] = 'runtime/cache/';
|   $config['cache_default_expires'] = 0;
|
|--------------------------------------------------------------------------
*/
$config['cache_dir'] = 'runtime/cache/';
$config['cache_default_expires'] = 7200;

/*
|--------------------------------------------------------------------------
| Cross Site Request Forgery
|--------------------------------------------------------------------------
| Enables a CSRF cookie token to be set. When set to TRUE, token will be
| checked on a submitted form. If you are accepting user data, it is strongly
| recommended CSRF protection be enabled.
|
| 'csrf_exclude_uris' = Array of uris that will not go throught protection
| 'csrf_token_name' = The token name
| 'csrf_cookie_name' = The cookie name
| 'csrf_expire' = The number in seconds the token should expire.
*/
$config['csrf_protection'] = 0;
$config['csrf_exclude_uris'] = array();
$config['csrf_token_name'] = 'csrf_test_name';
$config['csrf_cookie_name'] = 'csrf_cookie_name';
$config['csrf_expire'] = 7200;
$config['csrf_regenerate'] = 0;