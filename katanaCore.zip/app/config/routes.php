<?php


/*
| -------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| $route['translate_uri_dashes'] = TRUE will enable to use dash(-) instead 
| of underscore(_) in URI
|
| $route['404_override'] is use if you want to add custom 404 error page.
| 
|	example: $route['404_override'] = 'default/404'
|
|	if you have 'default folder' and '404.php file' inside error folder in view
*/
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//$route['administrator'] = 'administrator/index';
//$route['administrator'] = 'administrator';
//$route['access'] = 'access';
//$route['ref/(:any)'] = 'Api/referral/$1';
//$route['activate/(:any)'] = 'Main/activate_user/$1';
//$route['process'] = 'Actions';

//$route['(:any)'] = 'Api/$1';
//$route['api'] = 'Api/index';

$route['api/(:any)'] = 'Api/$1';
$route['api'] = 'Api/index';

$route['auth/(:any)'] = 'Auth/$1';
$route['login'] = 'Auth/login';
$route['forgot-pass'] = 'Auth/forgot_pass';
$route['sign-up'] = 'Auth/signup';
$route['discord'] = 'Auth/discord';
$route['sessions'] = 'Auth/sessions';

$route['pending'] = 'Auth/pending';

$route['share'] = 'Open/index';

//$route['sms_nuke'] = 'Api/sms_nuke';

//$route['(:any)'] = 'Main/$1';
$route['(:any)'] = 'Auth/verify_navigation/$1';
$route['app'] = 'Main/index';

// $route['agent'] = 'Ninja/index';
// $route['agent/(:any)'] = 'Ninja/$1';

//$route['home/(:any)'] = 'Home/$1';
//$route['home'] = 'Home/index';
//
//$route['main/news_info/(:any)'] = 'Main/index/$1';
//$route['main/(:any)'] = 'Main/$1';
//$route['main'] = 'Main/index';

//$route['news/(:any)'] = 'News/$1';
//$route['news'] = 'News/index';

//$route['403'] = 'Main/_403';

// download url
//$route['download'] = 'Redirect/to_external';

//$route['master/(:any)'] = 'Master/$1';
//$route['master'] = 'Master/index';

//$route['reset_pass/token/(:any)'] = 'Api/reset_password/$1';
//$route['register'] = 'Main/register';
//$route['webhook'] = 'Api/webhook';
//$route['pp_ipn'] = 'Api/pp_ipn';
//$route['ipn'] = 'Api/pp_ipn';
//$route['points'] = 'Points/index';
//$route['points/(:any)'] = 'Points/$1';

//$route['trans/(:any)'] = 'Api/trans/$1';


//$route['route'] = '/news';
//$route['news/(.*)'] = 'news/$1';

//$route['/'] = 'BlackOps/index';
//$route['game_app/(:any)'] = 'App/$1';
//$route['launcher/page'] = $route['page/launcher'] = 'App/launcher_banner';
//$route['config/launcher'] = 'App/launcher_conf';
//$route['config/launcher/(:any)'] = 'App/launcher_conf/$1';
//$route['launcher/patch'] = 'App/launcher_patch';
//$route['account/login'] = 'Auth/login';
//$route['auth/access'] = 'Auth/access';
//$route['account/register'] = 'Auth/register';
//$route['account/pending'] = 'Auth/pending';
//$route['acunetix/activation/(:any)'] = 'Auth/acunetix/$1';


//$route['main'] = 'template/index';
//$route['activate'] = 'main/activate';
//$route['auth_discord/(:any)'] = 'discord/$1';
//$route['auth_discord/discord'] = 'discord/index';
//$route['main/(:any)'] = 'main/$1';
//$route['(:any)'] = 'main/$1';
//$route['main/(:any)'] = 'welcome/index/$1';