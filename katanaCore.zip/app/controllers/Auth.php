<?php

class Auth extends Controller
{
    private
        $user = [],
        $assets = null,
        $_method = null,
        $data = [];

    public function __construct()
    {

        $config = get_config();
        $this->_method = $config['page_config']['_method'] = $this->get_current_method();
        $config['page_config']['_title'] = __CLASS__ . " : " . ucwords(str_replace(['_','.'],' ', $this->_method));
        // initialize global controller
        parent::__construct($config);
        $this->assets = '/public/assets/';
//        $this->db = (new Leet());
        $this->db = (new Mongo());
        $this->data = getData();
    }

    public function sessions() {
        $this->out(Sessions::all());
    }

    public function forgot_pass() {
        $this->out('forgot');
    }

    public function signup() {
        $this->out('request error', true,403);
    }

    public function pending() {
//        $this->out('account pending verification');
        show_error('Account pending','Please wait for Account verification','error_general', 403);
    }

    public function discord($action = false) {

        switch (strtolower($action)) {

            case "verify":
                if (!isset($this->data['get']['state'])) {
                    show_error('Access Denied',"Invalid request, state mismatch",'error_restricted', 403);
//                    $this->out('invalid request, state mismatch', true, 403);
                }
                if (isset($this->data['get']['state']) && $this->data['get']['state'] !== Sessions::pull('_discord')) {
                    show_error('Access Denied',"Invalid state, Signature: " . md5($this->data['get']['state'] . date('r')),'error_restricted', 403);
//                    $this->out('invalid state, try again later', true, 403);
                }


                if (!isset($this->data['get']['code'])) {

                    $error = strtolower($this->data['get']['error']) ?? '';
                    $default = "Invalid request, Please try again later";
                    switch ($error) {
                        case 'access_denied':
                            $default = "Request was denied. Try again later";
                            break;
                    }

                    show_error('Access Denied',$default,'error_restricted', 403);

//                    $this->out('invalid request, code missing', true, 403);
                }

                $discord_conf = config_item('DISCORD');

                $discord = "https://discord.com";

                // init
                $data = http_build_query([
                    "client_id" => $discord_conf['APP_ID'],
                    "client_secret" => $discord_conf['APP_SECRET'],
                    "grant_type" => "authorization_code",
                    "code" => $this->data['get']['code'],
                    "redirect_uri" => $discord_conf['APP_REDIRECT']
                ]);

                $fetch_init = get_content(
                    "{$discord}/api/oauth2/token",
                    "post",
                    false,
                    $data,
                );
                $response = (json_decode($fetch_init['data'], true) ?? $fetch_init['data']);
                if ($fetch_init['status'] !== 200) {
//                    $this->out($response, true, $fetch_init['status']);
                    show_error('Request Error',"<code>" . json_encode($response, JSON_PRETTY_PRINT) ."</code>",'error_general', $fetch_init['status']);
                }
                if (!isset($response['access_token'],$response['refresh_token'],$response['scope'])) {
//                    $this->out([
//                        'status' => 'unexpected error',
//                        'data' => $response
//                    ], true, 400);
                    show_error('Unexpected Error',"<code>" . json_encode($response, JSON_PRETTY_PRINT) ."</code>",'error_general', $fetch_init['status']);
                }
                $access_token = $response['access_token'];
                $refresh_token = $response['refresh_token'];
                $scope = $response['scope'];

                $session['discord'] = [
                    'access_token' => $access_token,
                    'refresh_token' => $refresh_token,
                    'scope' => $scope
                ];

                // fetch user
                $header = [
                    'Content-Type: application/x-www-form-urlencoded',
                    'Authorization: Bearer ' . $access_token
                ];
                $fetch_user = get_content(
                    "{$discord}/api/users/@me",
                    "get",
                    $header,
                );
                $response = (json_decode($fetch_user['data'], true) ?? $fetch_user['data']);
                if ($fetch_user['status'] !== 200) {
//                    $this->out($response, true, $fetch_user['status']);
                    show_error('Unexpected Error',"<code>" . json_encode($response, JSON_PRETTY_PRINT) ."</code>",'error_general', $fetch_user['status']);
                }
                if (!isset(
                    $response['id'],
                    $response['username'],
                    $response['avatar'],
                    $response['email'],
                    $response['locale'],
                    $response['verified'],
                    $response['global_name']
                )) {
//                    $this->out(['status' => 'unexpected error', 'data' => $response], true, 400);
                    show_error('Unexpected Error',"<code>" . json_encode($response, JSON_PRETTY_PRINT) ."</code>",'error_general', $fetch_user['status']);
                }
                $discord_id = $response['id'];
                $session['discord']['profile'] = $response;

                try {
                    // fetch connections
                    $fetch_connections = get_content(
                        "{$discord}/api/users/@me/connections",
                        "get",
                        $header,
                    );
                    $response = (json_decode($fetch_connections['data'], true) ?? $fetch_connections['data']);
                    if ($fetch_user['status'] !== 200) {
//                    $this->out($response, true, $fetch_connections['status']);
                        show_error('Unexpected Error',"<code>" . json_encode($response, JSON_PRETTY_PRINT) ."</code>",'error_general', $fetch_connections['status']);
                    }
                    if (is_array($response) && count($response) > 0) {
                        $session['discord']['connections'] = $response;
                    }
                } catch (Error $e) {
                    $session['discord']['connections'] = [
                        'error' => $response
                    ];
                }

                // fetch guilds
                $fetch_guilds = get_content(
                    "{$discord}/api/users/@me/guilds",
                    "get",
                    $header,
                );
                $response = (json_decode($fetch_guilds['data'], true) ?? $fetch_guilds['data']);
                if ($fetch_user['status'] !== 200) {
//                    $this->out($response, true, $fetch_guilds['status']);
                    show_error('Unexpected Error',"<code>" . json_encode($response, JSON_PRETTY_PRINT) ."</code>",'error_general', $fetch_user['status']);
                }
                if (is_array($response) && count($response) > 0) {
                    $session['discord']['guilds'] = $response;
                }

                // log discord login attempts
                $log = $this->db->log_discord_attempts($session['discord']);

                // check user perms
                if (!in_array($discord_id,$discord_conf['SERVER_ADMIN'])) {
                    // pending
                    redirect('pending');
                }

                // User is admin, set session, redirect dashboard
                $session['authenticated'] = $discord_id;
                $session['user'] = $session['discord']['profile'] ?? "System";

                // update user
                $update = $this->db->update_user($session['user']);
                Sessions::push($session);

                // unset discord login state
                Sessions::unset(['_discord','state']);

                $next_url = Sessions::pull('next_url');
                if (!is_null($next_url)) {
                    $next_url = array_filter(explode("/", $next_url, 2));
                    $next_url = implode("/", $next_url);
                    redirect($next_url);
                } else {
                    redirect('dashboard');
                }

                break;

            case "login":
                $state = Sessions::pull('_discord');

                if (strlen($state ?? '') <= 0) {
                    $this->out(ucfirst('unauthorized request'), true, 403);
                }
                if (!isset($this->data['post']['state'])) {
                    $this->out(ucfirst('invalid request'), true, 403);
                }
                if ($this->data['post']['state'] !== $state) {
                    $this->out(ucfirst('state invalid, request denied'), true, 403);
                }

                $discord_conf = config_item('DISCORD');
                $url = 'https://discordapp.com/oauth2/authorize?response_type=code&client_id='
                    . $discord_conf['APP_ID']
                    . '&redirect_uri='
                    . $discord_conf['APP_REDIRECT']
                    . '&scope='
                    . $discord_conf['APP_SCOPE']
                    . "&state="
                    . $state;

                $this->out([
                    'status' => 'success',
                    'redirect' => $url
                ]);
                break;

            default:
                $this->out([
                    'discord_actions' => [
                        '/auth/discord/login',
                        '/auth/discord/verify'
                    ]
                ]);
                break;
        }


    }

    public function login() {

        if (Sessions::pull('authenticated')) {
            redirect('dashboard');
        }

        $discord_state = substr(bin2hex(md5(date('r') . real_ip()) . openssl_random_pseudo_bytes(12)), 6, 24);
        Sessions::push(['_discord' => $discord_state]);

        $data = [
            'discord_state' => $discord_state,
//            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
//            'description' => 'stats, overview & system information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
//                    'plugins/jvectormap-next/jquery-jvectormap.css',
//                    'plugins/sweetalert2/dist/sweetalert2.min.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
//                    'plugins/jvectormap-next/jquery-jvectormap.css',
//                    'plugins/bootstrap-daterangepicker/daterangepicker.css',
                    '',
                    '',
//                    'css/main.css',
//                    'plugins/select-picker/dist/picker.min.css',

                    // data tables
//                    'plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css',
//                    'plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css',
//                    'plugins/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
//                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
//                    'plugins/jvectormap-content/world-mill.js',
//                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
//                    'js/demo/dashboard.demo.js',
                    '',
//                    'plugins/masonry-layout/dist/masonry.pkgd.min.js',
//                    'plugins/select-picker/dist/picker.min.js',
//                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
//                    'plugins/jvectormap-content/world-mill.js',
//                    'plugins/apexcharts/dist/apexcharts.min.js',
//                    'plugins/moment/min/moment.min.js',
//                    'plugins/bootstrap-daterangepicker/daterangepicker.js',
//                    'js/demo/dashboard.demo.js',
//                    'plugins/chart.js/dist/chart.umd.js',

                    // data tables
//                    'plugins/datatables.net/js/jquery.dataTables.min.js',
//                    'plugins/datatables.net-bs5/js/dataTables.bootstrap5.min.js',
//                    'plugins/datatables.net-buttons/js/dataTables.buttons.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.colVis.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.flash.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.html5.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.print.min.js',
//                    'plugins/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js',
//                    'plugins/datatables.net-responsive/js/dataTables.responsive.min.js',
//                    'plugins/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js',


                ]
            ],
        ];

//        $this->out($this->config);

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function verify_navigation($verify) {
        $verify = strtolower(cleanData($verify));

        $navs = config_item('navigations');
        $navigations = [];
        foreach ($navs as $cat => $nav) {

            foreach ($nav as $navi => $n) {
                if (isset($n['navs']) && count($n['navs']) >= 1) {
                    foreach ($n['navs'] as $i) {
                        $navigations[] = strtolower(str_replace(" ", "_", $i));
                    }
                } else {
                    $navigations[] = strtolower(str_replace(" ", "_", $navi));
                }
            }

        }

        if (!in_array($verify, $navigations, true)) {
            show_error('Page Not Found','The page you requested was not found.','error_404', 404);
        } else {

            if (is_null(Sessions::pull('authenticated'))) {

                $current_url = $_SERVER['REQUEST_URI'];
                Sessions::push(['next_url' => $current_url]);

                show_error('Access Denied','You must be logged-in to access this page','error_404', 403);
            }

            require APP_DIR . 'controllers/Main.php';
            $init = new Main();
            if (!method_exists($init, $verify)) {
                show_error('Access Denied',"Permission required to access page.",'error_restricted', 403);
            } else {
                $init->{$verify}();
            }

        }
    }





}