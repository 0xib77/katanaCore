<?php

use DiDom\Document;

class Main extends Controller
{

    private
        $user = [],
        $assets = null,
        $active_user = null,
        $user_email = null,
        $_method = null,
        $data = [];

    public function __construct()
    {

        $this->set_method_auth(
            __CLASS__, // class to check for method that requires auth
            [ // method/function list

                // disable access
//                '-payloads',
//                '-live_bots',
//                '-client_test',
//                '-dashboard',

                // public methods
//                '!dashboard', // whitelist function that does not need auth
                '!index',
                '!login',
//                '!private_method',
//                '!register',
//                '!forgot_password',
//                '!initiate_reset_password',
//                '!topup',
//                '!ref',
//                '!logout',
//                '!page',
//                '!fetch_news',
//                '!top_guild',
//                '!top_players',
//                '!top_newbies',
//                '!top_richest',
//                '!top_donator',
//                '!top_killers',
//                '!trans',
//                '!online_users',
//                '!get_server_info',
//                '!reset_password2',


                // private methods | needs auth
                'private_method',
//                'getreferredby',
//                'edit_account',
//                'change_password',
//                'logout',
//                'convert_time',
//                'getonline_time',
//                'transaction_history',
            ],
            [ // session auth to check
//                'authenticated_user_sample',
                'authenticated',
            ],
            403, //'/' // redirect location if not authed else display 403
        );

        $config = get_config();
        $this->_method = $config['page_config']['_method'] = $this->get_current_method();
        $config['page_config']['_title'] = __CLASS__ . " : " . ucwords(str_replace(['_','.'],' ', $this->_method));
        // initialize global controller
        parent::__construct($config);
        $this->user['avatar_url'] = $this->discord_profile_image();
        $this->assets = '/public/assets/';
//        $this->db = (new Leet());
        $this->db = (new Mongo());
        $this->data = getData();

        // check if user has password
        $has_pass = $this->db->has_pass(Sessions::pull('user')['username'] ?? '?');
        Sessions::push([
            'has_pass' => ($has_pass ? 'set' : 'require'),
            '_logoutKey' => md5(date('r'))
        ]);

        // log activity
        $this->log_activity();
    }

    private function log_activity() {

        $info = [
            'activity' => $_SERVER['REQUEST_URI'],
            'user' => Sessions::pull('user')['username'] ?? 'System',
            'session' => Sessions::all(),
            'date' => date('r')
        ];
        $log_id = $this->db->activity_logs($info);
    }

    private function discord_profile_image() {
        $_r = md5(date('r'));
        if (Sessions::pull('discord') && isset(
                Sessions::pull('discord')['profile']['id'],
                Sessions::pull('discord')['profile']['avatar'],
            )) {
            $_disc = Sessions::pull('discord');
            return "https://cdn.discordapp.com/avatars/{$_disc['profile']['id']}/{$_disc['profile']['avatar']}.jpg?_r=" . $_r;
        }   return "/public/assets/img/user/profile.jpg?_r=" . $_r;
    }

    public function index() {
        $auth = Sessions::pull('authenticated');
        if (!$auth) {
            redirect('login');
        }   redirect('dashboard');
    }

    public function connections() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'connection logs & information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function active_clients() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'active clients information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
                    '',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function logs() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'overall logs information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
//                    'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/atom-one-dark.min.css',
//                    'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/solarized-dark.min.css',
//                    'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/dracula.min.css',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function socket_connections() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'socket connection settings & information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
                    '',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function webhooks() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'webhook settings',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
                    '',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function system_settings() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'system settings',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
                    '',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function profile() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'profile settings & information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [
                    'plugins/jvectormap-next/jquery-jvectormap.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
                    '',
                    '',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [
                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
                    '',


                ]
            ],
        ];

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

    public function dashboard() {

        $data = [
            'avatar_img' => $this->user['avatar_url'],
            'auth_user_menu' => auth_profile_menu($this->user),
            'method' => get_method($this->get_current_method()),
            'description' => 'stats, overview & system information',
            'assets_path' => $this->assets,
            'load_css' => [
                'dir' => $this->assets,
                'css' => [

                    // draggable
                    'https://code.jquery.com/ui/1.14.0/themes/base/jquery-ui.css',

                    'plugins/jvectormap-next/jquery-jvectormap.css',
//                    'plugins/jvectormap-next/jquery-jvectormap.css',
//                    'plugins/sweetalert2/dist/sweetalert2.min.css',
                    'plugins/sweetalert2/dist/theme-dark/dark.css',
                    'https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css',
//                    'plugins/bootstrap-daterangepicker/daterangepicker.css',
                    '',
                    '',
//                    'css/main.css',
//                    'plugins/select-picker/dist/picker.min.css',

                    // data tables
//                    'plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css',
//                    'plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css',
//                    'plugins/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css',
                ]
            ],
            'load_js' => [
                'dir' => $this->assets,
                'js' => [

                    // draggable
                    'https://code.jquery.com/jquery-3.7.1.js',
                    'https://code.jquery.com/ui/1.14.0/jquery-ui.js',

                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
                    'plugins/jvectormap-content/world-mill.js',
                    'plugins/apexcharts/dist/apexcharts.min.js',
                    'plugins/sweetalert2/dist/sweetalert2.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js',
//                    'js/demo/dashboard.demo.js',
                    '',
//                    'plugins/masonry-layout/dist/masonry.pkgd.min.js',
//                    'plugins/select-picker/dist/picker.min.js',
//                    'plugins/jvectormap-next/jquery-jvectormap.min.js',
//                    'plugins/jvectormap-content/world-mill.js',
//                    'plugins/apexcharts/dist/apexcharts.min.js',
//                    'plugins/moment/min/moment.min.js',
//                    'plugins/bootstrap-daterangepicker/daterangepicker.js',
//                    'js/demo/dashboard.demo.js',
//                    'plugins/chart.js/dist/chart.umd.js',

                    // data tables
//                    'plugins/datatables.net/js/jquery.dataTables.min.js',
//                    'plugins/datatables.net-bs5/js/dataTables.bootstrap5.min.js',
//                    'plugins/datatables.net-buttons/js/dataTables.buttons.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.colVis.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.flash.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.html5.min.js',
//                    'plugins/datatables.net-buttons/js/buttons.print.min.js',
//                    'plugins/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js',
//                    'plugins/datatables.net-responsive/js/dataTables.responsive.min.js',
//                    'plugins/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js',


                ]
            ],
        ];

//        $this->out($this->config);

        $this->call->view(strtolower(__CLASS__) . DS . strtolower(__FUNCTION__), $data, 'main_ui');
    }

}
