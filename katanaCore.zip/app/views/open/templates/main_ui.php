<!DOCTYPE html>
<html lang="en" data-bs-theme="dark" class="bg-cover-3">
<head>
    <meta charset="utf-8">
    <title>{{_title}}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- ================== BEGIN core-css ================== -->
    <link href="{{assets_path}}css/vendor.min.css" rel="stylesheet">
    <link href="{{assets_path}}css/app.min.css" rel="stylesheet">
    <!-- ================== END core-css ================== -->

    <!-- ================== BEGIN page-css ================== -->
    {{load_css}}

<!--    <style>-->
<!--        /* ===== Scrollbar CSS ===== */-->
<!--        * {-->
<!--            --sb-track-color: var(--bs-dark);-->
<!--            --sb-thumb-color: var(--bs-theme);-->
<!--            --sb-size: 5px;-->
<!--        }-->
<!---->
<!--        *::-webkit-scrollbar {-->
<!--            width: var(--sb-size);-->
<!--        }-->
<!---->
<!--        *::-webkit-scrollbar-track {-->
<!--            background: var(--sb-track-color);-->
<!--            border-radius: 5px;-->
<!--        }-->
<!---->
<!--        *::-webkit-scrollbar-thumb {-->
<!--            background: var(--sb-thumb-color);-->
<!--            border-radius: 5px;-->
<!--        }-->
<!---->
<!--        @supports not selector(::-webkit-scrollbar) {-->
<!--            * {-->
<!--                scrollbar-color: var(--sb-thumb-color)-->
<!--                var(--sb-track-color);-->
<!--            }-->
<!--        }-->
<!--    </style>-->
    <!-- ================== END page-css ================== -->

    <link href="{{assets_path}}css/main.css" rel="stylesheet">

    <!-- ================== BEGIN core-js ================== -->
    <script src="{{assets_path}}js/vendor.min.js"></script>
    <script src="{{assets_path}}js/app.min.js"></script>
    <!-- ================== END core-js ================== -->

</head>

<div id="loader">
    <div class="spinner-border spinner-border-sm text-theme"></div>
</div>

<body class='pace-top'>
<!-- BEGIN #app -->
<div id="app" class="app app-boxed-layout bg-black bg-opacity-50 ps-25px pe-25px">

    <!-- BEGIN #content -->
    <div id="content" class="app-content-full-width">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a class="">APP</a></li>
            <li class="breadcrumb-item active text-uppercase text-light">{{_method}} <code class="ps-1"><small>&mdash; {{description}}</small></code></li>
        </ul>
        {{content}}
    </div>
    <!-- END #content -->

    <!-- BEGIN btn-scroll-top -->
    <a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
    <!-- END btn-scroll-top -->
</div>
<!-- END #app -->

<!-- ================== BEGIN page-js ================== -->
<script src="{{assets_path}}plugins/@highlightjs/cdn-assets/highlight.min.js"></script>
<script src="{{assets_path}}js/demo/highlightjs.demo.js"></script>
<!-- ================== END page-js ================== -->
<!-- Global variables START -->
<script>
    let _logoutKey = `{{_logoutKey}}`;
</script>
<!-- Global variables END -->
{{load_js}}
<script src="{{assets_path}}js/main.js"></script>
</body>
</html>
