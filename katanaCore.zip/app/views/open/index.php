
<div class="row mb-3">
    <div class="col-lg-6 col-sm-12">
        <a id="_totalBalance" class="card text-decoration-none">
            <div class="card-body d-flex align-items-center text-inverse m-5px bg-inverse bg-opacity-10">
                <div class="flex-fill">
                    <div class="mb-1 text-muted">Total User Balance</div>
                    <h2 id="jc_userBal" class="text-theme text-truncate">0</h2>
                </div>
                <div class="opacity-5">
                    <i class="fa-solid fa-money-bill-trend-up fa-4x"></i>
                </div>
            </div>
            <div class="card-arrow">
                <div class="card-arrow-top-left"></div>
                <div class="card-arrow-top-right"></div>
                <div class="card-arrow-bottom-left"></div>
                <div class="card-arrow-bottom-right"></div>
            </div>
        </a>
    </div>
    <div class="col-lg-6 col-sm-12">
        <a class="card text-decoration-none">
            <div class="card-body d-flex align-items-center text-inverse m-5px bg-inverse bg-opacity-10">
                <div class="flex-fill">
                    <div class="mb-1 text-muted">Potential Ransom <small class="text-secondary">(30%)</small></div>
                    <h2 id="jc_userRansom" class="text-danger text-truncate">~</h2>
                </div>
                <div class="opacity-5">
                    <i class="fa-solid fa-skull fa-4x text-danger"></i>
                </div>
            </div>
            <div class="card-arrow">
                <div class="card-arrow-top-left"></div>
                <div class="card-arrow-top-right"></div>
                <div class="card-arrow-bottom-left"></div>
                <div class="card-arrow-bottom-right"></div>
            </div>
        </a>
    </div>
</div>
<div class="row">
    <div class="col">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive pb-3">
                    <table id="datatableDefault" class="table table-sm table-hover text-nowrap w-100">
                        <thead>
                        <tr>
                            <th class="text-start">User</th>
                            <th class="text-start">Email</th>
                            <th class="text-start">Balance</th>
                        </tr>
                        </thead>
                        <tbody>
                        <!-- Rows will be dynamically populated -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-arrow">
                <div class="card-arrow-top-left"></div>
                <div class="card-arrow-top-right"></div>
                <div class="card-arrow-bottom-left"></div>
                <div class="card-arrow-bottom-right"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal modal-cover fade" id="userInfo">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <div class="card bg-gradient">
                    <div class="card-body">
                        <div class="d-flex fw-bold small mb-3">
                            <h4 class="flex-grow-1">User Details [<small class="text-theme user_type">&mdash;</small>]</h4>
                            <a href="#" data-toggle="card-expand" class="text-inverse text-opacity-50 text-decoration-none me-2"><i class="bi bi-fullscreen"></i></a>
                            <a href="#" data-toggle="tooltip" title="Close" data-bs-dismiss="modal" class="text-inverse text-opacity-50 text-decoration-none"><i class="bi bi-x-lg"></i></a>
                        </div>
                        <div class="row">
                            <div class="col-lg-8 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Name</label>
                                    <div class="row row-space-10">
                                        <div class="col">
                                            <input readonly class="form-control full_name" placeholder="Full Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Country</label>
                                    <div class="row row-space-10">
                                        <div class="col">
                                            <input readonly class="form-control country_base" placeholder="Country Base">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-8 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Contact</label>
                                    <div class="row row-space-10">
                                        <div class="col-6">
                                            <input readonly class="form-control phone_number" placeholder="Phone Number">
                                        </div>
                                        <div class="col-6">
                                            <input readonly class="form-control email_address" placeholder="Email Address">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Birthday</label>
                                    <div class="row row-space-10">
                                        <div class="col">
                                            <input readonly class="form-control birth_date" placeholder="Birth Date">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-10 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Address</label>
                                    <div class="row row-space-10">
                                        <div class="col-8">
                                            <input readonly class="form-control address" placeholder="Address">
                                        </div>
                                        <div class="col-4">
                                            <input readonly class="form-control city" placeholder="City">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Gender</label>
                                    <div class="row row-space-10">
                                        <div class="col">
                                            <input readonly class="form-control gender" placeholder="Gender">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Document [ <doc_type class="text-capitalize text-theme">&mdash;</doc_type> ]</label>
                                    <div class="row row-space-10">
                                        <div class="col-6 mb-3">
                                            <input readonly class="form-control doc_id" placeholder="Document ID">
                                        </div>
                                        <div class="col-6 mb-3">
                                            <button type="button" class="form-control btn btn-outline-theme doc_btn">View Document</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-12">
                                <div class="mb-3">
                                    <label class="form-label text-secondary">Card Info</label>
                                    <div class="row row-space-10">
                                        <div class="col">
                                            <input readonly class="form-control card_info" placeholder="Gender">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function _loadDocs(_id, alt) {
        // Show a loading alert
        Swal.fire({
            title: 'Loading...',
            html: '<div class="swal2-modal" style="display: flex; flex-direction: column; align-items: center;"><span class="text-secondary small">Document Type: <span class="text-info text-capitalize">' + alt + '</span></span></div>',
            showConfirmButton: false,
            allowOutsideClick: false,
            willOpen: () => {
                // Display the loading spinner while the image is being fetched
                Swal.showLoading();
            },
        });

        // Create an image object to check when the image is loaded
        const img = new Image();
        img.onload = () => {
            // Once the image is successfully loaded, update the Swal dialog
            Swal.fire({
                imageUrl: `/api/jc_docs/${_id}`,
                html: `<span class="text-secondary small">Document Type: <span class="text-info text-capitalize">${alt}</span></span>`,
                imageAlt: alt,
                showConfirmButton: false,
                customClass: {
                    image: 'swal2-image', // Apply your custom class to the image
                },
            });
        };

        img.onerror = () => {
            // Handle the case where loading the image fails
            Swal.fire({
                icon: 'error',
                title: 'Error loading image',
                text: 'Unable to fetch image. Please try again later.',
                showConfirmButton: true,
                confirmButtonText: 'Continue',
                customClass: {
                    confirmButton: 'btn btn-outline-theme',
                }
            });
        };

        // Set the src attribute to start fetching the image
        img.src = `/api/jc_docs/${_id}`;
    }

    $(document).ready(function() {

        try {
            $('[data-toggle="tooltip"]').tooltip();
        } catch (e) {
            console.log(`Error: ${e}`);
        }

        // Define formatter for currency
        const currencyFormatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'PHP',
            minimumFractionDigits: 2
        });

        let
            manualReload = false,
            sortTriggered = false;

        function _loader(_type = 'hide') {
            switch (_type) {
                case 'show':
                    if (sortTriggered && !manualReload) {
                        $('#loader').fadeIn('fast');
                    }
                    break;

                default:
                    if (sortTriggered && !manualReload) {
                        $('#loader').fadeOut('fast');
                        sortTriggered = false;
                    }
                    break;
            }

        }

        // Initialize DataTable with server-side processing
        const table = $('#datatableDefault').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 25, // Set the default number of rows per page to 25
            order: [[3, 'desc']], // Initial sort order set to 'balance' column, descending
            ajax: function(data, callback, settings) {


                _loader('show');

                console.log('DataTables request data:', data);

                const page = Math.ceil(data.start / data.length) + 1;
                const limit = data.length;

                // Extract sorting information from the DataTables request
                const sortColumnIndex = data.order && data.order[0] ? data.order[0].column : 3; // Default to 3
                const sortDirection = data.order && data.order[0] ? data.order[0].dir : 'desc'; // Default to 'desc'
                const sortColumn = data.columns && data.columns[sortColumnIndex] ? data.columns[sortColumnIndex].data : 'balance'; // Default to 'balance'

                const searchValue = data.search && data.search.value ? data.search.value : '';

                console.log('Sort column:', sortColumn);
                console.log('Sort direction:', sortDirection);
                console.log('Search value:', searchValue);

                $.ajax({
                    url: '/api/jc_users',
                    method: 'GET',
                    data: {
                        page: page,
                        limit: limit,
                        sortColumn: sortColumn,
                        sortDirection: sortDirection,
                        search: searchValue // Include search value in the request
                    },
                    success: function(response) {
                        $('h2#jc_userBal').text(currencyFormatter.format(response.totalBalance));

                        let ransom = (Number(response.totalBalance) * 0.30);
                        $('h2#jc_userRansom').text(currencyFormatter.format(ransom));

                        // Format data for DataTables
                        const formattedData = response.records.map((record, index) => ({
                            _id: record._id,
                            hash: record.hash,
                            user: `${record.user} <small class="sm text-secondary">[${record.account_id}]</small> ${(record.info.user_info.doc_id_no ? '<small class="sm text-theme">*</small>' : '')}`,
                            account_id: record.account_id,
                            balance: currencyFormatter.format(record.balance),
                            info: record.info,
                        }));

                        // Provide data to DataTables
                        callback({
                            draw: data.draw,
                            recordsTotal: response.totalRecords,
                            recordsFiltered: response.totalRecords,
                            data: formattedData
                        });


                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('Error with data fetch:', errorThrown);
                    },
                    complete: function(){
                        manualReload = false; // Reset manualReload after AJAX call
                        _loader('hide');
                    }
                });
            },
            columns: [
                { data: 'user' },
                { data: 'info.user_info.email' },
                { data: 'balance' }
            ],
            columnDefs: [
                {
                    targets: [0],
                    className: 'text-capitalize'
                },
                {
                    targets: [2],
                    className: 'text-theme'
                },
            ],
        });

        table.on('order.dt', function() {
            sortTriggered = true;
        });

        $('#_totalBalance').on('click', function() {
            manualReload = true;
            table.ajax.reload(null, false); // Reload data without resetting pagination
        });

        $('#datatableDefault tbody').on('click', 'tr', function() {
            const data = table.row(this).data();
            console.log(data);

            $('#loader').fadeIn('fast', function () {
                $('#userInfo').modal({
                    backdrop: 'static',
                    keyboard: false,
                    show: false // Initialize the modal but don't show it immediately
                });
                $("#userInfo").modal('show');
                let
                    _userInfo = data.info.user_info,
                    _docImg = _userInfo.image_filename ?? false,// image_filename
                    _docType = _userInfo.doc_type ? (_userInfo.doc_type).replace("_"," ") : '&mdash;',
                    _infoCard = $('#userInfo.modal .card-body');

                _infoCard.find('h4 small.user_type:eq(0)').text(_userInfo.idno ?? 'NA');
                _infoCard.find('input.full_name:eq(0)').val(_userInfo.fullname ?? 'NA');
                _infoCard.find('input.country_base:eq(0)').val(_userInfo.tagtype ?? 'NA');
                _infoCard.find('input.phone_number:eq(0)').val(_userInfo.conno ?? 'NA');
                _infoCard.find('input.email_address:eq(0)').val(_userInfo.email ?? 'NA');
                _infoCard.find('input.birth_date:eq(0)').val(_userInfo.bday ?? 'NA');
                _infoCard.find('input.address:eq(0)').val(_userInfo.address ?? 'NA');
                _infoCard.find('input.city:eq(0)').val(_userInfo.cityname ?? 'NA');
                _infoCard.find('input.gender:eq(0)').val(_userInfo.gender ?? 'NA');
                _infoCard.find('input.doc_id:eq(0)').val(_userInfo.doc_id_no ?? 'NA');
                _infoCard.find('input.card_info:eq(0)').val(_userInfo.cardno ?? 'NA');
                _infoCard.find('label doc_type:eq(0)').html(_docType);

                if (!(_userInfo.doc_id_no)) {
                    _infoCard
                        .find('button.doc_btn:eq(0)')
                        .addClass('disabled')
                        .attr('onclick', false);
                } else {
                    _infoCard
                        .find('button.doc_btn:eq(0)')
                        .removeClass('disabled')
                        .attr('onclick', `_loadDocs('${_docImg}','${_docType}')`);
                }


                $('#loader').fadeOut('slow');
            });

            // For modal display or further processing, you can use:
            // showModal(data); // Assuming showModal is a function to display a modal
        });
    });
</script>