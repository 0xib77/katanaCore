<?php
//header('Content-Type: application/json');
$code = ($code ?? "500");
http_response_code($code);
$status = [
    'code' => "{$code} error",
    'error' => 'Uncaught Exception Encountered',
    'status' => [
        'Exception Class' => get_class($exception ?? ''),
        'Error Message' => $message ?? 'Uncaught Exception Encountered',
        'File' => $exception->getFile(),
        'Line Number' => $exception->getLine(),
    ],
    'stack_trace' => [],
];

$stack_trace = "";

foreach ($exception->getTrace() as $error) {
    if (isset($error['file'])) {
        $status['stack_trace'][] = [
            'File' => $error['file'],
            'Line' => $error['line'],
            'Function' => $error['function'],
        ];

        $stack_trace .= <<<_Li
<li class="list-group-item">
    <table class="small">
        <tr>
            <td class="text-muted">File</td>
            <td class="ps-2">
                <code class="text-danger">{$error['file']}</code>
            </td>
        </tr>
        <tr>
            <td class="text-muted">Line</td>
            <td class="ps-2">
                <code class="text-danger">{$error['line']}</code>
            </td></tr>
        <tr>
            <td class="text-muted">Function</td>
            <td class="ps-2">
                <code class="text-danger">{$error['function']}</code>
            </td></tr>
    </table>
</li>
_Li;
    }
}
//echo json_encode($status, JSON_PRETTY_PRINT); exit;

?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <title><?=$status['code']?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- ================== BEGIN core-css ================== -->
    <link href="/public/assets/css/vendor.min.css" rel="stylesheet">
    <link href="/public/assets/css/app.min.css" rel="stylesheet">
    <!-- ================== END core-css ================== -->
    <link href="/public/assets/css/main.css" rel="stylesheet">

</head>
<body class='pace-top'>
<!-- BEGIN #app -->
<div id="app" class="app app-boxed-layout app-sidebar-collapsed">
    <!-- BEGIN #header -->
    <div id="header" class="app-header">

        <!-- BEGIN desktop-toggler -->
        <div class="desktop-toggler">
            <button type="button" class="menu-toggler" data-toggle-class="app-sidebar-collapsed" data-dismiss-class="app-sidebar-toggled" data-toggle-target=".app">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>
        <!-- BEGIN desktop-toggler -->

        <!-- BEGIN mobile-toggler -->
        <div class="mobile-toggler">
            <button type="button" class="menu-toggler" data-toggle-class="app-sidebar-mobile-toggled" data-toggle-target=".app">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>
        <!-- END mobile-toggler -->



        <!-- BEGIN brand -->
        <div class="brand">
            <a href="index.html" class="brand-logo">
					<span class="brand-img">
						<span class="brand-img-text text-danger">X</span>
					</span>
                <span class="brand-text mb-0 lh-sm">Exception Error</span>
            </a>
        </div>
        <!-- END brand -->

        <!-- BEGIN menu -->
        <div class="menu"></div>
        <!-- END menu -->

        <!-- BEGIN menu-search -->
        <form class="menu-search" method="POST" name="header_search_form">
            <div class="menu-search-container">
                <div class="menu-search-icon"><i class="bi bi-search"></i></div>
                <div class="menu-search-input">
                    <input type="text" class="form-control form-control-lg" placeholder="Search menu...">
                </div>
                <div class="menu-search-icon">
                    <a href="#" data-toggle-class="app-header-menu-search-toggled" data-toggle-target=".app"><i class="bi bi-x-lg"></i></a>
                </div>
            </div>
        </form>
        <!-- END menu-search -->
    </div>
    <!-- END #header -->

    <!-- BEGIN #sidebar -->
    <div id="sidebar" class="app-sidebar">
        <!-- BEGIN scrollbar -->
        <div class="app-sidebar-content" data-scrollbar="true" data-height="100%">
            <!-- BEGIN menu -->
            <div class="menu">
                <div class="menu-header">Status</div>
                <div class="menu-item active">
                    <a href="javascript:document.location.reload()" class="menu-link">
                        <span class="menu-icon"><i class="bi bi-bug-fill text-danger"></i></span>
                        <span class="menu-text">Error Status</span>
                    </a>
                </div>
            </div>
            <!-- END menu -->
            <div class="p-3 px-4 mt-auto">
                <!--                <a href="../../documentation/index.html" class="btn d-block btn-outline-theme">-->
                <!--                    <i class="fa fa-code-branch me-2 ms-n2 opacity-5"></i> Documentation-->
                <!--                </a>-->
                <span href="#" class="text-theme disabled small">
                    <i class="fa fa-bolt-lightning ms-n2 opacity-5 text-theme"></i> 2077KatanaSec
                </span>
            </div>
        </div>
        <!-- END scrollbar -->
    </div>
    <!-- END #sidebar -->

    <!-- BEGIN mobile-sidebar-backdrop -->
    <button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
    <!-- END mobile-sidebar-backdrop -->

    <!-- BEGIN #content -->
    <div id="content" class="app-content">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a class="">APP</a></li>
            <li class="breadcrumb-item active text-danger text-light"><?=$status['error']?></li>
        </ul>

        <div class="row">
            <div class="col">
                <h1 class="page-header">
                    <error class="text-danger"><?=ucfirst($status['status']['Exception Class'])?></error>
                </h1>

                <div class="card mb-4">
                    <div class="m-1 bg-black bg-opacity-50">
                        <div class="card-header fw-bold small d-flex bg-theme bg-opacity-50">
                            <span class="flex-grow-1"><?=ucfirst($status['status']['Error Message'])?></span>
                            <a href="#" data-toggle="card-expand" class="text-white text-opacity-50 text-decoration-none"><i class="fa fa-fw fa-expand"></i> EXPAND</a>
                        </div>
                        <div class="card-header p-0">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <table class="small">
                                        <tr>
                                            <td class="text-muted">File</td>
                                            <td class="ps-2">
                                                <code class="text-lime"><?=$status['status']['File']?></code>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Line</td>
                                            <td class="ps-2">
                                                <code class="text-lime"><?=$status['status']['Line Number']?></code>
                                            </td></tr>
                                    </table>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="m-1 bg-black bg-opacity-50">
                        <div class="card-header fw-bold small d-flex bg-danger bg-opacity-50">
                            <span class="flex-grow-1">Stack Trace</span>
                            <a href="#" data-toggle="card-expand" class="text-white text-opacity-50 text-decoration-none"><i class="fa fa-fw fa-expand"></i> EXPAND</a>
                        </div>
                        <div class="card-header p-0">
                            <ul class="list-group list-group-flush">
                                <?=$stack_trace?>
                            </ul>
                        </div>
                    </div>
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- END #content -->

    <!-- BEGIN theme-panel -->
    <div class="app-theme-panel">
        <div class="app-theme-panel-container">
            <a href="javascript:;" data-toggle="theme-panel-expand" class="app-theme-toggle-btn"><i class="bi bi-sliders"></i></a>
            <div class="app-theme-panel-content">
                <div class="small fw-bold text-inverse mb-1">Display Mode</div>
                <div class="card mb-3">
                    <!-- BEGIN card-body -->
                    <div class="card-body p-2">
                        <div class="row gx-2">
                            <div class="col-6">
                                <a href="javascript:;" data-toggle="theme-mode-selector" data-theme-mode="dark" class="app-theme-mode-link active">
                                    <div class="img"><img src="/public/assets/img/mode/dark.jpg" class="object-fit-cover" height="76" width="76" alt="Dark Mode"></div>
                                    <div class="text">Dark</div>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="javascript:;" data-toggle="theme-mode-selector" data-theme-mode="light" class="app-theme-mode-link">
                                    <div class="img"><img src="/public/assets/img/mode/light.jpg" class="object-fit-cover" height="76" width="76" alt="Light Mode"></div>
                                    <div class="text">Light</div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- END card-body -->

                    <!-- BEGIN card-arrow -->
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                    <!-- END card-arrow -->
                </div>

                <div class="small fw-bold text-inverse mb-1">Theme Color</div>
                <div class="card mb-3">
                    <!-- BEGIN card-body -->
                    <div class="card-body p-2">
                        <!-- BEGIN theme-list -->
                        <div class="app-theme-list">
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-pink" data-theme-class="theme-pink" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Pink">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-red" data-theme-class="theme-red" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Red">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-warning" data-theme-class="theme-warning" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Orange">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-yellow" data-theme-class="theme-yellow" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Yellow">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-lime" data-theme-class="theme-lime" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Lime">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-green" data-theme-class="theme-green" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Green">&nbsp;</a></div>
                            <div class="app-theme-list-item active"><a href="javascript:;" class="app-theme-list-link bg-teal" data-theme-class="" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Default">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-info" data-theme-class="theme-info"  data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cyan">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-primary" data-theme-class="theme-primary"  data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Blue">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-purple" data-theme-class="theme-purple" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Purple">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-indigo" data-theme-class="theme-indigo" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Indigo">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-gray-100" data-theme-class="theme-gray-200" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Gray">&nbsp;</a></div>
                        </div>
                        <!-- END theme-list -->
                    </div>
                    <!-- END card-body -->

                    <!-- BEGIN card-arrow -->
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                    <!-- END card-arrow -->
                </div>

                <div class="small fw-bold text-inverse mb-1">Theme Cover</div>
                <div class="card">
                    <!-- BEGIN card-body -->
                    <div class="card-body p-2">
                        <!-- BEGIN theme-cover -->
                        <div class="app-theme-cover">
                            <div class="app-theme-cover-item active">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-1.jpg);" data-theme-cover-class="" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Default">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-2.jpg);" data-theme-cover-class="bg-cover-2" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 2">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-3.jpg);" data-theme-cover-class="bg-cover-3" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 3">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-4.jpg);" data-theme-cover-class="bg-cover-4" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 4">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-5.jpg);" data-theme-cover-class="bg-cover-5" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 5">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-6.jpg);" data-theme-cover-class="bg-cover-6" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 6">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-7.jpg);" data-theme-cover-class="bg-cover-7" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 7">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-8.jpg);" data-theme-cover-class="bg-cover-8" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 8">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/public/assets/img/cover/cover-thumb-9.jpg);" data-theme-cover-class="bg-cover-9" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 9">&nbsp;</a>
                            </div>
                        </div>
                        <!-- END theme-cover -->
                    </div>
                    <!-- END card-body -->

                    <!-- BEGIN card-arrow -->
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                    <!-- END card-arrow -->
                </div>
            </div>
        </div>
    </div>
    <!-- END theme-panel -->
    <!-- BEGIN btn-scroll-top -->
    <a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
    <!-- END btn-scroll-top -->
</div>
<!-- END #app -->

<!-- ================== BEGIN core-js ================== -->
<script src="/public/assets/js/vendor.min.js"></script>
<script src="/public/assets/js/app.min.js"></script>
<!-- ================== END core-js ================== -->

<!-- ================== BEGIN page-js ================== -->
<script src="/public/assets/plugins/@highlightjs/cdn-assets/highlight.min.js"></script>
<script src="/public/assets/js/demo/highlightjs.demo.js"></script>
<!-- ================== END page-js ================== -->

<script>
    $(document).ready(function() {

        try {
            $('#content').fadeIn('slow', function () {
                try {
                    handleRenderChart();
                    handleRenderMap();
                } catch (e) {
                    console.log(`Oops: ${e}`);
                }
            });
        } catch (e) {
            console.log(`Error: ${e}`);
        }

    });
</script>
</body>
</html>

