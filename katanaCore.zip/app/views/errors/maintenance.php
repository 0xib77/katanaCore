<?php
//header('Content-Type: application/json');
$code = ($code ?? "1337");
http_response_code($code);
$status = [
    'code' => 'Black Ops Going Dark',
    'status' => $heading ?? 'Oops!',
    'message' => $message ?? 'Error occurred',
];
//echo json_encode($status, JSON_PRETTY_PRINT); exit;
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="dark" class="bg-cover-7">
<head>
    <meta charset="utf-8">
    <title><?=$status['status'];?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- ================== BEGIN core-css ================== -->
    <link href="/public/assets/css/vendor.min.css" rel="stylesheet">
    <link href="/public/assets/css/app.min.css" rel="stylesheet">
    <!-- ================== END core-css ================== -->
    <link href="/public/assets/css/main.css" rel="stylesheet">

</head>
<body class='pace-top'>
<!-- BEGIN #app -->
<div id="app" class="app app-full-height app-without-header">
    <!-- BEGIN error -->
    <div class="error-page">
        <!-- BEGIN error-page-content -->
        <div class="error-page-content">
            <div class="card mb-5 mx-auto">
                <div class="card-body">
                    <div class="card p-4 bg-black bg-opacity-50">
                        <div class="error-code text-uppercase text-theme text-opacity-100"><?=$status['status'];?></div>
                        <div class="card-body p-0 mb-0">
                            <h1 class="text-opacity-75"><?=$status['code'];?></h1>
                            <!--            <h3>We can't seem to find the page you're looking for</h3>-->
                            <h3 class="text-secondary text-opacity-35"><?=$status['message'];?></h3>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
                <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                </div>
            </div>

        </div>
        <!-- END error-page-content -->
    </div>
    <!-- END error -->
    <!-- BEGIN btn-scroll-top -->
    <a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
    <!-- END btn-scroll-top -->
</div>
<!-- END #app -->

<!-- ================== BEGIN core-js ================== -->
<script src="/public/assets/js/vendor.min.js"></script>
<script src="/public/assets/js/app.min.js"></script>
<!-- ================== END core-js ================== -->


</body>
</html>