<?php
header('Content-Type: application/json');
$code = ($code ?? "500");
http_response_code($code);
$status = [
    'code' => 'DB Error',
    'status' => $heading ?? 'Oops!',
    'message' => $message ?? 'Error occurred',
];
echo json_encode($status, JSON_PRETTY_PRINT); exit;