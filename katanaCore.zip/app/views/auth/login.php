<div class="login">
    <!-- BEGIN login-content -->
    <div class="login-content">
        <form class="_login" action="" method="POST" name="login_form">
            <h1 class="text-center">Authenticate</h1>
            <div class="text-inverse text-opacity-50 text-center mb-4">
                For your protection, please verify your identity.
            </div>
            <div class="mb-3">
                <label class="form-label">Username / Email Address <span class="text-danger">*</span></label>
                <input required maxlength="15" tabindex="1" type="text" name="_user" class="form-control form-control-lg bg-inverse bg-opacity-5" value="" placeholder="">
            </div>
            <div class="mb-3">
                <div class="d-flex">
                    <label class="form-label">Password <span class="text-danger">*</span></label>
                    <a href="/forgot-pass" class="ms-auto text-inverse text-decoration-none text-opacity-50">Forgot password?</a>
                </div>
                <input required maxlength="25" tabindex="2" type="password" name="_pass" class="form-control form-control-lg bg-inverse bg-opacity-5" value="" placeholder="">
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <input class="form-check-input" name="_save" type="checkbox" value="_user" id="customCheck1">
                    <label class="form-check-label" for="customCheck1">Remember me</label>
                </div>
            </div>
            <button type="submit" class="btn btn-outline-theme btn-lg d-block w-100 fw-500 mb-3">Sign In</button>
            <button onclick="discord_login()" type="button" class="btn btn-outline-discord btn-lg d-block w-100 fw-500 mb-3">
                <i class="fab fa-lg fa-fw me-2 fa-discord"></i> Login with Discord
            </button>
            <strike>
                <div class="text-center text-inverse text-opacity-50">
                    Don't have an account yet? <a href="/sign-up">Sign up</a>.
                </div>
            </strike>
        </form>
    </div>
    <!-- END login-content -->
</div>
<script>
    function discord_login() {

        // clear inputs
        $('form._login input').val('');

        let
            _discord = `{{discord_state}}`;

        Swal.fire({
            title: 'Logging-in via Discord',
            text: 'Processing request...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: '/auth/discord/login',
            method: 'POST',
            data: {
                state: _discord
            },
            success: function (response) {

                if ('status' in response && response.status === 'success') {

                    if ('redirect' in response) {
                        document.location.href = response.redirect;
                    } else {
                        Swal.fire({
                            title: 'Oops!',
                            html: `Unexpected response`,
                            icon: 'warning',
                            confirmButtonText: 'Try again later',
                            timer: 5000,
                            customClass: {
                                confirmButton: 'btn btn-outline-warning',
                            }
                        });
                    }

                } else {
                    Swal.fire({
                        title: 'Oops!',
                        html: `Unexpected login response`,
                        icon: 'info',
                        confirmButtonText: 'Try again later',
                        timer: 5000,
                        customClass: {
                            confirmButton: 'btn btn-outline-warning',
                        }
                    }).then(function () {
                        document.location.reload();
                    });
                }


            },
            error: function (error) {

                let _error = false;
                if ('responseJSON' in error && typeof error.responseJSON !== 'undefined' && 'error' in error.responseJSON && 'message' in error.responseJSON.error) {
                    _error = error.responseJSON.error.message;
                } else {
                    _error = 'An error occurred, Try again later';
                }
                $('form[name=login_form] input.form-control').addClass('is-invalid');
                Swal.fire({
                    title: 'Oops!',
                    html: _error,
                    icon: 'error',
                    confirmButtonText: 'Continue',
                    customClass: {
                        confirmButton: 'btn btn-secondary',
                    }
                });
            }
        });

        console.log(`login with discord: ${_discord}`);
    }

    $(document).ready(function() {

        $('input[name=_user], input[name=_pass]').on('focus click keyup', function (e) {
            if ($(this).hasClass('is-invalid')) {
                $(this).val('');
            }
            $(this).removeClass('is-invalid');
        });

        $('form[name=login_form]').on('submit', function (e) {
            e.preventDefault();
            // check user, pass
            let
                _error = null,
                _login = {},
                _login_array = $(this).serializeArray();

            $(_login_array).each(function (x, input) {

                let _input = $(`input[name=${input['name']}]`);

                _input.removeClass('is-invalid');
                _input.removeAttr('placeholder');

                switch (input['name']) {
                    case "_user":
                    case "_pass":
                        if (input['value'].length <= 0) {
                            _input.addClass('is-invalid');
                            $(`input[name=${input['name']}]`).focus();
                            return false;
                        } else if (input['value'].length <= 4) {
                            _input.addClass('is-invalid');

                            switch (input['name']) {
                                case "_user":
                                    _error = "A valid username is required";
                                    _input.attr('placeholder', 'Please enter a valid username');
                                    break;

                                case "_pass":
                                    _error = "A valid password is required";
                                    _input.attr('placeholder', 'Please enter a valid password');
                                    break;
                            }

                            Swal.fire({
                                title: 'Oops!',
                                html: `<span>${_error}</span>`,
                                icon: 'error',
                                confirmButtonText: 'Continue',
                                customClass: {
                                    confirmButton: 'btn btn-outline-theme',
                                }
                            });

                            return false;
                        }

                        break;
                }

                if (_error === null) {
                    _login[input['name']] = input['value'];
                }

            });

            if (_error === null && Object.entries(_login).length >= 2) {

                Swal.fire({
                    title: 'Logging in',
                    text: 'Please wait while we verify your account.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                console.log(_login);

                $.ajax({
                    url: '/api/login',
                    method: 'POST',
                    data: _login,
                    success: function (response) {

                        console.log(response);
                        if ('status' in response && response.status === 'success') {
                            $('form[name=login_form] input.form-control').addClass('is-valid');

                            Swal.fire({
                                title: 'Success',
                                html: `Account authenticated, redirecting...`,
                                icon: 'success',
                                showConfirmButton: false,
                                timer: 1000,
                                allowOutsideClick: false
                            }).then((action) => {
                                if (action.dismiss === Swal.DismissReason.cancel) {
                                    document.location.reload();
                                }

                                if ('next_url' in response) {
                                    document.location.href=response.next_url;
                                } else {
                                    document.location.href='/dashboard';
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Oops!',
                                html: `Unexpected login response`,
                                icon: 'info',
                                confirmButtonText: 'Try again later',
                                timer: 5000,
                                customClass: {
                                    confirmButton: 'btn btn-outline-warning',
                                }
                            }).then(function () {
                               document.location.reload();
                            });
                        }


                    },
                    error: function (error) {
                        let _error = false;
                        if ('responseJSON' in error && typeof error.responseJSON !== 'undefined' && 'error' in error.responseJSON && 'message' in error.responseJSON.error) {
                            _error = error.responseJSON.error.message;
                        } else {
                            _error = 'An error occurred, Try again later';
                        }
                        $('form[name=login_form] input.form-control').addClass('is-invalid');
                        Swal.fire({
                            title: 'Oops!',
                            html: _error,
                            icon: 'error',
                            confirmButtonText: 'Continue',
                            customClass: {
                                confirmButton: 'btn btn-secondary',
                            }
                        });
                    }
                });

            }

        });

    });
</script>