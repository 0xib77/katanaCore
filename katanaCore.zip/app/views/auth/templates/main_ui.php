<!DOCTYPE html>
<html lang="en" data-bs-theme="dark" class="bg-cover-6">
<head>
    <meta charset="utf-8">
    <title>{{_title}}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- ================== BEGIN core-css ================== -->
    <link href="{{assets_path}}css/vendor.min.css" rel="stylesheet">
    <link href="{{assets_path}}css/app.min.css" rel="stylesheet">
    <!-- ================== END core-css ================== -->

    <!-- ================== BEGIN page-css ================== -->
    {{load_css}}
    <!-- ================== END page-css ================== -->

    <link href="{{assets_path}}css/main.css" rel="stylesheet">

    <!-- ================== BEGIN core-js ================== -->
    <script src="{{assets_path}}js/vendor.min.js"></script>
    <script src="{{assets_path}}js/app.min.js"></script>
    <!-- ================== END core-js ================== -->

</head>
<body class='pace-top'>
<!-- BEGIN #app -->
<div id="app" class="app app-full-height app-without-header">
    <!-- BEGIN login -->
    {{content}}
    <!-- END login -->
    <!-- BEGIN btn-scroll-top -->
    <a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
    <!-- END btn-scroll-top -->
</div>
<!-- END #app -->

{{load_js}}
<script src="{{assets_path}}js/main.js"></script>

</body>
</html>
