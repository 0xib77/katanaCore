<?php
$links = json_decode((file_get_contents("https://bdo-dash.2077.ws/api/links") ?? []), true);
$randomIndex = array_rand($links);
$picked = $links[$randomIndex];
$html = <<<_HTML
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Loader</title>
</head>
<style>
    img.center {

        display: block;

        margin-left: auto;

        margin-right: auto;

    }
</style>
<body>
<!--<img src=".img/" alt="BDO" class="center">-->
<p style="text-align: center">You will be redirected in <span id="counter">0</span> second(s).</p>
</body>
</html>
<script type="text/javascript">
    function countdown() {
        var i = document.getElementById('counter');
        if (parseInt(i.innerHTML) <= 0) {
            location.href = '{$picked}';
        }
        if (parseInt(i.innerHTML) != 0) {
            i.innerHTML = parseInt(i.innerHTML) - 1;
        }
    }
    setInterval(function () {
        countdown();
    }, 500);
</script>
_HTML;
echo $html;