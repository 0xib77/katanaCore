var lineChart;
var lineChart2;

$(document).ready(function () {

    var handleRenderChartJs = function() {
        Chart.defaults.font.family = app.font.bodyFontFamily;
        Chart.defaults.font.size = 12;
        Chart.defaults.color = app.color.bodyColor;
        Chart.defaults.borderColor = app.color.borderColor;
        Chart.defaults.plugins.legend.display = false;
        Chart.defaults.plugins.tooltip.padding = { left: 8, right: 12, top: 8, bottom: 8 };
        Chart.defaults.plugins.tooltip.cornerRadius = 8;
        Chart.defaults.plugins.tooltip.titleMarginBottom = 6;
        Chart.defaults.plugins.tooltip.color = app.color.componentBg;
        Chart.defaults.plugins.tooltip.multiKeyBackground = app.color.componentColor;
        Chart.defaults.plugins.tooltip.backgroundColor = app.color.componentColor;
        Chart.defaults.plugins.tooltip.titleFont.family = app.font.bodyFontFamily;
        Chart.defaults.plugins.tooltip.titleFont.weight = app.font.bodyFontWeight;
        Chart.defaults.plugins.tooltip.footerFont.family = app.font.bodyFontFamily;
        Chart.defaults.plugins.tooltip.displayColors = true;
        Chart.defaults.plugins.tooltip.boxPadding = 6;
        Chart.defaults.scale.grid.color = app.color.borderColor;
        Chart.defaults.scale.beginAtZero = true;
        Chart.defaults.backgroundColor = '#b5b5b5';
        Chart.defaults.borderColor = '#b5b5b5';

        var ctx = document.getElementById('lineChart');


        lineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['May', 'Jun', 'Jul', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    color: 'gray',
                    borderColor: 'gray',
                    borderWidth: 3,
                    pointBackgroundColor: app.color.componentBg,
                    pointBorderWidth: 1.5,
                    pointRadius: 4,
                    pointHoverBackgroundColor: 'gray',
                    pointHoverBorderColor: 'gray',
                    pointHoverRadius: 7,
                    label: 'New Customers',
                    data: [2, 3, 1, 5, 18, 9]
                },{
                    color: 'orange',
                    backgroundColor: 'orange',
                    borderColor: 'orange',
                    borderWidth: 3,
                    pointBackgroundColor: app.color.componentBg,
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverBackgroundColor: app.color.componentBg,
                    pointHoverBorderColor: 'orange',
                    pointHoverRadius: 6,
                    pointHoverBorderWidth: 2,
                    label: 'Returning Customers',
                    data: [5, 1, 3, 10, 26, 13]
                }]
            }
        });

        var ctx2 = document.getElementById('lineChart2');

        lineChart2 = new Chart(ctx2, {
            type: 'line',
            data: {
                labels: ['May', 'Jun', 'Jul', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    color: 'gray',
                    borderColor: 'gray',
                    borderWidth: 3,
                    pointBackgroundColor: app.color.componentBg,
                    pointBorderWidth: 1.5,
                    pointRadius: 4,
                    pointHoverBackgroundColor: 'gray',
                    pointHoverBorderColor: 'gray',
                    pointHoverRadius: 7,
                    label: 'New Customers',
                    data: [2, 3, 1, 5, 18, 9]
                },{
                    color: 'orange',
                    backgroundColor: 'orange',
                    borderColor: 'orange',
                    borderWidth: 3,
                    pointBackgroundColor: app.color.componentBg,
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverBackgroundColor: app.color.componentBg,
                    pointHoverBorderColor: 'orange',
                    pointHoverRadius: 6,
                    pointHoverBorderWidth: 2,
                    label: 'Completed Shipments',
                    data: [5, 1, 3, 10, 26, 16]
                },{
                    color: '#3385ff',
                    backgroundColor: '#3385ff',
                    borderColor: '#3385ff',
                    borderWidth: 3,
                    pointBackgroundColor: app.color.componentBg,
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverBackgroundColor: app.color.componentBg,
                    pointHoverBorderColor: '#3385ff',
                    pointHoverRadius: 6,
                    pointHoverBorderWidth: 2,
                    label: 'Filled Customers',
                    data: [9, 12, 8, 16, 19, 13]
                }]
            }
        });
    };

});

/* Controller
------------------------------------------------ */
document.addEventListener('DOMContentLoaded', function() {
    handleRenderChartJs();

    document.addEventListener('theme-reload', function() {
        lineChart.destroy();
        lineChart2.destroy();
        handleRenderChartJs();
    });
});

function handleRenderChartJs() {
    // Your function logic for rendering the Chart.js chart goes here
}