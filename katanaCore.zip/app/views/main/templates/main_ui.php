<!DOCTYPE html>
<html lang="en" data-bs-theme="dark" class="bg-cover-3">
<head>
    <meta charset="utf-8">
    <title>{{_title}}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- ================== BEGIN core-css ================== -->
    <link href="{{assets_path}}css/vendor.min.css" rel="stylesheet">
    <link href="{{assets_path}}css/app.min.css" rel="stylesheet">
    <!-- ================== END core-css ================== -->

    <!-- ================== BEGIN page-css ================== -->
    {{load_css}}

<!--    <style>-->
<!--        /* ===== Scrollbar CSS ===== */-->
<!--        * {-->
<!--            --sb-track-color: var(--bs-dark);-->
<!--            --sb-thumb-color: var(--bs-theme);-->
<!--            --sb-size: 5px;-->
<!--        }-->
<!---->
<!--        *::-webkit-scrollbar {-->
<!--            width: var(--sb-size);-->
<!--        }-->
<!---->
<!--        *::-webkit-scrollbar-track {-->
<!--            background: var(--sb-track-color);-->
<!--            border-radius: 5px;-->
<!--        }-->
<!---->
<!--        *::-webkit-scrollbar-thumb {-->
<!--            background: var(--sb-thumb-color);-->
<!--            border-radius: 5px;-->
<!--        }-->
<!---->
<!--        @supports not selector(::-webkit-scrollbar) {-->
<!--            * {-->
<!--                scrollbar-color: var(--sb-thumb-color)-->
<!--                var(--sb-track-color);-->
<!--            }-->
<!--        }-->
<!--    </style>-->
    <!-- ================== END page-css ================== -->

    <link href="{{assets_path}}css/main.css" rel="stylesheet">
    <style>
        .hljs * {
            user-select: unset !important;
        }
    </style>

    <!-- ================== BEGIN core-js ================== -->
    <script src="{{assets_path}}js/vendor.min.js"></script>
    <script src="{{assets_path}}js/app.min.js"></script>
    <!-- ================== END core-js ================== -->

</head>

<div id="loader">
    <div class="spinner-border spinner-border-sm text-theme"></div>
</div>

<body class='pace-top bg-black bg-opacity-50'>
<!-- BEGIN #app -->
<!--<div id="app" class="app app-boxed-layout bg-black bg-opacity-50">-->
<div id="app" class="app ">
    <!-- BEGIN #header -->
    <div id="header" class="app-header">

        <!-- BEGIN desktop-toggler -->
        <div class="desktop-toggler">
            <button type="button" class="menu-toggler" data-toggle-class="app-sidebar-collapsed" data-dismiss-class="app-sidebar-toggled" data-toggle-target=".app">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>
        <!-- BEGIN desktop-toggler -->

        <!-- BEGIN mobile-toggler -->
        <div class="mobile-toggler">
            <button type="button" class="menu-toggler" data-toggle-class="app-sidebar-mobile-toggled" data-toggle-target=".app">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>
        <!-- END mobile-toggler -->



        <!-- BEGIN brand -->
        <div class="brand">
            <a href="#powered_by_2077KatanaSec" class="brand-logo">
					<span class="brand-img">
						<span class="brand-img-text text-theme">{{sys_acronym}}</span>
					</span>
                <span class="brand-text">{{sys_name}}</span>
            </a>
        </div>
        <!-- END brand -->

        <!-- BEGIN menu -->
        <div class="menu">
            <div class="menu-item dropdown">
                <a href="#" data-toggle-class="app-header-menu-search-toggled" data-toggle-target=".app" class="menu-link">
                    <div class="menu-icon"><i class="bi bi-search nav-icon"></i></div>
                </a>
            </div>
            <div class="menu-item dropdown dropdown-mobile-full">
                <a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
                    <div class="menu-icon"><i class="bi bi-grid-3x3-gap nav-icon"></i></div>
                </a>
                <div class="dropdown-menu fade dropdown-menu-end w-300px text-center p-0 mt-1">
<!--                    <div class="row row-grid gx-0">-->
<!--                        <div class="col-4">-->
<!--                            <a href="email_inbox.html" class="dropdown-item text-decoration-none p-3 bg-none">-->
<!--                                <div class="position-relative">-->
<!--                                    <i class="bi bi-circle-fill position-absolute text-theme top-0 mt-n2 me-n2 fs-6px d-block text-center w-100"></i>-->
<!--                                    <i class="bi bi-envelope h2 opacity-5 d-block my-1"></i>-->
<!--                                </div>-->
<!--                                <div class="fw-500 fs-10px text-inverse">INBOX</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="col-4">-->
<!--                            <a href="pos_customer_order.html" target="_blank" class="dropdown-item text-decoration-none p-3 bg-none">-->
<!--                                <div><i class="bi bi-hdd-network h2 opacity-5 d-block my-1"></i></div>-->
<!--                                <div class="fw-500 fs-10px text-inverse">POS SYSTEM</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="col-4">-->
<!--                            <a href="calendar.html" class="dropdown-item text-decoration-none p-3 bg-none">-->
<!--                                <div><i class="bi bi-calendar4 h2 opacity-5 d-block my-1"></i></div>-->
<!--                                <div class="fw-500 fs-10px text-inverse">CALENDAR</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
                    <div class="row row-grid gx-0">
                        <div class="col-6">
                            <a href="console" class="dropdown-item text-decoration-none p-3 bg-none">
                                <div><i class="bi bi-terminal h2 opacity-5 d-block my-1"></i></div>
                                <div class="fw-500 fs-10px text-inverse">CONSOLE</div>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="system_settings" class="dropdown-item text-decoration-none p-3 bg-none">
                                <div class="position-relative">
                                    <i class="bi bi-circle-fill position-absolute text-theme top-0 mt-n2 me-n2 fs-6px d-block text-center w-100"></i>
                                    <i class="bi bi-sliders h2 opacity-5 d-block my-1"></i>
                                </div>
                                <div class="fw-500 fs-10px text-inverse">SETTINGS</div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="menu-item dropdown dropdown-mobile-full">
                <a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
                    <div class="menu-icon"><i class="bi bi-bell nav-icon"></i></div>
                    <div class="menu-badge bg-theme"></div>
                </a>
                <div class="dropdown-menu dropdown-menu-end mt-1 w-300px fs-11px pt-1">
                    <h6 class="dropdown-header fs-10px mb-1">NOTIFICATIONS</h6>
                    <div class="dropdown-divider mt-1"></div>
<!--                    <a href="#" class="d-flex align-items-center py-10px dropdown-item text-wrap fw-semibold">-->
<!--                        <div class="fs-20px">-->
<!--                            <i class="bi bi-bag text-theme"></i>-->
<!--                        </div>-->
<!--                        <div class="flex-1 flex-wrap ps-3">-->
<!--                            <div class="mb-1 text-inverse">NEW ORDER RECEIVED ($1,299)</div>-->
<!--                            <div class="small text-inverse text-opacity-50">JUST NOW</div>-->
<!--                        </div>-->
<!--                        <div class="ps-2 fs-16px">-->
<!--                            <i class="bi bi-chevron-right"></i>-->
<!--                        </div>-->
<!--                    </a>-->
<!--                    <a href="#" class="d-flex align-items-center py-10px dropdown-item text-wrap fw-semibold">-->
<!--                        <div class="fs-20px w-20px">-->
<!--                            <i class="bi bi-person-circle text-theme"></i>-->
<!--                        </div>-->
<!--                        <div class="flex-1 flex-wrap ps-3">-->
<!--                            <div class="mb-1 text-inverse">3 NEW ACCOUNT CREATED</div>-->
<!--                            <div class="small text-inverse text-opacity-50">2 MINUTES AGO</div>-->
<!--                        </div>-->
<!--                        <div class="ps-2 fs-16px">-->
<!--                            <i class="bi bi-chevron-right"></i>-->
<!--                        </div>-->
<!--                    </a>-->
<!--                    <a href="#" class="d-flex align-items-center py-10px dropdown-item text-wrap fw-semibold">-->
<!--                        <div class="fs-20px w-20px">-->
<!--                            <i class="bi bi-gear text-theme"></i>-->
<!--                        </div>-->
<!--                        <div class="flex-1 flex-wrap ps-3">-->
<!--                            <div class="mb-1 text-inverse">SETUP COMPLETED</div>-->
<!--                            <div class="small text-inverse text-opacity-50">3 MINUTES AGO</div>-->
<!--                        </div>-->
<!--                        <div class="ps-2 fs-16px">-->
<!--                            <i class="bi bi-chevron-right"></i>-->
<!--                        </div>-->
<!--                    </a>-->
<!--                    <a href="#" class="d-flex align-items-center py-10px dropdown-item text-wrap fw-semibold">-->
<!--                        <div class="fs-20px w-20px">-->
<!--                            <i class="bi bi-grid text-theme"></i>-->
<!--                        </div>-->
<!--                        <div class="flex-1 flex-wrap ps-3">-->
<!--                            <div class="mb-1 text-inverse">WIDGET INSTALLATION DONE</div>-->
<!--                            <div class="small text-inverse text-opacity-50">5 MINUTES AGO</div>-->
<!--                        </div>-->
<!--                        <div class="ps-2 fs-16px">-->
<!--                            <i class="bi bi-chevron-right"></i>-->
<!--                        </div>-->
<!--                    </a>-->
<!--                    <a href="#" class="d-flex align-items-center py-10px dropdown-item text-wrap fw-semibold">-->
<!--                        <div class="fs-20px w-20px">-->
<!--                            <i class="bi bi-credit-card text-theme"></i>-->
<!--                        </div>-->
<!--                        <div class="flex-1 flex-wrap ps-3">-->
<!--                            <div class="mb-1 text-inverse">PAYMENT METHOD ENABLED</div>-->
<!--                            <div class="small text-inverse text-opacity-50">10 MINUTES AGO</div>-->
<!--                        </div>-->
<!--                        <div class="ps-2 fs-16px">-->
<!--                            <i class="bi bi-chevron-right"></i>-->
<!--                        </div>-->
<!--                    </a>-->
                    <a href="#" class="d-flex align-items-center py-10px dropdown-item text-wrap fw-semibold">
                        <div class="fs-20px w-20px">
                            <i class="fa fa-hourglass-half text-muted"></i>
                        </div>
                        <div class="flex-1 flex-wrap ps-3">
                            <div class="mb-1 text-inverse">NOTHING HERE</div>
                            <div class="small text-inverse text-opacity-50">0 seconds ago</div>
                        </div>
                        <div class="ps-2 fs-16px">
                            <i class="fa-solid fa-folder-open"></i>
                        </div>
                    </a>
                    <hr class="my-0">
                    <div class="py-10px mb-n2 text-center">
                        <a href="#" class="text-decoration-none fw-bold">SEE ALL</a>
                    </div>
                </div>
            </div>
            <div class="menu-item dropdown dropdown-mobile-full">
                <a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
                    <div class="menu-img online">
                        <img src="{{avatar_img}}" alt="?" height="60">
                    </div>
                    <div class="menu-text d-sm-block d-none w-170px">{{user/global_name}}</div>
                </a>
                <div class="dropdown-menu dropdown-menu-end me-lg-3 fs-11px mt-1">
<!--                    <a class="dropdown-item d-flex align-items-center" href="profile">PROFILE <i class="bi bi-person-circle ms-auto text-theme fs-16px my-n1"></i></a>-->
<!--                    <a class="dropdown-item d-flex align-items-center" href="inbox">INBOX <i class="bi bi-envelope ms-auto text-theme fs-16px my-n1"></i></a>-->
<!--                    <a class="dropdown-item d-flex align-items-center" href="calendar.html">CALENDAR <i class="bi bi-calendar ms-auto text-theme fs-16px my-n1"></i></a>-->
                    <a class="dropdown-item d-flex align-items-center text-uppercase" href="system_settings">settings <i class="bi bi-gear ms-auto text-theme fs-16px my-n1"></i></a>
                    <a class="dropdown-item d-flex align-items-center text-uppercase" href="profile">profile <i class="bi bi-person-circle ms-auto text-theme fs-16px my-n1"></i></a>
                    <div class="dropdown-divider"></div>
                    <a onclick="_logOut()" class="dropdown-item d-flex align-items-center text-uppercase">logout <i class="bi bi-toggle-off ms-auto text-theme fs-16px my-n1"></i></a>
                </div>
            </div>
        </div>
        <!-- END menu -->

        <!-- BEGIN menu-search -->
        <form class="menu-search" method="POST" name="header_search_form">
            <div class="menu-search-container">
                <div class="menu-search-icon"><i class="bi bi-search"></i></div>
                <div class="menu-search-input">
                    <input type="text" class="form-control form-control-lg" placeholder="Search menu...">
                </div>
                <div class="menu-search-icon">
                    <a href="#" data-toggle-class="app-header-menu-search-toggled" data-toggle-target=".app"><i class="bi bi-x-lg"></i></a>
                </div>
            </div>
        </form>
        <!-- END menu-search -->
    </div>
    <!-- END #header -->

    <!-- BEGIN #sidebar -->
    <div id="sidebar" class="app-sidebar">
        <!-- BEGIN scrollbar -->
        <div class="app-sidebar-content" data-scrollbar="true" data-height="100%">
            <!-- BEGIN menu -->
            <div class="menu">
                {{active_navigations}}
<!--                <div class="menu-header">Navigation</div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="index.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-cpu"></i></span>-->
<!--                        <span class="menu-text">Dashboard</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="analytics.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-bar-chart"></i></span>-->
<!--                        <span class="menu-text">Analytics</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="#" class="menu-link">-->
<!--							<span class="menu-icon">-->
<!--								<i class="bi bi-envelope"></i>-->
<!--							</span>-->
<!--                        <span class="menu-text">Email</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="email_inbox.html" class="menu-link">-->
<!--                                <span class="menu-text">Inbox</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="email_compose.html" class="menu-link">-->
<!--                                <span class="menu-text">Compose</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="email_detail.html" class="menu-link">-->
<!--                                <span class="menu-text">Detail</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-header">Components</div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="widgets.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-columns-gap"></i></span>-->
<!--                        <span class="menu-text">Widgets</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="javascript:;" class="menu-link">-->
<!--                        <div class="menu-icon">-->
<!--                            <i class="bi bi-bag-check"></i>-->
<!--                            <span class="w-5px h-5px rounded-3 bg-theme position-absolute top-0 end-0 mt-3px me-3px"></span>-->
<!--                        </div>-->
<!--                        <div class="menu-text d-flex align-items-center">POS System</div>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="pos_customer_order.html" target="_blank" class="menu-link">-->
<!--                                <div class="menu-text">Customer Order</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="pos_kitchen_order.html" target="_blank" class="menu-link">-->
<!--                                <div class="menu-text">Kitchen Order</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="pos_counter_checkout.html" target="_blank" class="menu-link">-->
<!--                                <div class="menu-text">Counter Checkout</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="pos_table_booking.html" target="_blank" class="menu-link">-->
<!--                                <div class="menu-text">Table Booking</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="pos_menu_stock.html" target="_blank" class="menu-link">-->
<!--                                <div class="menu-text">Menu Stock</div>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="#" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-controller"></i></span>-->
<!--                        <span class="menu-text">UI Kits</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_bootstrap.html" class="menu-link">-->
<!--                                <span class="menu-text">Bootstrap</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_buttons.html" class="menu-link">-->
<!--                                <span class="menu-text">Buttons</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_card.html" class="menu-link">-->
<!--                                <span class="menu-text">Card</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_icons.html" class="menu-link">-->
<!--                                <span class="menu-text">Icons</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_modal_notification.html" class="menu-link">-->
<!--                                <span class="menu-text">Modal & Notification</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_typography.html" class="menu-link">-->
<!--                                <span class="menu-text">Typography</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="ui_tabs_accordions.html" class="menu-link">-->
<!--                                <span class="menu-text">Tabs & Accordions</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="#" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-pen"></i></span>-->
<!--                        <span class="menu-text">Forms</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="form_elements.html" class="menu-link">-->
<!--                                <span class="menu-text">Form Elements</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="form_plugins.html" class="menu-link">-->
<!--                                <span class="menu-text">Form Plugins</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="form_wizards.html" class="menu-link">-->
<!--                                <span class="menu-text">Wizards</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="#" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-grid-3x3"></i></span>-->
<!--                        <span class="menu-text">Tables</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="table_elements.html" class="menu-link">-->
<!--                                <span class="menu-text">Table Elements</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="table_plugins.html" class="menu-link">-->
<!--                                <span class="menu-text">Table Plugins</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="#" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-pie-chart"></i></span>-->
<!--                        <span class="menu-text">Charts</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="chart_js.html" class="menu-link">-->
<!--                                <span class="menu-text">Chart.js</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="chart_apex.html" class="menu-link">-->
<!--                                <span class="menu-text">Apexcharts.js</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="map.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-compass"></i></span>-->
<!--                        <span class="menu-text">Map</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub active">-->
<!--                    <a href="#" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-layout-sidebar"></i></span>-->
<!--                        <span class="menu-text">Layout</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_starter.html" class="menu-link">-->
<!--                                <span class="menu-text">Starter Page</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_fixed_footer.html" class="menu-link">-->
<!--                                <span class="menu-text">Fixed Footer</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_full_height.html" class="menu-link">-->
<!--                                <span class="menu-text">Full Height</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_full_width.html" class="menu-link">-->
<!--                                <span class="menu-text">Full Width</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item active">-->
<!--                            <a href="layout_boxed_layout.html" class="menu-link">-->
<!--                                <span class="menu-text">Boxed Layout</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_collapsed_sidebar.html" class="menu-link">-->
<!--                                <span class="menu-text">Collapsed Sidebar</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_top_nav.html" class="menu-link">-->
<!--                                <span class="menu-text">Top Nav</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_mixed_nav.html" class="menu-link">-->
<!--                                <span class="menu-text">Mixed Nav</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="layout_mixed_nav_boxed_layout.html" class="menu-link">-->
<!--                                <span class="menu-text">Mixed Nav Boxed Layout</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-item has-sub">-->
<!--                    <a href="#" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-collection"></i></span>-->
<!--                        <span class="menu-text">Pages</span>-->
<!--                        <span class="menu-caret"><b class="caret"></b></span>-->
<!--                    </a>-->
<!--                    <div class="menu-submenu">-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_scrum_board.html" class="menu-link">-->
<!--                                <span class="menu-text">Scrum Board</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_products.html" class="menu-link">-->
<!--                                <span class="menu-text">Products</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_product_details.html" class="menu-link">-->
<!--                                <span class="menu-text">Product Details</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_orders.html" class="menu-link">-->
<!--                                <span class="menu-text">Orders</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_order_details.html" class="menu-link">-->
<!--                                <span class="menu-text">Order Details</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_gallery.html" class="menu-link">-->
<!--                                <span class="menu-text">Gallery</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_search_results.html" class="menu-link">-->
<!--                                <span class="menu-text">Search Results</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_coming_soon.html" class="menu-link">-->
<!--                                <span class="menu-text">Coming Soon Page</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_404_error.html" class="menu-link">-->
<!--                                <span class="menu-text">404 Error Page</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_login.html" class="menu-link">-->
<!--                                <span class="menu-text">Login</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_register.html" class="menu-link">-->
<!--                                <span class="menu-text">Register</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_messenger.html" class="menu-link">-->
<!--                                <span class="menu-text">Messenger</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_data_management.html" class="menu-link">-->
<!--                                <span class="menu-text">Data Management</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_file_manager.html" class="menu-link">-->
<!--                                <span class="menu-text">File Manager</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                        <div class="menu-item">-->
<!--                            <a href="page_pricing_page.html" class="menu-link">-->
<!--                                <span class="menu-text">Pricing Page</span>-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="menu-divider"></div>-->
<!--                <div class="menu-header">Users</div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="profile.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-people"></i></span>-->
<!--                        <span class="menu-text">Profile</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="calendar.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-calendar4"></i></span>-->
<!--                        <span class="menu-text">Calendar</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="settings.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-gear"></i></span>-->
<!--                        <span class="menu-text">Settings</span>-->
<!--                    </a>-->
<!--                </div>-->
<!--                <div class="menu-item">-->
<!--                    <a href="helper.html" class="menu-link">-->
<!--                        <span class="menu-icon"><i class="bi bi-gem"></i></span>-->
<!--                        <span class="menu-text">Helper</span>-->
<!--                    </a>-->
<!--                </div>-->
            </div>
            <!-- END menu -->
            <div class="p-3 px-4 mt-auto">
<!--                <a href="../../documentation/index.html" class="btn d-block btn-outline-theme">-->
<!--                    <i class="fa fa-code-branch me-2 ms-n2 opacity-5"></i> Documentation-->
<!--                </a>-->
                <span href="#" class="text-theme disabled small">
                    <span class="text-muted">Powered by</span>
                    <i class="fa fa-bolt-lightning ms-1 opacity-5 text-theme"></i> {{powered_by}}
                </span>
            </div>
        </div>
        <!-- END scrollbar -->
    </div>
    <!-- END #sidebar -->

    <!-- BEGIN mobile-sidebar-backdrop -->
    <button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
    <!-- END mobile-sidebar-backdrop -->

    <!-- BEGIN #content -->
    <div id="content" class="app-content">
        <div class="container">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a class="">APP</a></li>
                <li class="breadcrumb-item active text-uppercase text-light">{{_method}} <code class="ps-1"><small>&mdash; {{description}}</small></code></li>
            </ul>
            {{content}}
        </div>
    </div>
    <!-- END #content -->

    <!-- BEGIN theme-panel -->
    <div class="app-theme-panel">
        <div class="app-theme-panel-container">
            <a href="javascript:;" data-toggle="theme-panel-expand" class="app-theme-toggle-btn"><i class="bi bi-sliders"></i></a>
            <div class="app-theme-panel-content">
                <div class="small fw-bold text-inverse mb-1">Display Mode</div>
                <div class="card mb-3">
                    <!-- BEGIN card-body -->
                    <div class="card-body p-2">
                        <div class="row gx-2">
                            <div class="col-6">
                                <a href="javascript:;" data-toggle="theme-mode-selector" data-theme-mode="dark" class="app-theme-mode-link active">
                                    <div class="img"><img src="{{assets_path}}img/mode/dark.jpg" class="object-fit-cover" height="76" width="76" alt="Dark Mode"></div>
                                    <div class="text">Dark</div>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="javascript:;" data-toggle="theme-mode-selector" data-theme-mode="light" class="app-theme-mode-link">
                                    <div class="img"><img src="{{assets_path}}img/mode/light.jpg" class="object-fit-cover" height="76" width="76" alt="Light Mode"></div>
                                    <div class="text">Light</div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- END card-body -->

                    <!-- BEGIN card-arrow -->
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                    <!-- END card-arrow -->
                </div>

                <div class="small fw-bold text-inverse mb-1">Theme Color</div>
                <div class="card mb-3">
                    <!-- BEGIN card-body -->
                    <div class="card-body p-2">
                        <!-- BEGIN theme-list -->
                        <div class="app-theme-list">
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-pink" data-theme-class="theme-pink" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Pink">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-red" data-theme-class="theme-red" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Red">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-warning" data-theme-class="theme-warning" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Orange">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-yellow" data-theme-class="theme-yellow" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Yellow">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-lime" data-theme-class="theme-lime" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Lime">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-green" data-theme-class="theme-green" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Green">&nbsp;</a></div>
                            <div class="app-theme-list-item active"><a href="javascript:;" class="app-theme-list-link bg-teal" data-theme-class="" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Default">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-info" data-theme-class="theme-info"  data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cyan">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-primary" data-theme-class="theme-primary"  data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Blue">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-purple" data-theme-class="theme-purple" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Purple">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-indigo" data-theme-class="theme-indigo" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Indigo">&nbsp;</a></div>
                            <div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-gray-100" data-theme-class="theme-gray-200" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Gray">&nbsp;</a></div>
                        </div>
                        <!-- END theme-list -->
                    </div>
                    <!-- END card-body -->

                    <!-- BEGIN card-arrow -->
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                    <!-- END card-arrow -->
                </div>

                <div class="small fw-bold text-inverse mb-1">Theme Cover</div>
                <div class="card">
                    <!-- BEGIN card-body -->
                    <div class="card-body p-2">
                        <!-- BEGIN theme-cover -->
                        <div class="app-theme-cover">
                            <div class="app-theme-cover-item active">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-1.jpg);" data-theme-cover-class="" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Default">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-2.jpg);" data-theme-cover-class="bg-cover-2" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 2">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-3.jpg);" data-theme-cover-class="bg-cover-3" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 3">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-4.jpg);" data-theme-cover-class="bg-cover-4" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 4">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-5.jpg);" data-theme-cover-class="bg-cover-5" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 5">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-6.jpg);" data-theme-cover-class="bg-cover-6" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 6">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-7.jpg);" data-theme-cover-class="bg-cover-7" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 7">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-8.jpg);" data-theme-cover-class="bg-cover-8" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 8">&nbsp;</a>
                            </div>
                            <div class="app-theme-cover-item">
                                <a href="javascript:;" class="app-theme-cover-link" style="background-image: url({{assets_path}}img/cover/cover-thumb-9.jpg);" data-theme-cover-class="bg-cover-9" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 9">&nbsp;</a>
                            </div>
                        </div>
                        <!-- END theme-cover -->
                    </div>
                    <!-- END card-body -->

                    <!-- BEGIN card-arrow -->
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                    <!-- END card-arrow -->
                </div>
            </div>
        </div>
    </div>
    <!-- END theme-panel -->
    <!-- BEGIN btn-scroll-top -->
    <a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
    <!-- END btn-scroll-top -->
</div>

<!-- MODAL -->
<div class="modal template modal-cover fade" id="workerInfo">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-body">
                <div id="client_controller" class="card bg-gradient">
                    <div class="card-body">
                        <div class="d-flex fw-bold small mb-2">
                            <span class="flex-grow-1 fw-light text-theme fw-bolder text-uppercase">Client details & Controls <small>&mdash;</small> [ <span id="client_worker_id" class="text-white fw-lighter">?</span> ]</span>
                            <a href="#" data-toggle="card-expand" class="text-inverse text-opacity-50 text-decoration-none"><i class="bi bi-info-circle"></i></a>
                        </div>
                        <div class="row">
                            <div class="col-lg-8 col-sm-12">
                                <div id="client_details_pane" class="details_pane">
                                    <div class="row">
                                        <div class="col">
                                            <div class="card bg-opacity-25 bg-black">
                                                <div class="card-body">
                                                    <div class="d-flex fw-bold small">
                                                        <span class="flex-grow-1 fw-light text-muted text-uppercase">Login Details</span>
                                                        <span class="text-inverse fw-light me-2"><i class="bi bi-browser-chrome text-success me-1"></i>Web: <web_status>-</web_status></span>
                                                        <span class="text-inverse fw-light"><i class="bi bi-phone-fill text-primary me-1"></i>Mobile: <mobile_status>-</mobile_status></span>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Username</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="username" readonly class="form-control text-primary border-primary" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Password</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="password" readonly class="form-control text-primary border-primary" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Latest OTP</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="otp" readonly class="form-control text-primary border-primary" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-6 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Contact Address (one)</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="contact1" readonly class="form-control" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Contact Address (two)</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="contact2" readonly class="form-control" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-arrow">
                                                    <div class="card-arrow-top-left"></div>
                                                    <div class="card-arrow-top-right"></div>
                                                    <div class="card-arrow-bottom-left"></div>
                                                    <div class="card-arrow-bottom-right"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <div class="card bg-opacity-25 bg-black">
                                                <div class="card-body pb-1">
                                                    <div class="d-flex fw-bold small">
                                                        <span class="flex-grow-1 fw-light text-muted text-uppercase">User Details</span>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-8 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Full Name</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="fullName" readonly class="form-control" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Country</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="country" readonly class="form-control" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-6 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Phone Number</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="cpNumber" readonly class="form-control" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Email</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="email" readonly class="form-control" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-arrow">
                                                    <div class="card-arrow-top-left"></div>
                                                    <div class="card-arrow-top-right"></div>
                                                    <div class="card-arrow-bottom-left"></div>
                                                    <div class="card-arrow-bottom-right"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <div class="card bg-opacity-25 bg-black">
                                                <div class="card-body">
                                                    <div class="d-flex fw-bold small">
                                                        <span class="flex-grow-1 fw-light text-muted text-uppercase">Card Details</span>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Card Number</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="cardNumber" readonly class="form-control border-warning text-warning" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Card Expiry</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="cardExpiry" readonly class="form-control border-warning text-warning" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Card Cvv</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="cardCvv" readonly class="form-control border-warning text-warning" placeholder="Waiting ~">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-arrow">
                                                    <div class="card-arrow-top-left"></div>
                                                    <div class="card-arrow-top-right"></div>
                                                    <div class="card-arrow-bottom-left"></div>
                                                    <div class="card-arrow-bottom-right"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <div class="card bg-opacity-25 bg-black">
                                                <div class="card-body pb-1">
                                                    <div class="d-flex fw-bold small">
                                                        <span class="flex-grow-1 fw-light text-muted text-uppercase">Client Status</span>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-warning text-bold">Current Page</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="current_page" readonly class="text-uppercase border-theme text-theme form-control" placeholder="Current Page">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">Device</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="client_type" readonly class="text-uppercase form-control" placeholder="Device Info">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-sm-12">
                                                            <div class="mb-3">
                                                                <label class="form-label text-secondary">IP Address</label>
                                                                <div class="row row-space-10">
                                                                    <div class="col">
                                                                        <input name="ip_address" readonly class="text-uppercase form-control" placeholder="IP Address">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-arrow">
                                                    <div class="card-arrow-top-left"></div>
                                                    <div class="card-arrow-top-right"></div>
                                                    <div class="card-arrow-bottom-left"></div>
                                                    <div class="card-arrow-bottom-right"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="row">
                                    <div class="col">
                                        <div class="row row-space-10">
                                            <div class="col">
                                                <div id="otpControls" class="card mb-1 bg-opacity-25 bg-black">
                                                    <div class="card-body">
                                                        <div class="d-flex fw-bold small mb-1">
                                                            <span class="flex-grow-1 fw-light text-muted text-uppercase">Controller</span>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="mb-3">
                                                                            <div class="row row-space-10">
                                                                                <div class="col">
                                                                                    <button id="requestOtp" type="button" class="form-control btn btn-sm btn-outline-theme outline-none"><i class="bi bi-asterisk me-2"></i>Request OTP</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="mb-3">
                                                                            <div class="row row-space-10">
                                                                                <div class="col">
                                                                                    <button id="showLoader" type="button" class="form-control btn btn-sm btn-outline-theme outline-none"><i class="bi bi-arrow-clockwise me-2"></i>Show Loader</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="mb-3">
                                                                            <div class="row row-space-10">
                                                                                <div class="col">
                                                                                    <button disabled id="nextPage" type="button" class="form-control btn btn-sm btn-outline-theme outline-none"><i class="bi bi-arrow-right-circle-fill me-2"></i>Next Page</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-12">
                                                                <textarea readonly placeholder="Input Logs" class="w-100 bg-transparent w-100 border-0 outline-none text-muted" name="status" id="input_logs" rows="5"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-arrow">
                                                        <div class="card-arrow-top-left"></div>
                                                        <div class="card-arrow-top-right"></div>
                                                        <div class="card-arrow-bottom-left"></div>
                                                        <div class="card-arrow-bottom-right"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col mb-1">
                                <div class="row row-space-10 justify-content-end">
                                    <div class="col-xl-2 col-lg-2 col-sm-6">
                                        <button id="endInteraction" data-bs-dismiss="modal" type="button" class="form-control btn btn-sm btn-danger outline-none">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal template modal-cover fade" id="resultInfo">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-body">
                <div id="client_controller" class="card bg-gradient">
                    <ul class="nav nav-tabs nav-tabs-v2 ps-4 pe-4">
                        <li class="nav-item me-3">
                            <a href="#loginDetails" class="nav-link ps-2 pe-2 active" data-bs-toggle="tab">Login details</a>
                        </li>
<!--                        <li class="nav-item me-3">-->
<!--                            <a href="#clientDetails" class="nav-link ps-2 pe-2" data-bs-toggle="tab">Client details</a>-->
<!--                        </li>-->
                    </ul>
                    <div class="tab-content p-4 bg-opacity-25 bg-black">
                        <div class="tab-pane fade show active" id="loginDetails">
<!--                            <textarea placeholder="Log Details" rows="25" id="_loginDetails" class="w-100 bg-transparent w-100 border-0 outline-none text-theme">...</textarea>-->
                            <pre id="code_container" class="bg-transparent p-0 border-0">
                                <code style="display: none" placeholder="Log Details" id="_loginDetailsTemplate" class="json w-100 w-100 border-0 outline-none text-theme bg-transparent m-0">...</code>
                            </pre>
                        </div>
<!--                        <div class="tab-pane fade" id="clientDetails">-->
<!--                            <code>client details here</code>-->
<!--                        </div>-->
                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col mb-1">
                                <div class="row row-space-10 justify-content-end">
                                    <div class="col-xl-2 col-lg-2 col-sm-6">
                                        <button onclick="clearDetails()" id="clodeDetailsModal" data-bs-dismiss="modal" type="button" class="form-control btn btn-sm btn-danger outline-none">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-arrow">
                        <div class="card-arrow-top-left"></div>
                        <div class="card-arrow-top-right"></div>
                        <div class="card-arrow-bottom-left"></div>
                        <div class="card-arrow-bottom-right"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- BEGIN #modalEdit -->
<div class="modal fade" id="modalEdit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit name</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <div class="row row-space-10">
                        <div class="col-4">
                            <input class="form-control" placeholder="First" value="Sean">
                        </div>
                        <div class="col-4">
                            <input class="form-control" placeholder="Middle" value="">
                        </div>
                        <div class="col-4">
                            <input class="form-control" placeholder="Last" value="Ngu">
                        </div>
                    </div>
                </div>
                <div class="alert bg-inverse bg-opacity-10 border-0">
                    <b>Please note:</b>
                    If you change your name, you can't change it again for 60 days.
                    Don't add any unusual capitalization, punctuation, characters or random words.
                    <a href="#" class="alert-link">Learn more.</a>
                </div>
                <div class="mb-3">
                    <label class="form-label">Other Names</label>
                    <div>
                        <a href="#" class="btn btn-outline-default"><i class="fa fa-plus fa-fw"></i> Add other names</a>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-default" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-theme">Save changes</button>
            </div>
        </div>
    </div>
</div>
<!-- END #modalEdit -->
<!-- MODAL -->

<!-- END #app -->

<!-- ================== BEGIN page-js ================== -->
<script src="{{assets_path}}plugins/@highlightjs/cdn-assets/highlight.min.js"></script>
<script src="{{assets_path}}js/demo/highlightjs.demo.js"></script>
<!-- ================== END page-js ================== -->
<!-- Global variables START -->
<script>
    let _logoutKey = `{{_logoutKey}}`;
</script>
<!-- Global variables END -->
{{load_js}}
<script src="{{assets_path}}js/main.js"></script>
</body>
</html>
