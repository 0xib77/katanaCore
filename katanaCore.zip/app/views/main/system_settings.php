<div class="row justify-content-center">

    <div class="col-xl-10">

        <div class="row">

            <div class="col-xl-9">

                <div id="profile" class="mb-5">
                    <h4><i class="bi bi-person-circle text-theme"></i> Profile</h4>
                    <p>View and update your general account information and settings.</p>
                    <div class="card">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex align-items-center">
                                <div class="flex-1 text-break">
                                    <div>Name</div>
                                    <div class="text-theme">{{user/global_name}}</div>
                                </div>
                            </div>
                            <div class="list-group-item d-flex align-items-center">
                                <div class="flex-1 text-break">
                                    <div>Username</div>
                                    <div class="text-theme">{{user/username}}</div>
                                </div>
                            </div>
                            <div class="list-group-item d-flex align-items-center">
                                <div class="flex-1 text-break">
                                    <div>Email address</div>
                                    <div class="text-theme">{{user/email}}</div>
                                </div>
                            </div>
                            <div class="list-group-item d-flex align-items-center">
                                <div class="flex-1 text-break">
                                    <div>Password</div>
                                    <div class="text-muted fw-bold">**********</div>
                                </div>
                                <div>
                                    <a onclick="updatePass()" href="#updatePass" data-bs-toggle="modal" class="btn btn-sm btn-outline-theme w-100px">Update</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>

            </div>


            <div class="col-xl-3">

                <nav id="sidebar-bootstrap" class="navbar navbar-sticky d-none d-xl-block">
                    <nav class="nav">
                        <a class="nav-link active" href="#profile" data-toggle="scroll-to">Profile</a>
                    </nav>
                </nav>

            </div>

        </div>

    </div>

</div>

<script>

    function updatePass() {

        let updateSrc = `
            <div class="row">
                <div class="col">
                    <div class="mb-3 text-start">
                        <label class="form-label text-secondary">Password</label>
                        <div class="row row-space-10">
                            <div class="col">
                                <input type="password" name="updatePassword" id="updatePassword" class="form-control outline-none" placeholder="Password">
                                <small id="passwordStrengthMsg" class="text-muted">Strong password is required</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="mb-3 text-start">
                        <label class="form-label text-secondary">Confirm Password</label>
                        <div class="row row-space-10">
                            <div class="col">
                                <input type="password" name="confirmPassword" id="confirmPassword" class="form-control outline-none" placeholder="Confirm Password">
                                <small id="passwordMatch" class="text-muted"></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;

        function checkPasswordStrength(password) {
            let strength = 0;
            if (password.length >= 8) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;

            return strength;
        }

        function displayPasswordStrength(strength) {
            const $msg = $('#passwordStrengthMsg');
            if (strength < 3) {
                $msg
                    .removeClass('text-success')
                    .removeClass('text-warning')
                    .addClass('text-danger')
                    .text('Password is weak');
            } else if (strength === 3 || strength === 4) {
                $msg
                    .removeClass('text-muted')
                    .removeClass('text-success')
                    .addClass('text-warning')
                    .text('Password is acceptable, but could be stronger');
            } else if (strength === 5) {
                $msg
                    .removeClass('text-muted')
                    .removeClass('text-warning')
                    .addClass('text-success')
                    .text('Password is strong');
            }
        }

        Swal.fire({
            title: 'Update Password',
            html: updateSrc,
            icon: 'info',
            confirmButtonText: 'Update',
            cancelButtonText: 'Cancel',
            allowOutsideClick: false,
            showCancelButton: true,
            customClass: {
                confirmButton: 'btn btn-theme',
                cancelButton: 'btn btn-secondary',
            },
            didOpen: () => {
                const $passwordInput = $('#updatePassword');
                const $confirmPasswordInput = $('#confirmPassword');

                let _checkPass = function (passMatch, $passwordInput, $confirmPasswordInput) {
                    setTimeout(function () {
                        if ($passwordInput.val() === $confirmPasswordInput.val()) {
                            passMatch
                                .text('Password match, please proceed')
                                .removeClass('text-muted')
                                .addClass('text-success');
                        } else if($confirmPasswordInput.val().length >= $passwordInput.val().length) {
                            passMatch
                                .text('Confirm password incorrect')
                                .removeClass('text-muted')
                                .removeClass('text-success')
                                .addClass('text-danger');
                        } else {
                            passMatch
                                .addClass('text-muted')
                                .text('');
                        }
                    }, 500, $passwordInput, $confirmPasswordInput);
                };

                $passwordInput.on('input', function () {
                    const password = $(this).val();
                    const strength = checkPasswordStrength(password);
                    displayPasswordStrength(strength);
                    console.log('Password:', password); // Optional: Debugging line
                    Swal.resetValidationMessage();
                });

                $confirmPasswordInput.on('input', function () {
                    console.log('Confirm Password:', $(this).val()); // Optional: Debugging line
                    const passMatch = $('#passwordMatch');
                    passMatch.text(passMatch.text() +'.');
                    _checkPass(passMatch, $passwordInput, $confirmPasswordInput);
                    Swal.resetValidationMessage();
                });
            },
            preConfirm: () => {
                const password = $('#updatePassword').val();
                const confirmPassword = $('#confirmPassword').val();
                const strength = checkPasswordStrength(password);

                if (strength < 5) {
                    Swal.showValidationMessage('Please choose a stronger password.');
                    return false;
                }
                if (password !== confirmPassword) {
                    Swal.showValidationMessage('Passwords do not match.');
                    return false;
                }

                return { password, confirmPassword };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                console.log('Passwords are confirmed:', result.value);
                // Handle the confirmed passwords

                Swal.fire({
                    title: 'Password update',
                    text: 'Processing request...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                $.ajax({
                    url: '/api/password_update',
                    method: 'POST',
                    data: {
                        updatedPass: result.value
                    },
                    success: function (response) {

                        console.log(response);
                        if ('status' in response && response.status === 'success') {

                            Swal.fire({
                                title: 'Updated',
                                html: response.message ?? `Password updated successfully`,
                                icon: 'success',
                                showConfirmButton: false,
                                timer: 2000,
                            });

                        } else {
                            Swal.fire({
                                title: 'Oops!',
                                html: `Unexpected request response`,
                                icon: 'info',
                                confirmButtonText: 'Try again later',
                                timer: 5000,
                                allowOutsideClick: false,
                                customClass: {
                                    confirmButton: 'btn btn-outline-warning',
                                }
                            });
                        }

                    },
                    error: function (error) {
                        let _error = false;
                        if ('responseJSON' in error && typeof error.responseJSON !== 'undefined' && 'error' in error.responseJSON && 'message' in error.responseJSON.error) {
                            _error = error.responseJSON.error.message;
                        } else {
                            _error = 'An error occurred, Try again later';
                        }
                        Swal.fire({
                            title: 'Oops!',
                            html: _error,
                            icon: 'error',
                            confirmButtonText: 'Continue',
                            allowOutsideClick: false,
                            customClass: {
                                confirmButton: 'btn btn-secondary',
                            }
                        });
                    }
                });
            }
        });
    }

    $(document).ready(function () {
        $('#loader').fadeOut('slow', function () {
            $('#content').fadeIn('slow', function () {
                try {
                    var scrollSpy = new bootstrap.ScrollSpy(document.body, {target: '#sidebar-bootstrap', offset: 200});
                } catch (e) {
                    console.log(`Oops: ${e}`);
                }
            });
        });
    });
</script>