<div class="row">
    <div class="col-8 col-sm-12 mb-3">
        <div class="card-body">
            <div class="card" id="site_groups">
                <div class="card-header fw-bold small d-flex">
                    <span class="flex-grow-1 text-uppercase">Active Sites</span>
                    <a href="#" data-toggle="card-expand" class="text-inverse text-opacity-50 text-decoration-none"><i class="fa fa-fw fa-expand"></i></a>
                </div>
                <div class="card-body bg-inverse bg-opacity-10">
                    <textarea placeholder="..." disabled readonly name="lists" id="site_groups" rows="25" class="bg-transparent w-100 border-0 outline-none text-muted disabled"></textarea>
                </div>
                <div class="card-footer">
                    <div class="row justify-content-end mb-1 ms-0 me-0">
                        <div class="col-xl-2 col-lg-2 col-sm-6 pe-0">
                            <button type="button" class="btn btn-muted btn-sm w-100 cancel" style="display: none">Cancel</button>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-sm-6 pe-0">
                            <button type="button" class="btn btn-info btn-sm w-100 edit">Edit</button>
                        </div>
                    </div>
                </div>
                <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-4 col-sm-12">
        <div class="card-body">
            <div class="card" id="dead_sites">
                <div class="card-header fw-bold small d-flex">
                    <span class="flex-grow-1 text-uppercase text-danger">Dead Sites</span>
                    <a href="#" data-toggle="card-expand" class="text-inverse text-opacity-50 text-decoration-none"><i class="fa fa-fw fa-expand"></i></a>
                </div>
                <div class="card-body bg-inverse bg-opacity-10">
                    <textarea placeholder="..." disabled readonly name="lists" id="site_groups" rows="15" class="bg-transparent w-100 border-0 outline-none text-danger disabled"></textarea>
                </div>
                <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {

        let textarea = $('.card#site_groups textarea#site_groups');
        let textarea2 = $('.card#dead_sites textarea#site_groups');
        let textareaValue = textarea.val();
        let site_lists = textarea.val().split('\n');

        let isReadOnly = null;
        let updateBtn = $('.card#site_groups button.edit');
        let cancelBtn = $('.card#site_groups button.cancel');
        let detaulState = function () {

            cancelBtn.hide();
            isReadOnly = true;
            textarea.prop('readonly', isReadOnly);
            updateBtn
                .toggleClass('btn-info btn-theme')
                .text('Edit');
            textarea
                .attr('placeholder', '...')
                .attr('disabled', isReadOnly)
                .removeClass('text-theme')
                .addClass('text-muted')
                .addClass('disabled');
        };

        let socket_connections_request = {
            fetch: '/api/socket_connections/fetch',
            update: '/api/socket_connections/update'
        }

        // fetch lists
        $.get(socket_connections_request.fetch, function (response) {
            if (typeof response !== "undefined" && 'lists' in response) {
                let list = textareaValue = response.lists.join('\n');
                textarea.val(list);
            }
            if (typeof response !== "undefined" && 'dead_lists' in response) {
                let list = response.dead_lists.join('\n');
                textarea2.val(list);
            }
        });

        cancelBtn.click(function () {

            site_lists = textarea.val().split('\n');
            site_lists = site_lists.filter(function(item) {
                return item !== "" && item !== null && item !== undefined;
            });

            let
                cancel = $(this),
                revert = function () {
                cancel.hide();
                detaulState();
                textarea.val(textareaValue);
            }
            if (textareaValue !== textarea.val() && site_lists.length >= 1) {
                Swal.fire({
                    title: 'List update',
                    html: `<span class="text-warning">Revert changes?</span>`,
                    icon: 'question',
                    confirmButtonText: 'Continue',
                    cancelButtonText: 'Cancel',
                    // allowOutsideClick: false,
                    showCancelButton: true,
                    customClass: {
                        confirmButton: 'btn btn-info',
                        cancelButton: 'btn btn-secondary',
                    }
                }).then((revert_change) => {
                    if (revert_change.isConfirmed) {
                        revert();
                    }
                });
            } else {
                revert();
            }


        });

        updateBtn.click(function() {

            site_lists = textarea.val().split('\n');
            site_lists = site_lists.filter(function(item) {
                return item !== "" && item !== null && item !== undefined;
            });

            isReadOnly = textarea.prop('readonly');

            console.log(`isReadOnly: ${(isReadOnly ? 'true' : 'false')}`)

            if (isReadOnly) {

                textarea.prop('readonly', false);
                cancelBtn.show();
                textarea.prop('readonly', !isReadOnly);
                updateBtn
                    .toggleClass('btn-info btn-theme')
                    .text('Save');

                textarea
                    .attr('placeholder', 'https://parasite.io')
                    .removeClass('text-muted')
                    .addClass('text-theme')
                    .removeAttr('disabled')
                    .removeClass('disabled');

                setTimeout(function () {
                    textarea.focus();
                    textarea[0].click();
                }, 100);
            } else {

                console.log(site_lists);

                if (textareaValue !== textarea.val() && !isReadOnly && site_lists.length >= 1) {
                    // save site list
                    Swal.fire({
                        title: 'Site list update',
                        html: `<span>Save list?</span><br><pre class="bg-transparent border-0 text-secondary m-0 pb-0 overflow-hidden">${textarea.val()}</pre>`,
                        icon: 'question',
                        confirmButtonText: 'Continue',
                        cancelButtonText: 'Cancel',
                        // allowOutsideClick: false,
                        showCancelButton: true,
                        customClass: {
                            confirmButton: 'btn btn-info',
                            cancelButton: 'btn btn-secondary',
                        }
                    }).then((save_list) => {

                        if (save_list.isConfirmed) {

                            Swal.fire({
                                title: 'List update',
                                text: 'updating list...',
                                allowOutsideClick: false,
                                didOpen: () => {
                                    Swal.showLoading();
                                }
                            });

                            $.ajax({
                                url: socket_connections_request.update,
                                method: 'POST',
                                data: {
                                    site_lists: site_lists
                                },
                                success: function (response) {

                                    console.log(response);
                                    if ('status' in response && response.status === 'success') {

                                        Swal.fire({
                                            title: 'Site list',
                                            html: 'Updated successfully',
                                            icon: 'success',
                                            showConfirmButton: false,
                                            showCancelButton: false,
                                            timer: 1000,
                                            allowOutsideClick: false,
                                        });

                                        let list = textareaValue = response.lists.join('\n');
                                        textarea.val(list);

                                        detaulState();

                                    } else {
                                        Swal.fire({
                                            title: 'Oops!',
                                            html: `Unexpected request response`,
                                            icon: 'warning',
                                            confirmButtonText: 'Try again later',
                                            timer: 5000,
                                            allowOutsideClick: false,
                                            customClass: {
                                                confirmButton: 'btn btn-warning',
                                            }
                                        });
                                    }

                                },
                                error: function (error) {
                                    let _error = false;
                                    if ('responseJSON' in error && typeof error.responseJSON !== 'undefined' && 'error' in error.responseJSON && 'message' in error.responseJSON.error) {
                                        _error = error.responseJSON.error.message;
                                    } else {
                                        _error = 'An error occurred, Try again later';
                                    }
                                    Swal.fire({
                                        title: 'Oops!',
                                        html: _error,
                                        icon: 'error',
                                        confirmButtonText: 'Continue',
                                        allowOutsideClick: false,
                                        timer: 5000,
                                        customClass: {
                                            confirmButton: 'btn btn-secondary',
                                        }
                                    });
                                },
                                complete: function () {
                                    //
                                }
                            });
                        }

                    });
                } else {
                    setTimeout(function () {
                        textarea.focus();
                        textarea[0].click();
                    }, 100);
                }

            }
        });
    });
</script>