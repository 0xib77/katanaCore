<div class="row">
    <div class="col-12 col-sm-12 mb-3">
        <div class="card-body">
            <div class="card" id="hook_groups">
                <div class="card-header fw-bold small d-flex">
                    <span class="flex-grow-1 text-uppercase">Discord Webhooks</span>
                    <a href="#" data-toggle="card-expand" class="text-inverse text-opacity-50 text-decoration-none"><i class="fa fa-fw fa-expand"></i></a>
                </div>
                <div class="card-body bg-inverse bg-opacity-10">
                    <div class="row">
                        <div class="col">
                            <table id="webhook_inputs">
                                <tbody>
                                <tr class="template">
                                    <td class="w-100">
                                        <input type="search" class="mb-2 webhooks form-control" placeholder="Discord Webhook ~">
                                    </td>
                                    <td>
                                        <button disabled class="mb-2 btn btn-sm bg-transparent icon border-0 outline-none">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card-footer pt-0">
                    <div class="row justify-content-between mb-1">
                        <div class="col-xl-2 col-lg-2 col-sm-6 mt-2">
                            <button type="button" class="btn btn-secondary btn-sm w-100 add">Add Another</button>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-sm-6 mt-2">
                            <button type="button" class="btn btn-info btn-sm w-100 save">Save</button>
                        </div>
                    </div>
                </div>
                <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>

    function removeTr(id) {
        let _tr = $(`tr#x_${id}`);
        if (_tr.length >= 1) {
            _tr.fadeOut('fast', function () {
                $(this).remove();
            });
        }
    }
    $('body').on('click', 'table#webhook_inputs tbody input.webhooks', function () {
        $(this).removeClass('border-danger');
    });

    $(document).ready(function () {
        let
            webhooks_table = $('table#webhook_inputs'),
            webhooks_tbody = webhooks_table.find('tbody:eq(0)'),
            webhooks_template = webhooks_tbody.find('tr.template:eq(0)');

        let addBtn = $('.card#hook_groups button.add');
        let saveBtn = $('.card#hook_groups button.save');

        // fetch hooks
        $.get('/api/fetch_hooks', function (response) {
            if (typeof response !== "undefined" && 'list' in response) {

                let
                    trCount = 0,
                    _tr = false;

                Object.entries(response.list).reverse().forEach(function ([x, hook]) {
                    trCount = webhooks_tbody.find('input.webhooks').length;

                    if (!(_tr)) {
                        _tr = webhooks_template;
                        _tr.prependTo(webhooks_tbody);
                    } else {
                        _tr = webhooks_template.clone();
                        _tr.find('button:eq(0)')
                            .attr('onclick', `removeTr('${(trCount +1)}')`)
                            .addClass('text-danger')
                            .removeAttr('disabled');
                        _tr.prependTo(webhooks_tbody);

                        _tr
                            .attr('id', `x_${(trCount +1)}`)
                            .removeClass('template');
                    }

                    _tr.find('input:eq(0)').val(hook);
                    if (_tr.find('input:eq(0)').hasClass('border-danger')) {
                        _tr.find('input:eq(0)').removeClass('border-danger');
                    } else {
                        _tr.find('input:eq(0)').addClass('border-theme');
                    }
                });
            }
        });

        addBtn.click(function () {
            let
                trCount = webhooks_tbody.find('input.webhooks').length,
                _tr = webhooks_template.clone();
            _tr
                .attr('id', `x_${(trCount +1)}`)
                .removeClass('template');
            _tr.find('input:eq(0)').val('');
            if (_tr.find('input:eq(0)').hasClass('border-danger')) {
                _tr.find('input:eq(0)').removeClass('border-danger');
            }
            if (_tr.find('input:eq(0)').hasClass('border-theme')) {
                _tr.find('input:eq(0)').removeClass('border-theme');
            }
            _tr.find('button:eq(0)')
                .attr('onclick', `removeTr('${(trCount +1)}')`)
                .addClass('text-danger')
                .removeAttr('disabled');
            _tr.prependTo(webhooks_tbody);
        });

        saveBtn.click(function () {
            let _inputs = webhooks_tbody.find('input.webhooks');
            let
                _hasError = false,
                webhooks = [];
            _inputs.each(function (x, y) {
                // console.log(y);
                let _input = $(y);
                if (_input.val().length <= 0) {
                    _hasError = true;
                    _input.addClass('border-danger');
                    _input.fadeOut('slow', function () {
                       $(this).fadeIn('fast');
                    });
                } else {
                    if (_input.hasClass('border-danger')) {
                        _input.removeClass('border-danger');
                    }
                    // save
                    if (!(webhooks.includes(_input.val()))) {
                        webhooks.push(_input.val());
                    } else {
                        _hasError = true;
                        _input.addClass('border-danger');
                        _input.fadeOut('slow', function () {
                            $(this).fadeIn('fast');
                        });
                    }
                    // webhooks[x] = _input.val();
                }
            });
            // check hooks
            if (!(_hasError) && webhooks.length >= 1) {
                Swal.fire({
                    title: 'Webhook update',
                    text: 'updating settings...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                let settings = JSON.stringify(webhooks);
                console.log(settings);

                $.ajax({
                    url: '/api/save_hooks',
                    method: 'POST',
                    data: {
                        hooks: settings
                    },
                    success: function (response) {

                        console.log(response);
                        if ('status' in response && response.status === 'success') {

                            Swal.fire({
                                title: 'Discord Hooks',
                                html: 'Updated successfully',
                                icon: 'success',
                                showConfirmButton: false,
                                showCancelButton: false,
                                timer: 1000,
                                allowOutsideClick: false,
                            });

                        } else {
                            Swal.fire({
                                title: 'Oops!',
                                html: `Unexpected request response`,
                                icon: 'warning',
                                confirmButtonText: 'Try again later',
                                timer: 5000,
                                allowOutsideClick: false,
                                customClass: {
                                    confirmButton: 'btn btn-warning',
                                }
                            });
                        }

                    },
                    error: function (error) {
                        let _error = false;
                        if ('responseJSON' in error && typeof error.responseJSON !== 'undefined' && 'error' in error.responseJSON && 'message' in error.responseJSON.error) {
                            _error = error.responseJSON.error.message;
                        } else {
                            _error = 'An error occurred, Try again later';
                        }
                        Swal.fire({
                            title: 'Oops!',
                            html: _error,
                            icon: 'error',
                            confirmButtonText: 'Continue',
                            allowOutsideClick: false,
                            timer: 5000,
                            customClass: {
                                confirmButton: 'btn btn-secondary',
                            }
                        });
                    },
                    complete: function () {
                        //
                    }
                });

            }
        });
    });
</script>