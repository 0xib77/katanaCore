<div id="results_group_container">
<!--    <div id="waiting_for_connections" class="row">-->
<!--        <div class="col bg-white bg-opacity-5 text-center justify-content-center rounded-1 p-1 ps-2 pe-2">-->
<!--            Waiting for connections ...-->
<!--        </div>-->
<!--    </div>-->
    <div style="display: none" id="page_results_container" class="row results_container">
        <div class="col">

            <div class="card mb-3">

                <div class="card-body">

                    <div class="d-flex fw-bold small mb-3">
                        <span class="flex-grow-1 text-info"><group>Waiting ...</group> [ <x class="text-muted fw-light">Logs:</x> <total_clients class="text-muted">0</total_clients> ]</span>
                        <span class="text-inverse text-opacity-50 text-decoration-none"><i class="bi bi-list-task text-info"></i></span>
                    </div>


                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-borderless mb-2px small text-nowrap workers_container">
                            <tbody>
                            <tr id="waiting">
                                <td colspan="5" class="justify-content-center text-secondary"><i class="bi bi-hourglass-bottom me-1 text-secondary"></i>Waiting for results ...</td>
                            </tr>
                            <tr style="display: none" id="page_worker_template" class="clickable">
                                <td>
                                    <span class="d-flex align-items-center">
                                        <i id="status_indicator" class="bi bi-circle-fill fs-6px text-info me-3"></i>
                                        <small>
                                            <span class="text-muted text-uppercase">
                                                <i class="bi bi-journal-text me-2 text-theme"></i> Status &mdash; <b class="text-warning fw-bold">
                                                    <status class="fw-bold text-warning"></status>
                                                    <interacting_user class="text-white"></interacting_user>
                                                </b>
                                            </span>
                                        </small>
                                    </span>
                                </td>
                                <td class="w-25">
                                    <i class="text-white bi bi-clock-history me-2 client_type"></i>
                                    <last_update></last_update>&nbsp;<x class="text-muted">/</x>
                                    <rez_date class="text-white fw-bold"></rez_date> ago~
                                </td>
                                <td class="w-25">
                                    <small>
                                        <span id="country_flag" class="me-2"></span><country class="text-uppercase fw-bold"></country><ip_address class="ms-1 small fw-light text-success"></ip_address>
                                    </small>
                                </td>
                                <td>
                                    <small>
                                        <span id="interaction_wait" class="text-uppercase">Attempts&nbsp;<x class="text-muted">/</x><attempts class="text-white fw-bold ms-1">0</attempts></span>
                                    </small>
                                </td>
                                <td class="text-end">
                                    <small>
                                        <rez>
                                            <i class="bi bi-filetype-key text-primary"></i>
                                        </rez>
                                    </small>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                </div>


                <div class="card-arrow">
                    <div class="card-arrow-top-left"></div>
                    <div class="card-arrow-top-right"></div>
                    <div class="card-arrow-bottom-left"></div>
                    <div class="card-arrow-bottom-right"></div>
                </div>

            </div>

        </div>
    </div>
</div>

<script>

    let
        _validated_logs = {},
        _groupList = [],
        _groupListDead = [];

    function clearDetails() {
        $('div.modal#resultInfo').find('#_loginDetails.shown').remove();
    }

    function showDetails(elem, trId) {
        // console.warn(elem);
        // console.warn(_validated_logs);
        // console.warn(_validated_logs[trId]);
        // console.warn($(elem));
        let _modal = $('div.modal#resultInfo:eq(0)');

        _modal.modal({
            backdrop: 'static',
            keyboard: false,
            show: false // Initialize the modal but don't show it immediately
        });

        _modal.modal('show');
        _modal.off('shown.bs.modal');
        _modal.on('shown.bs.modal', function () {
            // update modal
            // _modal.find('#_loginDetails:eq(0)').text('');
            if (trId in _validated_logs) {
                // _modal.find('#_loginDetails:eq(0)').text(JSON.stringify(_validated_logs[trId], null, 4));
                // init hljs

                let
                    _codeContainer = _modal.find('pre#code_container:eq(0)'),
                    codeTemplate = _codeContainer.find('code#_loginDetailsTemplate:eq(0)'),
                    codeDetails = codeTemplate.clone();

                codeDetails
                    .removeClass('hljs')
                    .removeAttr('data-highlighted')
                    .attr('id', '_loginDetails')
                    .addClass('shown')
                    .addClass('language-json')
                    .css('display', 'block')
                    .removeAttr('style');
                codeDetails.text(JSON.stringify(_validated_logs[trId], null, 4));
                codeDetails.prependTo(_codeContainer);

                hljs.highlightAll();
                hljs.highlightElement(codeDetails[0]);
            }
        });
        // setTimeout(function () {
        //     // update modal
        //     _modal.find('#_loginDetails:eq(0)').text('');
        //     if (trId in _validated_logs) {
        //         _modal.find('#_loginDetails:eq(0)').text(JSON.stringify(_validated_logs[trId], null, 4));
        //     }
        // }, 500, _modal);

    }

    $(document).ready(function () {
        // fetch sites
        let
            _resultsGroupContainer = $('div#results_group_container'),
            _pageResultsContainer = _resultsGroupContainer.find('div.row#page_results_container'),
            _api = `https://${document.domain}/api`;

        $.get(`${_api}/socket_connections/fetch`, function (response) {

            let _error = function () {
                Swal.fire({
                    title: 'Please update settings',
                    html: 'No active links available',
                    icon: 'error',
                    showConfirmButton: false,
                    showCancelButton: false,
                    timer: 3000,
                    allowOutsideClick: false,
                }).then(function () {
                    $('div#page_results_container').removeAttr('style');
                });
            }
            if ((typeof response !== "undefined" && 'lists' in response) || typeof response !== "undefined" && 'dead_lists' in response) {

                if ((Object.entries(response.lists).length >= 1) || Object.entries(response.dead_lists).length >= 1) {
                    _groupList = response.lists;
                    Object.entries(response.lists).forEach(([i, origin]) => {
                        let _id = `row_${CryptoJS.MD5(origin).toString()}`;
                        let container = _pageResultsContainer.clone();
                        container
                            .removeAttr('style')
                            .attr('id', _id);
                        container.find('group:eq(0)')
                            .html(`<i class="bi bi-lightning-charge-fill text-warning me-1"></i>${origin}`);
                        container.prependTo(_resultsGroupContainer);
                    });

                    if (Object.entries(response.dead_lists).length >= 1) {
                        _groupListDead = response.dead_lists;
                        Object.entries(response.dead_lists).forEach(([i, origin]) => {
                            let _id = `row_${CryptoJS.MD5(origin).toString()}`;
                            let container = _pageResultsContainer.clone();
                            container
                                .removeAttr('style')
                                .attr('id', _id);
                            container.find('group:eq(0)')
                                .addClass('text-danger')
                                .html(`<i class="bi bi-bug-fill text-danger me-1"></i>${origin}`);
                            container.prependTo(_resultsGroupContainer);
                        });
                    }

                } else {
                    _error();
                }
            } else {
                _error();
            }
        }).done(function () {
            // fetch logs
            console.warn(`Group list: ${JSON.stringify(_groupList, null, 3)}`);
            let _processList = function (_origin, i) {
                console.warn(`${i} - ${_origin}`);
                let row_id = CryptoJS.MD5(_origin).toString();
                let row_template = _resultsGroupContainer.find(`div.row#row_${row_id}:eq(0)`);
                let rez = 0;
                let origin = btoa(_origin).replace(/=/g,'');

                $.get(`${_api}/validated_logs/${origin}`, function (response) {

                    if (Object.entries(response).length >= 1) {

                        Object.entries(response).forEach(([x, result]) => {

                            let client_id = ('_id' in result) ? result._id : (('key' in result) ? result.key : x);
                            let _trId = CryptoJS.MD5(client_id + _origin).toString();
                            let tr_template = row_template.find('tr#page_worker_template:eq(0)').clone();

                            console.warn(result);
                            console.warn(client_id);
                            console.warn(_origin);
                            _validated_logs[_trId] = result;

                            tr_template
                                .attr('origin',origin)
                                .attr('onclick',`showDetails(this, '${_trId}')`)
                                .removeAttr('style')
                                .removeAttr('id')
                                .attr('id', `tr_${_trId}`);

                            tr_template.find('last_update:eq(0)').text(result.updated_at);
                            tr_template.find('rez_date:eq(0)').text(moment(result.updated_at, "YYYY-MM-DD HH:mm:ss").fromNow(true));

                            tr_template.find('status:eq(0)').text(result.status ?? '*');

                            if ('client' in result && 'ip_info' in result.client) {
                                tr_template.find('span#country_flag:eq(0)')
                                    .addClass(`fi fi-${(result.client.ip_info.countryCode).toLowerCase()}`);
                                tr_template.find('country:eq(0)')
                                    .text(result.client.ip_info.country);
                                tr_template.find('ip_address:eq(0)')
                                    .text(result.client.ip_info.query);

                                let
                                    interacting_id = 'NA',
                                    interacting_user = '?';

                                if ('client' in result && 'interacting' in result.client) {
                                    interacting_id = result.client.interacting.id ?? interacting_id;
                                    interacting_user = result.client.interacting.username ?? interacting_user;
                                }

                                tr_template.find('interacting_user:eq(0)')
                                    .html(` <x class="text-muted">/</x> ${interacting_user} ( <small class="text-theme fw-light">${interacting_id}</small> )`);
                            } else {
                                tr_template.find('span#country_flag:eq(0)')
                                    .addClass(`fi fi-xx`);
                            }

                            if ('attempts' in result) {
                                rez++;
                                // Object.entries(result.attempts).forEach(([client_id, attempt]) => {
                                //     console.warn(`Origin attempt: ${JSON.stringify(attempt, null, 3)}`);
                                // });
                                let _validated = 0;
                                Object.entries(result.attempts).forEach(function ([id, attempt]) {
                                    if ('status' in attempt && attempt.status === 'validated') {
                                        _validated++;
                                    }
                                });
                                tr_template.find('attempts:eq(0)')
                                    .text(`${_validated} - ${Object.entries(result.attempts).length}`);
                                console.warn(`Origin logs: ${JSON.stringify(result, null, 3)}`);
                            }

                            tr_template.prependTo(row_template.find('table tbody:eq(0)'));
                            row_template.prependTo(_resultsGroupContainer);

                        });

                        row_template.find('total_clients:eq(0)')
                            .removeClass('text-muted')
                            .addClass('text-warning')
                            .text(rez);

                        row_template.find('tr#waiting').fadeOut('slow');
                    }

                }).done(function () {
                    console.warn(_validated_logs);
                });
            };
            _groupList.forEach((_origin, i) => {
                _processList(_origin, i);
            });
            _groupListDead.forEach((_origin, i) => {
                _processList(_origin, i);
            });
        });

    });
</script>