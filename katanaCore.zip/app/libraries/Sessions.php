<?php

class Sessions
{
    public static function push(array $sessions)
    {
        foreach ($sessions as $key => $val) {
            if (!empty($key)) {
                $_SESSION[$key] = $val;
            }
        }
    }

    public static function pull($key)
    {
        if (is_array($key)) {
            $walk = $_SESSION;
            foreach ($key as $k) {
                if (isset($walk[$k])) {
                    $walk = $walk[$k];
                }
            }
            return $walk;
        } else {
            if (isset($_SESSION[$key]) && !empty($_SESSION[$key])) {
                return $_SESSION[$key];
            }
        }
        return null;
    }

    public static function unset($key)
    {
        if (is_array($key)) {
            foreach ($key as $k) {
                if (isset($_SESSION[$k])) {
                    unset($_SESSION[$k]);
                }
            }
        } else if (isset($_SESSION[$key])) {
            unset($_SESSION[$key]);
        }
    }

    public static function all()
    {
        return $_SESSION;
    }

    public static function clear()
    {
        session_destroy();
        session_unset();
    }
}