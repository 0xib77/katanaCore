<?php 

use \Workerman\Worker;
use \GatewayWorker\Gateway;
use \Workerman\Autoloader;

require_once __DIR__ . '/../vendor/autoload.php';

//@file_put_contents('socket_dir', __DIR__);

//---------------------------------------------------------------------------- SSL
$context = array(
    'ssl' => array(
        'local_cert'    => '/home/checker/public_html/app/server/private/app/cert/server.pem',
        'local_pk'      => '/home/checker/public_html/app/server/private/app/cert/server.key',
        'verify_peer' => false,
//        'allow_self_signed' => true,
//        'verify_peer_name' => false,
    )
);
$gateway = new Gateway("Websocket://0.0.0.0:8443", $context);
$gateway->transport = 'ssl';
//---------------------------------------------------------------------------- SSL

// gateway
//$gateway = new Gateway("Websocket://0.0.0.0:8000");

// gateway name
$gateway->name = 'DarkSide Gateway';
// gateway worker count
$gateway->count = 4;
// gateway lan IP
$gateway->lanIp = '68.168.211.94';
// port 2300 to 2301
$gateway->startPort = 2300;
// ping interval
$gateway->pingInterval = 30;
// ping data
$gateway->pingData = '{"type":"ping"}';
// address to listen
$gateway->registerAddress = '0.0.0.0:1236';

// is defined global start check
if(!defined('GLOBAL_START'))
{
    Worker::runAll();
}

