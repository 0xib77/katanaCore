<?php
// decode secret
//const AUTH_KEY = 's3cur3d!@123!@#!';
@date_default_timezone_set('Asia/Manila');

const DS = DIRECTORY_SEPARATOR;
const CONFIG_DIR = __DIR__ . DS;
const SOCKET_SERVER = 'socket.gh0s7.stream:8443';
const SleekDB = [
    "auto_cache" => false,
    "cache_lifetime" => null,
    "timeout" => false, // deprecated! Set it to false!
    "primary_key" => "_id",
    "folder_permissions" => 0777
];
const LOG_DB = [
    'data_dir' => __DIR__ . '/../../../../database',

    'checker' => 'checker_queue',
    'check_cards' => 'check_cards',
    'scanned' => 'scanned_cards',
    'users' => 'live_users',
    'active_users' => 'active_users',
    'security_keys' => 'authentication_keys',
    'stored_scans' => 'stored_scans'

];
const CONFIG = [
    'time_stamp_format' => 'm/d/Y h:iA',
];

const CHANNELS = [
    'main' => 1,
];