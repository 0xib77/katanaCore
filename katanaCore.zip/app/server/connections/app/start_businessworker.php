<?php

use \Workerman\Worker;
use \GatewayWorker\BusinessWorker;
use \Workerman\Autoloader;

$required = [
    'vendor/autoload.php',
    'app/config/config.php',
    'lib/Fun.php',
];
foreach ($required as $require) {
    $r = __DIR__ . '/../' . $require;
    if (file_exists($r)) {
        require_once $r;
    } else {
        echo "[~] Unable to include: {$r}\n";
    }
}

// bussinessWorker
$worker = new BusinessWorker();
// worker名称
$worker->name = 'BlackOps Socket Server';
// bussiness worker count
$worker->count = 4;
// address to listen
$worker->registerAddress = '0.0.0.0:1236';

// is defined global start check
if(!defined('GLOBAL_START'))
{
    Worker::runAll();
}

