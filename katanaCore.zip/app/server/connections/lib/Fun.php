<?php

namespace DarkSide;

class Fun {
    function auth_dec($data) {

        if (!defined('AUTH_KEY')) {
            require_once __DIR__ . '/../config.php';
        }
        $secret_key = hex2bin(hash('sha256', AUTH_KEY)); // new
        //$secret_key = hex2bin("5e425d24053bc066370c3a706786a071ed9a62c6bdb2d8501eaefc5eec178503"); // old
        $json = @json_decode(@base64_decode($data), true, 512);
        $iv = base64_decode(@$json['iv']);
        $tag = base64_decode(@$json['tag']);
        $encrypted_data = base64_decode(@$json['data']);
        $decrypted_data = @openssl_decrypt($encrypted_data, 'aes-256-gcm', $secret_key, OPENSSL_RAW_DATA, $iv, $tag);
        return base64_decode($decrypted_data);
    }
}