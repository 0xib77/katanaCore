<?php
if (!function_exists('sqlInput')) {
    function sqlInput($input) {
        return filter_var($input, FILTER_UNSAFE_RAW);
    }
}