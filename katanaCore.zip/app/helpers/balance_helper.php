<?php
if (!function_exists('get_bal')) {
    function get_bal($id = false, $from = false, $inline = false, $instance = false)
    {
        if (!$id) {
            if ($inline) {
                return false;
            }

            $instance->out([
                'status' => 'error',
                'message' => 'missing parameter'
            ]);
        }

        $account = [];
        if ($from && isset($from['account_details']) && count($from['account_details']) > 0) {
            $account = $from;
        } else {
            $fetch = $instance->db->fetch_injected_single((int)$id);
            if (isset($fetch['account_details']) && count($fetch['account_details']) > 0) {
                $account = $fetch;
            } else {
                $account = false;
            }
        }

//        $instance->out($account);

        $total = 0;
        $balance = "<small>N/A</small>";

        if ($account) {

            if (isset($account['account_details']) && count($account['account_details']) > 0) {
                $balance = "";
                foreach ($account['account_details'] as $balance_details) {
                    if (isset($balance_details['formatted_balance'], $balance_details['balance_type'], $balance_details['currency'])) {
                        if ((int)$balance_details['formatted_balance'] <= 0) {
                            $muted = 'text-muted';
                        } else {
                            $muted = 'text-primary';
                        }

                        switch (strtolower($balance_details['balance_type'])) {
                            case 'available balance':

                                // get total
                                $bal = $balance_details['formatted_balance'];
                                $_bal = (int)str_replace(',', '', $bal);
                                if ($_bal > 0 && $balance_details['pay_bills']) {
//                                    $total .= "||{$bal}";
                                    $total = ((int)$total + $_bal);
                                }

                                $balance .= "{$balance_details['currency']}<small class='text-success me-2 {$muted}'>{$balance_details['formatted_balance']}</small>";
                                break;

                            default:
                                $balance .= "{$balance_details['currency']}<small class='text-warning me-2 {$muted}'>{$balance_details['formatted_balance']}</small>";
                                break;
                        }
                    }
                }
            }
        }

        if ($inline) {
            return [
                'trusted' => $account['trust_details']['trusted'] ?? false,
                'balance' => $balance,
                'total' => $total
            ];
        }

        $instance->out([
            'trusted' => $account['trust_details']['trusted'] ?? false,
            'src' => $balance,
            'total' => $total
        ]);
    }
}