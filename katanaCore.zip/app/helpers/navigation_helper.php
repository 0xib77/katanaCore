<?php

if (!function_exists('render_navigations')) {
    function render_navigations($view, $config, $class)
    {
        $view = basename($view);

        // get navigations
        if (isset($config['navigations']) && is_array($config['navigations'])) {

            $rendered_nav = "";
            $arr_navs = 0;
            if (count($config['navigations']) > 0) {

                foreach ($config['navigations'] as $nav_type => $navigations) {

                    if (empty($nav_type) || !is_array($navigations) || count($navigations) <= 0) {
                        continue;
                    }

                    $nav_type = ucwords($nav_type);
                    $rendered_nav .= <<<_menu_header
                                        <div class="menu-header">{$nav_type}</div>
                                    _menu_header;

                    foreach ($navigations as $nav => $items) {

                        // check permission
                        // get perms
                        $perm = Sessions::pull('permission') ?? false;
                        if ($perm && !in_array($perm, $items['permissions'], true)) {
                            continue;
                        }

                        $active = '';
                        $has_active = '';
                        $identifier = $items[$nav]['identifier'] ?? "";

                        if (isset($items['navs']) && count($items['navs']) >= 1) {

                            $b = ucwords($nav);
                            $lis = "";

                            foreach ($items['navs'] as $k) {
                                if (isset($n['is_disabled']) && $n['is_disabled'] === true) {
                                    continue;
                                }
                                if (!empty($k)) {

                                    if (strtolower($view) === strtolower(str_replace([' ','.'], '_', $k))) {
                                        $has_active = 'active';
                                        $active = $has_active;
                                    } else {
                                        $active = '';
                                    }
                                    $a = strip_tags(strtolower(str_replace([' ','.'], '_', $k)));
                                    $x = ucwords(str_replace('_', ' ', $a));
                                    $dash_theme = '';
                                    if (!empty($has_active) && strtolower($view) === strtolower(str_replace([' ','.'], '_', $k))) {
                                        $dash_theme = 'text-theme';
                                    }
                                    if (isset($items['view'])) {
                                        $a = "#{$a}";
                                    }

                                    $lis .= <<<_item_lis
                                                <div class="menu-item {$active}">
                                                    <a href="{$a}" class="menu-link">
                                                        <span class="menu-text"><i class="bi bi-dash {$dash_theme}"></i> {$x}</span>
                                                    </a>
                                                </div>
                                            _item_lis;
                                }
                            }
                            $text_theme = (empty($has_active) ? '' : 'text-theme');
                            $rendered_nav .= <<<_nav_item
                                                <div class="menu-item has-sub {$has_active} {$identifier}">
                                                    <a href="#{$arr_navs}" class="menu-link">
                                                        <span class="menu-icon"><i class="{$items['icon']}"></i></span>
                                                        <span class="menu-text">{$b}</span>
                                                        <span class="menu-caret {$text_theme}"><b class="caret"></b></span>
                                                    </a>
                                                    <div class="menu-submenu">
                                                        {$lis}
                                                    </div>
                                                </div>
                                            _nav_item;

                            $arr_navs++;
                        } elseif (!empty($nav) && isset($items['icon'])) {

                            if (strtolower($view) === strtolower(str_replace([' ','.'], '_', $nav))) {
                                $active = 'active';
                            }

                            $a = strip_tags(strtolower(str_replace([' ','.'], '_', $nav)));
                            if (isset($items['view'])) {
                                $a = "#{$a}";
                            }
                            $b = ucwords(str_replace('_', ' ', $nav));
                            $rendered_nav .= <<<_nav_item
                                                <div class="menu-item {$active} {$identifier}">
                                                    <a href="{$a}" class="menu-link">
                                                        <span class="menu-icon"><i class="{$items['icon']}"></i></span>
                                                        <span class="menu-text">{$b}</span>
                                                    </a>
                                                </div>
                                            _nav_item;
                        } else {
                            $rendered_nav .= <<<_nav_item
                                                <div class="menu-item">
                                                    <a href="#" class="menu-link">
                                                        <span class="menu-icon"><i class="bi bi-cpu"></i></span>
                                                        <span class="menu-text">Welcome</span>
                                                    </a>
                                                </div>
                                            _nav_item;
                        }
                    }
                }
            } else {
                $rendered_nav .= <<<_nav_item
                                    <div class="menu-item">
                                        <a href="#" class="menu-link">
                                            <span class="menu-icon"><i class="bi bi-cpu"></i></span>
                                            <span class="menu-text">Welcome</span>
                                        </a>
                                    </div>
                                _nav_item;
            }

            $config['page_config']['active_navigations'] = $rendered_nav;
        }

        return $config;

    }
}