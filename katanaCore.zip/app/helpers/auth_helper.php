<?php
/**
 * Sets the authentication data for the current user.
 *
 * @param array $user The user data.
 * @param Leet $db The database connection.
 * @return void
 */
if (!function_exists('set_auth')) {
    function set_auth($user, Leet $db)
    {
        if (class_exists('Sessions')) {
            $login_time = date(config_item('time_stamp_format'));
            $db->user_active($user['_id'], $login_time);

            Sessions::push([
                'user_details' => $user,
                'authenticated_user' => $user['username'],
                'login_time' => $login_time,
                'authenticated' => true
            ]);
        } else {
            throw new RuntimeException('Class: Sessions is not loaded.');
        }
    }
}