<?php
if (!function_exists('getHeaders')) {
    function getHeaders() {
        static $headers = null;

        // Return cached headers if already processed
        if ($headers !== null) {
            return $headers;
        }

        $headers = [];

        // Try apache_request_headers() first if available
        if (function_exists('apache_request_headers')) {
            try {
                $rawHeaders = apache_request_headers();
                if (is_array($rawHeaders)) {
                    // Normalize apache headers
                    foreach ($rawHeaders as $key => $value) {
                        $key = strtolower(str_replace('-', '_', $key));
                        $headers[$key] = $value;
                    }
                    return $headers;
                }
            } catch (Exception $e) {
                // Fallback to manual header processing
            }
        }

        // Process $_SERVER variables if apache_request_headers() fails or unavailable
        foreach ($_SERVER as $key => $value) {
            // Only process HTTP_ prefixed headers and other common headers
            if (strpos($key, 'HTTP_') === 0) {
                // Remove HTTP_ prefix and convert to lowercase
                $header = strtolower(substr($key, 5));
            }
            // Handle non-HTTP_ headers like CONTENT_TYPE, CONTENT_LENGTH
            elseif (in_array($key, ['CONTENT_TYPE', 'CONTENT_LENGTH', 'AUTH_TYPE'])) {
                $header = strtolower($key);
            } else {
                continue;
            }

            // Convert underscore to hyphen for standard format
            $header = str_replace('_', '-', $header);

            // Handle multiple values for the same header
            if (isset($headers[$header])) {
                // Convert to array if not already
                if (!is_array($headers[$header])) {
                    $headers[$header] = [$headers[$header]];
                }
                $headers[$header][] = $value;
            } else {
                $headers[$header] = $value;
            }
        }

        // Additional headers that might be missed
        $additional_headers = [
            'content-type' => 'CONTENT_TYPE',
            'content-length' => 'CONTENT_LENGTH',
            'authorization' => 'HTTP_AUTHORIZATION'
        ];

        foreach ($additional_headers as $header => $server_key) {
            if (!isset($headers[$header]) && isset($_SERVER[$server_key])) {
                $headers[$header] = $_SERVER[$server_key];
            }
        }

        // Handle Authorization header for CGI/FastCGI
        if (!isset($headers['authorization'])) {
            $auth = null;

            // Check for redirect auth header
            if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
                $auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
            } elseif (isset($_SERVER['PHP_AUTH_USER'])) {
                // Basic auth
                $auth = 'Basic ' . base64_encode($_SERVER['PHP_AUTH_USER'] . ':' .
                        ($_SERVER['PHP_AUTH_PW'] ?? ''));
            } elseif (isset($_SERVER['PHP_AUTH_DIGEST'])) {
                // Digest auth
                $auth = $_SERVER['PHP_AUTH_DIGEST'];
            }

            if ($auth !== null) {
                $headers['authorization'] = $auth;
            }
        }

        // Handle proxy headers
        $proxy_headers = [
            'client-ip',
            'x-forwarded-for',
            'x-forwarded-proto',
            'x-forwarded-port',
            'x-forwarded-host'
        ];

        foreach ($proxy_headers as $header) {
            $server_key = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
            if (isset($_SERVER[$server_key]) && !isset($headers[$header])) {
                $headers[$header] = $_SERVER[$server_key];
            }
        }

        // Clean and validate values
        array_walk_recursive($headers, function(&$value) {
            // Remove invalid UTF-8 characters
            $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
            // Trim whitespace
            $value = trim($value);
        });

        return $headers;
    }
}