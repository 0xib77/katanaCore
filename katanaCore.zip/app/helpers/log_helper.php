<?php
if (!function_exists('log_request')) {
    function log_request($requestData)
    {
        $logDirectory = $_SERVER['DOCUMENT_ROOT'] . '/logs';
        $logFile = $logDirectory . '/request_log_' . date('Y-m-d') . '.log';

        // Create log directory if it does not exist
        if (!is_dir($logDirectory)) {
            mkdir($logDirectory, 0755, true);
        }

        // Log the request data to a file
        $logMessage = date('Y-m-d H:i:s') . " - " . $_SERVER['REQUEST_METHOD'] . " " . $_SERVER['REQUEST_URI'] . " - " . json_encode($requestData) . PHP_EOL . PHP_EOL;
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
}
