<?php

if (!function_exists('auth_profile_menu')) {
    function auth_profile_menu($profile_session) {
        if (!is_null($profile_session)) {

            return <<<_MENU
<div class="dropdown-menu dropdown-menu-end me-lg-3 mt-1 w-200px">
    <a class="dropdown-item d-flex align-items-center" href="#"><i class="far fa-user fa-fw fa-lg me-3"></i> Profile</a>
<!--    <a class="dropdown-item d-flex align-items-center" href="#"><i class="far fa-envelope fa-fw fa-lg me-3"></i> Inbox</a>-->
<!--    <a class="dropdown-item d-flex align-items-center" href="#"><i class="far fa-calendar fa-fw fa-lg me-3"></i> Calendar</a>-->
    <a class="dropdown-item d-flex align-items-center" href="#"><i class="fa fa-sliders fa-fw fa-lg me-3"></i> Settings</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item d-flex align-items-center" href="#"><i class="fa fa-arrow-right-from-bracket fa-fw fa-lg me-3"></i> Logout</a>
</div>
_MENU;

        }

        return <<<_AUTH_MENU
<div class="dropdown-menu dropdown-menu-end me-lg-3 mt-1 w-200px">
    <a class="dropdown-item d-flex align-items-center text-muted disabled" href="#"><i class="far fa-user fa-fw fa-lg me-3"></i><small> &mdash;</small></a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item d-flex align-items-center" href="/auth/login"><i class="fa fa-right-to-bracket fa-fw fa-lg me-3"></i> Login</a>
</div>
_AUTH_MENU;

    }
}