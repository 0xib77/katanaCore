<?php
if (!function_exists('cleanData')) {
    function cleanData($data)
    {
        if (is_array($data)) {
            foreach ($data as $key => $val) {
                if (is_array($val)) {
                    $data[$key] = cleanData($val); // Recursively clean nested arrays
                } else {
                    $data[$key] = cleanSingleValue($val);
                }
            }
        } else {
            $data = cleanSingleValue($data);
        }
        return $data;
    }
}

if (!function_exists('cleanSingleValue')) {
    function cleanSingleValue($value) {
        $cleanedValue = trim(strip_tags($value));
        $cleanedValue = stripslashes($cleanedValue);
        if ($cleanedValue === "") {
            $cleanedValue = false;
        }
        return $cleanedValue;
    }
}

if (!function_exists('cleanEmail')) {
    function cleanEmail($email) {

        @list($email, $domain) = explode("@", $email, 2);
        $email = explode("+", $email, 2)[0];
        $email = str_replace(".", "", $email);
        return "{$email}@{$domain}";

    }
}

if (!function_exists('is_validEmail')) {
    function is_validEmail($email) {
        return (preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $email));
    }
}

if (!function_exists('get_method')) {
    function get_method($method) {
        return ucwords(str_replace(["_","."]," ", $method));
    }
}