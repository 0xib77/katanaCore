<?php
if (!function_exists('getData')) {
    function getData() {
        $content_type = strtolower($_SERVER['CONTENT_TYPE'] ?? "");
        $content_type = explode(";", $content_type, 2)[0];
        // Get the raw POST data
        $raw_data = @file_get_contents('php://input');

        // Format the data based on the Content-Type
        switch (strtolower($_SERVER['REQUEST_METHOD'])) {
            case "post":
                switch ($content_type) {
                    case 'application/json':
                        $data['post'] = json_decode($raw_data, true) ?? [];
                        break;

                    case 'application/x-www-form-urlencoded':
                        parse_str($raw_data, $parsed);
                        $data['post'] = $parsed;
                        break;

                    default:
                        $data['post'] = $_POST;
                        break;
                }

                break;
        }

        $data['get'] = get_request($_GET);
        return cleanData($data);
    }

    function get_request($data) {
        if (count($data) > 0) {
            return $data;
        } return [];
    }
}