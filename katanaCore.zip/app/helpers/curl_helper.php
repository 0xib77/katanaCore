<?php /** @noinspection ALL */
if (!function_exists('get_content')) {

    if (!(defined('DS'))) {
        define('DS', DIRECTORY_SEPARATOR);
    }

    function get_content(
        $URL,
        $method = "GET",
        $headers = false,
        $data = false,
        $proxy = false,
        $stream = false // [ 'out_path' => '', 'file_name' => '' ]
    )
    {

        $ch = curl_init();

        // auto decode gzip
        curl_setopt($ch,CURLOPT_ENCODING, '');

        if ($headers) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        } else {

            $getRandomUserAgent = function() {
                // Array of user-agent strings
                $userAgents = [
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36",
                    "Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.71",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1",
                    "Mozilla/5.0 (iPad; CPU OS 14_3 like Mac OS X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.93 Mobile Safari/537.36",
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 12.5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6 Safari/605.1.15",
                    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0",
                ];

                // Randomly pick a user-agent
                return $userAgents[array_rand($userAgents)];
            };
            $randomUserAgent = $getRandomUserAgent();
            $headers = [
                "Accept-language: en-US,en;q=0.9",
                "naccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "User-Agent: $randomUserAgent", // Randomly picked User-Agent
            ];
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }

        $action = strtolower($method);
        switch ($action) {
            case "get":
                curl_setopt($ch, CURLOPT_TIMEOUT, 0);
                break;
            case "post":
                curl_setopt($ch, CURLOPT_TIMEOUT, 0);
                curl_setopt($ch, CURLOPT_POST, 1);
                if ($data) {
                    if (is_array($data)) {
                        $data = http_build_query($data);
                    }
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                }
                break;
                break;
            case "patch":
            case "put":
            case "delete":
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($action));
                if (in_array($action, ['put','patch']) && $data) {
                    $data = (is_array($data) ? http_build_query($data) : $data);
                    curl_setopt($ch, CURLOPT_ENCODING, "");
                    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
                    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                }
                break;
        }

        $response = [];
        if (
            $stream &&
            isset(
                $stream['out_path'],
                $stream['file_name']
            )
        ) {

            if(!is_dir($stream['out_path']) && !mkdir($stream['out_path'])) {
                $response['status'] = 000;
                $response['error'] = "unable to create dir: {$stream['out_path']}";
                $response['data'] = null;
                return $response;
            }

            // delete existing file
            if (file_exists($stream['out_path'].DS.$stream['file_name'])) {
                @unlink($stream['out_path'].DS.$stream['file_name']);
            }

            $path = $stream['out_path'];
            $file = $stream['file_name'];

            $fp = fopen($path.DS.$file, 'w+');

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $URL);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
            if (is_array($proxy)) {
                curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
                if (isset($proxy['value'])) {
                    curl_setopt($ch, CURLOPT_PROXY, $proxy['value']);
                }
                if (isset($proxy['auth'])) {
                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy['auth']);
                }
            }

            curl_setopt($ch, CURLOPT_FILE, $fp);

            $data = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            $response['status'] = $http_code;

            if (!curl_errno($ch)) {
                $file = $path.DS.$file;
                if (file_exists($file)) {
                    $response['data'] = $file;
                    $response['error'] = null;
                } else {
                    $response['data'] = $data;
                    $response['error'] = "file: {$file} does not exist";
                }
            } else {
                $response['data'] = null;
                $response['error'] = curl_error($ch);
            }

            curl_close($ch);
            fclose($fp);

        } else {

            $headers = [];

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $URL);
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_HEADERFUNCTION,
                function ($curl, $header) use (&$headers) {
                    $len = strlen($header);
                    $header = explode(':', $header, 2);
                    if (count($header) < 2) // ignore invalid headers
                        return $len;

                    if ($header[0] === 'set-cookie') {
                        $headers['set-cookie'][] = trim($header[1]);
                    } else {
                        $headers[strtolower(trim($header[0]))][] = trim($header[1]);
                    }

                    return $len;
                }
            );
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);

//            $proxy = [
//                "value" => "159.203.98.234:29690",
//                "auth" => "randydj121_1:140zGhFeeeL0",
//            ];

//            $proxy = false;
//            curl_setopt($ch, CURLOPT_PROXY, "127.0.0.1:31337");

            if (is_array($proxy)) {
                curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
                if (isset($proxy['value'])) {
                    curl_setopt($ch, CURLOPT_PROXY, $proxy['value']);
                }
                if (isset($proxy['auth'])) {
                    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy['auth']);
                }
            }

            $data = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $response['status'] = $http_code;

            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
//            $header = substr($data, 0, $header_size);
//            $response['header'] = $header;

            foreach ($headers as $key => $val) {
                if (count($val) == 1) {
                    $headers[$key] = $val[0];
                }
            }
            $response['headers'] = $headers;

            if (!curl_errno($ch)) {
                $response['data'] = substr($data, $header_size);;
                $response['error'] = null;
            } else {
                $response['data'] = $data ?? null;
                $response['error'] = curl_error($ch);
            }

            curl_close($ch);

        }

        return $response;
    }
}