<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
const PREVENT_DIRECT_ACCESS = TRUE;

/*
 *---------------------------------------------------------------
 * SYSTEM DIRECTORY NAME
 *---------------------------------------------------------------
 *
 * This variable must contain the name of your "scheme" directory.
 * Set the path if it is not in the same directory as this file.
 * 
 * NO TRAILING SLASH!
 */
	$system_path 			= 'scheme';

/*
 *---------------------------------------------------------------
 * APPLICATION DIRECTORY NAME
 *---------------------------------------------------------------
 *
 * If you want this front controller to use a different "app"
 * directory than the default one you can set its name here.
 *
 * NO TRAILING SLASH!
 */
	$application_folder 	= 'app';

/*
 *---------------------------------------------------------------
 * APPLICATION DIRECTORY NAME
 *---------------------------------------------------------------
 * This let you set up your public folder where css, js and other public,
 * files will be visible
 */
	$public_folder			= 'public';

/*
 * ------------------------------------------------------
 * Define Application Constants
 * ------------------------------------------------------
 */
const DS = DIRECTORY_SEPARATOR;
define('SITE', $_SERVER['HTTP_HOST']);
define('ROOT_DIR', $_SERVER['DOCUMENT_ROOT'] . DS);
define('SYSTEM_DIR', ROOT_DIR . $system_path . DS);
define('APP_DIR', ROOT_DIR . $application_folder . DS);
define('PUBLIC_DIR', $public_folder);

/*
 * ------------------------------------------------------
 * Setup done? Then Hurray!
 * ------------------------------------------------------
 */
require_once(SYSTEM_DIR . 'kernel/Katana2077.php');
exit();
