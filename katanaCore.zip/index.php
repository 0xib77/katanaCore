<?php
http_response_code(407);