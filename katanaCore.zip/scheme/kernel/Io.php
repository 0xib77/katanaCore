<?php


/**
 * Class Input and Ouput
 */
class Io
{

    /**
     * If CSRF Protection is enables, csrf_verify() will
     * run
     *
     * @var boolean
     */
    private $_enable_csrf = FALSE;

    /**
     * Securty instance
     *
     * @var class
     */
    private $security;

    /**
     * Class constructor
     */
    public function __construct()
    {
        /**
         * Load Security Instance
         *
         * @var class
         */
        $this->security =& load_class('Security', 'kernel');

        /**
         * Check CSRF Protection if enabled
         *
         * @var boolean
         */
        $this->_enable_csrf = (config_item('csrf_protection') === TRUE);

        /**
         * Check CSRF Protection
         *
         * @var
         */
        if ($this->_enable_csrf === TRUE) {
            $this->security->csrf_validate();
        }
    }

    /**
     * POST Variable
     *
     * @param string
     * @return string
     */
    public function post($index = NULL)
    {
        if ($index === NULL && !empty($_POST)) {
            $post = array();
            foreach ($_POST as $key => $value) {
                $post[$key] = $value;
            }
            return $post;
        }
        return $_POST[$index];
    }

    /**
     * GET Variable
     *
     * @param string
     * @return string
     */
    public function get($index = NULL)
    {
        if ($index === NULL && !empty($_GET)) {
            $get = array();
            foreach ($_GET as $key => $value) {
                $get[$key] = $value;
            }
            return $get;
        }
        return $_GET[$index];
    }

    /**
     * Cookie Variable
     *
     * @param string $index
     * @return void
     */
    public function cookie($index = NULL)
    {
        if ($index === NULL && !empty($_COOKIE)) {
            $cookie = array();
            foreach ($_COOKIE as $key => $value) {
                $cookie[$key] = $value;
            }
            return $cookie;
        }
        return $_COOKIE[$index] ?? null;
    }

    /**
     * Set cookie in your application
     *
     * @param string $name
     * @param string $value
     * @param string $expiration
     * @param array $options
     * @return
     */
    public function set_cookie($name, $value = '', $expiration = 0, $options = array())
    {
        //list of defaults
        $lists = array('prefix', 'path', 'domain', 'secure', 'httponly', 'samesite');

        //hold options elements
        $arr = array();

        if (is_array($options)) {
            if (count($options) > 0) {
                foreach ($options as $key => $val) {
                    if (isset($options[$key]) && $options[$key] != 'expiration') {
                        $arr[$key] = $val;
                    } else {
                        $arr[$key] = config_item('cookie_' . $key);
                    }
                    $pos = array_search($key, $lists);
                    unset($lists[$pos]);
                }
            }
        }

        if (!is_numeric($expiration) || $expiration < 0) {
            $arr['expiration'] = 1;
        } else {
            $arr['expiration'] = ($expiration > 0) ? time() + $expiration : 0;
        }

        foreach ($lists as $key) {
            $arr[$key] = config_item('cookie_' . $key);
        }

        setcookie($arr['prefix'] . $name, $value,
            array(
                'expires' => $arr['expiration'],
                'path' => $arr['path'],
                'domain' => $arr['domain'],
                'secure' => (bool)$arr['secure'],
                'httponly' => (bool)$arr['httponly'],
                'samesite' => $arr['samesite']
            ));
    }

    /**
     * Is Ajax
     *
     * @return boolean Check if Request is AJAX
     */
    public function is_ajax()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';
    }
}

