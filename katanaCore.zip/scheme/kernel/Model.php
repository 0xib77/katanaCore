<?php

/**
 * Class Model
 */
class Model
{

    /**
     * Class Constructor
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * magic __get
     *
     * @param string $key
     * @return void
     */
    public function __get($key)
    {
        return katana_instance()->$key;
    }
}