<?php

/**
 * Language Class
 */
class Lang
{

    /**
     * Current Language
     *
     * @var string
     */
    public $current = '';

    /**
     * Default Language
     *
     * @var string
     */
    public $default;

    /**
     * List of Language
     *
     * @var array
     */
    public $languages = array();

    /**
     * Class Constructor
     */
    public function __construct()
    {
        /**
         * Set Default Language
         *
         * @var string
         */
        $this->default = config_item('language');
        /**
         * Set Current Language
         *
         * @var string
         */
        $this->current = $this->clientlanguage();
    }

    /**
     * Get Client Language
     *
     * @return string
     */
    public function clientlanguage()
    {
        return !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 5) : null;
    }

    /**
     * Translate String to other Language
     *
     * @param string $key
     * @param array $params
     * @return strng
     */
    public function translate($key, $params = array())
    {

        $this->lang_loaded();

        if (is_string($key) && !empty($this->languages[$this->current][$key])) {
            $text = $this->languages[$this->current][$key];

            if (!empty($params) && is_array($params)) {
                foreach ($params as $param => $replacement) {
                    $text = str_replace('{' . $param . '}', $replacement, $text);
                }
            }

            return $text;
        }

        return null;
    }

    /**
     * Load Language File
     *
     * @return array
     */
    public function lang_loaded()
    {
        if (empty($this->languages[$this->current])) {
            if (file_exists(APP_DIR . 'language/' . $this->current . '.php')) {
                $this->languages[$this->current] = require_once(APP_DIR . 'language/' . $this->current . '.php');
            } else {
                $this->languages[$this->current] = require_once(SYSTEM_DIR . 'language/' . $this->default . '.php');
            }
        }
    }

    /**
     * Change Current Language
     *
     * @param string $lang
     * @return $this
     */
    public function language($lang)
    {
        $this->current = (!empty($lang) && is_string($lang)) ? $lang : $this->clientlanguage();
        $this->lang_loaded();
    }
}
