<?php

/*

/**
 * Class Error
 */

class Errors
{
    /**
     * Show 404 Page Not Found
     *
     * @param string $heading
     * @param string $message
     * @param string $page
     * @return void
     */
    public function show_404($heading, $message, $template)
    {
        $template = !empty($template) ? $template : 'error_404';
        $heading = !empty($heading) ? $heading : 'Page Not Found';
        $message = !empty($message) ? $message : 'The page you requested was not found.';
        $this->show_error($heading, $message, $template, 404);
    }

    /**
     * Show error for debugging
     *
     * @param string $heading
     * @param string $message
     * @param string $template
     * @param integer code
     * @return void
     */
    public function show_error($heading, $message, $template, $code = 500)
    {
        $template_path = config_item('error_view_path');
        if (empty($template_path)) {
            $template_path = APP_DIR . 'views/errors' . DIRECTORY_SEPARATOR;
        }

        http_response_code($code);

        load_class('minify', 'libraries');
        $minify = new Minify(true, true);

        ob_start();
        require_once($template_path . $template . '.php');
        $page = ob_get_clean();

        echo $minify->minify_html($page);
        exit;
    }

    /**
     * Show Exception error for debugging
     *
     * @param object $exception
     * @return void
     */
    public function show_exception($exception)
    {
        $template_path = config_item('error_view_path');
        if (empty($template_path)) {
            $template_path = APP_DIR . 'views/errors' . DIRECTORY_SEPARATOR;
        }

        $message = $exception->getMessage();
        if (empty($message)) {
            $message = '(null)';
        }

        load_class('minify', 'libraries');
        $minify = new Minify(true, true);

        ob_start();
        require_once($template_path . 'error_exception.php');
        $page = ob_get_clean();

        echo $minify->minify_html($page);
        exit;
    }

    /**
     * Show PHP error for debugging
     *
     * @param string $severity
     * @param string $message
     * @param string $filepath
     * @param string $line
     * @return void
     */
    public function show_php_error($severity, $message, $filepath, $line)
    {
        $template_path = config_item('error_view_path');
        if (empty($template_path)) {
            $template_path = APP_DIR . 'views/errors' . DIRECTORY_SEPARATOR;
        }

        load_class('minify', 'libraries');
        $minify = new Minify(true, true);

        ob_start();
        require_once($template_path . 'error_php.php');
        $page = ob_get_clean();

        echo $minify->minify_html($page);
        die();
    }

}