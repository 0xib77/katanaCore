<?php


/**
 * Required to execute neccessary functions
 */
require_once SYSTEM_DIR . 'kernel/Registry.php';
require_once SYSTEM_DIR . 'kernel/Routine.php';

/**
 * Katana2077 BASE URL of your APPLICATION
 */
define('BASE_URL', config_item('base_url'));

/**
 * Composer (Autoload)
 */
if ($composer_autoload = config_item('composer_autoload')) {
    if ($composer_autoload === TRUE) {
        file_exists(APP_DIR . 'vendor/autoload.php')
            ? require(APP_DIR . 'vendor/autoload.php')
            : show_404('404 Not Found', 'Composer config file not found.');
    } elseif (file_exists($composer_autoload)) {
        require_once($composer_autoload);
    } else {
        show_404('404 Not Found', 'Composer config file not found.');
    }
}

/**
 * Instantiate the Benchmark class
 */
$performance =& load_class('performance', 'kernel');
$performance->_init('Katana2077');

/**
 * Deployment Environment
 */
$env = strtolower(config_item('ENVIRONMENT'));
switch ($env) {
    case 'maintenance':
        _handlers();
        show_error(
            'maintenance mode',
            ucwords(config_item('maintenance_message') ?? "Under Maintenance"),
            $env
        );
        break;

    case 'development':
        _handlers();
        error_reporting(-1);
        ini_set('display_errors', 1);
        break;

    case 'testing':
    case 'production':
//        error_reporting(E_ALL);
//        ini_set('display_errors', 1);
        error_reporting(0);
        ini_set('display_errors', 0);
        break;

    default :
        _handlers();
        error_reporting(-1);
        ini_set('display_errors', 1);
}

/**
 * Error Classes to show errors
 *
 * @return void
 */
function _handlers()
{
    set_error_handler('_error_handler');
    set_exception_handler('_exception_handler');
    register_shutdown_function('_shutdown_handler');
}

/**
 * Instantiate the routing class and set the routing
 */
$router =& load_class('router', 'kernel');

/**
 * Instantiate the security class for xss and csrf support
 */
$security =& load_class('security', 'kernel');

/**
 * Instantiate the Input/Ouput class
 */
$io =& load_class('io', 'kernel');

/**
 * Instantiate the Language class
 */
$lang =& load_class('lang', 'kernel');

/**
 * Load BaseController
 */
require_once SYSTEM_DIR . 'kernel/Controller.php';

/**
 * Instantiate Katana2077 Controller
 *
 * @return object
 */
function &katana_instance()
{
    return Controller::instance();
}

$performance->_init('Katana2077');

/**
 * Initiate Router
 */
$router->initiate();