<?php


/**
 * Class Registry
 */
class Registry
{
    private static $_instance;
    private $_classes = array();

    /**
     * @param string $key
     */
    static function get_object($key)
    {
        return self::instance()->get($key);
    }

    /**
     * @param string $key
     */
    protected function get($key)
    {

        if (isset($this->_classes[$key])) {
            return $this->_classes[$key];
        }
        return NULL;
    }

    /**
     * Get Instance of Registry
     */
    public static function instance()
    {
        if (!isset(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * @param string $key
     * @param object $object
     */
    static function store_object($key, $object)
    {
        return self::instance()->set($key, $object);
    }

    /**
     * @param string $key
     * @param object $object
     */
    protected function set($key, $object)
    {
        $this->_classes[$key] = $object;
    }
}