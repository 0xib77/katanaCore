<?php

/**
 * Class Loader
 */
class Loader
{
    /**
     * Hold class name
     *
     * @var mixed
     */
    private $class;
    /**
     * Hold the sub directory of the class
     *
     * @var string
     */
    private $sub_dir = '';
    /**
     * Page Container
     * @var string
     */
    private
        $page = '',
        $config = [];

    public function __construct(array $config)
    {
        $this->config = $config;
        //        $this->model('leet', 'db');
    }

    public function update_config(array $config)
    {
        $this->config = $config;
    }

    /**
     * @param mixed $class
     * @param null $object_name
     *
     * @return object
     */
    public function model($class, $object_name = NULL)
    {
        if (!class_exists('Model')) {
            require(SYSTEM_DIR . 'kernel/Model.php');
        }

        $Katana = Controller::instance();

        if (is_array($class)) {
            foreach ($class as $key => $value) {
                $this->get_sub_dir($value);
                if (!is_int($key)) {
                    $Katana->properties[$key] = &load_class($this->class, 'models' . $this->sub_dir, NULL, $key);
                } else {
                    $Katana->properties[$this->class] = &load_class($this->class, 'models' . $this->sub_dir, NULL, $this->class);
                }
            }
        } else {
            $this->get_sub_dir($class);
            if (!is_null($object_name)) {
                $Katana->properties[$object_name] = &load_class($this->class, 'models' . $this->sub_dir, NULL, $object_name);
            } else {
                $Katana->properties[$this->class] = &load_class($this->class, 'models' . $this->sub_dir);
            }
        }
    }

    /**
     * Get Subdirectories
     *
     * @return void
     */
    private function get_sub_dir($url)
    {
        if (strpos($url, '/')) {
            $model = explode('/', $url);
            $this->class = end($model);
            array_pop($model);
            $this->sub_dir = '/' . implode('/', $model);
        } else {
            $this->class = $url;
        }
    }

    /**
     * Load View File
     *
     * @param string $viewFile
     * @param array $data
     * @return void
     */
    public function view($view_file, $data = NULL, $template = false, $cache_view = false, $cache_expiry = 60, $clean = true)
    {

        // minify
        //        $this->library('minify');
        $minify = new Minify(true, true);

        // render navigation from navigation_helper
        //        $this->helper($this->config['navigation_helper']);
        $this->config = array_merge($this->config, render_navigations($view_file, $this->config, __CLASS__));

        $config = get_config();
        $env = $config['ENVIRONMENT'];
        switch (strtolower($env)) {
            case 'production':
                $cache_expiry = 120;
                break;

            default:
                $cache_expiry = 0;
                break;
        }

        $view_src = APP_DIR . 'views' . DS . $view_file . '.php';
        $view = strtolower(basename($view_src));
        $path = dirname($view_src);
        $ext = [];

        // load libs
        //        $this->library(['cache']);
        $check_cache = false;
        $au = Sessions::pull('auth_user');
        $_cache = (!is_null($au) ? $au : md5($_SERVER['HTTP_USER_AGENT']));

        if ($cache_view) {
            // try caching
            $cache = (new Cache());
            // get cache
            $check_cache = $cache->get($_cache . '_' . $view, true);
        }

        if (!$check_cache) {

            $view_name = explode(".", $view);
            $view_ext = array_pop($view_name);

            ob_start();

            if ($view_ext !== 'php') {
                if (file_exists($view_src)) {
                    require($view_src);
                } else {
                    throw new RuntimeException($view_file . ' view file did not exist.');
                }
            } else if (file_exists($view_src)) {
                require($view_src);
            } else {
                throw new RuntimeException($view_file . ' view file does not exist.');
            }

            $this->page = ob_get_clean();
            //            $this->page = $minify->minify_html(ob_get_clean());
            //            $this->page = $minify->minify_html($this->page);

            if ($template) {
                @ob_start();
                $template_ui = $path . '/templates/' . $template;
                $template_name = explode(".", basename($template_ui));
                $template_ext = array_pop($template_name);

                if ($template_ext !== 'php') {
                    if (file_exists($template_ui . '.php')) {
                        require($template_ui . '.php');
                    } else {
                        throw new RuntimeException($template_ui . ' view ui file did not exist.');
                    }
                } else if (file_exists($template_ui)) {
                    require($template_ui);
                } else {
                    throw new RuntimeException($template_ui . ' view ui file does not exist.');
                }
                $template = $minify->minify_html(ob_get_clean());
                $this->page = str_replace("{{content}}", $this->page, $template);

                if (
                    isset($this->config['page_config']) &&
                    is_array($this->config['page_config']) &&
                    count((array)$this->config['page_config']) > 0
                ) {

                    // set method js
                    //                    $this->config['page_config']['method_js'] = $view_name[0] . '.js';
                    // set current page
                    $this->config['page_config']['current_page'] = ucfirst(str_replace('_', ' ', $view_name[0]));
                    // set current method
                    //                    $this->config['page_config']['current_method'] = ucfirst($view_name[0]);

                    $parse_data = function () {
                        global $data;
                        if (is_array($data)) {
                            $data = array_merge($data, Sessions::all());
                        }
                        return array_merge((is_array($data) ? $data : []), $this->config['page_config']);
                    };
                    $page_config = $parse_data();

                    $this->init_map($page_config, $minify);

                }
            }

            if (!is_null($data)) {
                if (is_array($data)) {
                    $data = array_merge($data, Sessions::all());

                    // check for load css
                    if (
                        isset($data['load_css']['dir'], $data['load_css']['css']) &&
                        is_array($data['load_css']['css']) &&
                        is_dir(ROOT_DIR . $data['load_css']['dir'])
                    ) {
                        $load_css = "";
                        foreach (array_filter($data['load_css']['css']) as $css) {
                            if (file_exists(ROOT_DIR . $data['load_css']['dir'] . $css)) {
                                $load_css .= '<link rel="stylesheet" href="' . $data['load_css']['dir'] . $css . '">' . PHP_EOL;
                            } else if (count(explode('://', $css, 2)) >= 1) {
                                $load_css .= '<link rel="stylesheet" href="' . $css . '">' . PHP_EOL;
                            }
                        }
                        $data['load_css'] = $load_css;
                    } else {
                        $data['load_css'] = "";
                    }

                    // check for load js
                    if (
                        isset($data['load_js']['dir'], $data['load_js']['js']) &&
                        is_array($data['load_js']['js']) &&
                        is_dir(ROOT_DIR . $data['load_js']['dir'])
                    ) {
                        $load_js = "";
                        foreach (array_filter($data['load_js']['js']) as $js) {
                            if (file_exists(ROOT_DIR . $data['load_js']['dir'] . $js)) {
                                $load_js .= '<script src="' . $data['load_js']['dir'] . $js . '"></script>' . PHP_EOL;
                            } else if (count(explode('://', $js, 2)) >= 1) {
                                $load_js .= '<script src="' . $js . '"></script>' . PHP_EOL;
                            }
                        }
                        $data['load_js'] = $load_js;
                    } else {
                        $data['load_js'] = "";
                    }

                    // check if not dropdown
                    if (!isset($data['parent'])) {
                        $data['parent'] = "";
                    }

                    $this->init_map($data, $minify);

                } else {
                    throw new RuntimeException('View parameter only accepts array types');
                }
            }

            if ($cache_view) {
                // cache view
                $cache->write($this->page, $_cache . '_' . basename($view_file), $cache_expiry);
            }
        } else {
            $this->page = $check_cache;
        }

        if ($clean) {
            // remove empty extractors
            echo preg_replace_callback('#{{(.*?)}}#is', function ($matches) {
                // remove
                return '';
            }, $this->page);
            exit;
        }

        echo $this->page;
        exit;
    }

    /**
     * Load Library
     *
     * @param mixed $classes
     * @param array $params
     * @return void
     */
    public function library($classes, $params = NULL)
    {
        $Katana = Controller::instance();
        if (is_array($classes)) {
            foreach ($classes as $class) {
                $Katana->properties[$class] = &load_class($class, 'libraries');
            }
        } else {
            $Katana->properties[$classes] = &load_class($classes, 'libraries', $params);
        }
    }

    private function init_map($data, $minify = null) {

        foreach ($data as $key => $value) {
            // Check if the placeholder exists in the page content
            if (strpos($this->page, "{{{$key}}}") !== false || strpos($this->page, "{{{$key}/}}") !== false) {
                if (is_array($value)) {
                    $this->page = str_replace(["{{{$key}}}", "{{{$key}/}}"], json_encode($value), $this->page);
                } else {
                    $this->page = str_replace("{{{$key}}}", $value, $this->page);
                }
            } else if (is_array($value)) {
                $this->map_data($value, $key);
            } else {
                $this->page = str_replace("{{{$key}}}", ($value ?? ''), $this->page);
            }
        }
    }

    private function map_data($data, $parentKey = "") {
        foreach ($data as $key => $value) {
            $compositeKey = $parentKey ? "{$parentKey}/{$key}" : $key;
            if (is_array($value)) {
                $this->map_data($value, $compositeKey);
            } else {
                $this->page = str_replace("{{{$compositeKey}}}", ($value ?? ''), $this->page);
            }
        }
    }

    /**
     * Load Helper
     *
     * @param mixed $helper
     * @return void
     */
    public function helper($helper)
    {
        if (is_array($helper)) {
            foreach (array(APP_DIR . 'helpers', SYSTEM_DIR . 'helpers') as $dir) {
                foreach ($helper as $hlpr) {
                    if (file_exists($dir . DS . $hlpr . '_helper.php')) {
                        require $dir . DS . $hlpr . '_helper.php';
                    }
                }
            }
        } else {
            foreach (array(APP_DIR . 'helpers', SYSTEM_DIR . 'helpers') as $dir) {
                if (file_exists($dir . DS . $helper . '_helper.php')) {
                    require $dir . DS . $helper . '_helper.php';
                }
            }
        }
    }

    /**
     * Class Loader
     *
     * @param mixed $class
     * @return void
     */
    public function class($class, $directory)
    {
        $Katana = Controller::instance();
        if (is_array($class)) {
            foreach (array(APP_DIR . $directory, SYSTEM_DIR . $directory) as $dir) {
                foreach ($class as $cls) {
                    if (file_exists($dir . DS . $cls . '.php')) {
                        require $dir . DS . $cls . '.php';
                    }
                }
            }
        } else {
            foreach (array(APP_DIR . $directory, SYSTEM_DIR . $directory) as $dir) {
                if (file_exists($dir . DS . $class . '.php')) {
                    require $dir . DS . $class . '.php';
                }
            }
        }
    }

    /**
     * Load Database
     *
     * @param mixed $dbname
     * @return void
     */
    public function database($dbname = NULL)
    {
        $Katana = &Controller::instance();
        $database = &load_class('database', 'database', $dbname);
        if (is_null($dbname)) {
            $Katana->db = $database::instance(NULL);
        } else {
            $Katana->properties[$dbname] = $database::instance($dbname);
        }
    }
}

/**
 * Class Controller
 */
class Controller
{
    /**
     * DB Instance
     *
     * @var object
     */
    public $db = null;

    /**
     * Controller Instance
     *
     * @var object
     */
    private static $instance;

    /**
     * Load class
     *
     * @var object
     */
    public $call;

    /**
     * Page Configutaion
     * @var array
     */
    public $config = [];

    /**
     * Dynamic Properties using __set and __get
     *
     * @var array
     */
    public $properties = [];

    public
        $method,
        $require_auth = [];

    /**
     * Constructor
     */
    public function __construct($config = false)
    {

        if ($config && is_array($config) && count($config) > 0) {
            $this->config = $config;
        }

        self::$instance = &$this;

        foreach (loaded_class() as $var => $class) {
            $this->properties[$var] = &load_class($class);
        }

        /**
         * Load all Loader Class
         */
        $this->call = new Loader($this->config);

        /**
         * Autoloaded
         *
         * @return void
         */
        $autoload = &autoload_config();

        if (count($autoload['libraries']) > 0) {
            $this->call->library($autoload['libraries']);
        }
        if (count($autoload['models']) > 0) {
            $this->call->model($autoload['models']);
        }
        if (count($autoload['helpers']) > 0) {
            $this->call->helper($autoload['helpers']);
        }
    }

    public function is_authed($location = false)
    {
        if (!is_null(Sessions::pull('authenticated_user'))) {
            redirect(($location) ? $location : 'system/dashboard');
        }
    }

    public function is_admin($user_id)
    {
        $admins = config_item('DISCORD')['SERVER_ADMIN'];
        if (in_array($user_id, $admins)) {
            return true;
        }
        return false;
    }

    /**
     * Instance of controller
     *
     * @return object
     */
    public static function &instance()
    {
        return self::$instance;
    }

    /**
     * Get Dynamic Properties
     *
     * @param string $prop
     * @return void
     * @throws Exception
     */
    public function __get($prop)
    {
        if (array_key_exists($prop, $this->properties)) {
            return $this->properties[$prop];
        }

        throw new Exception("Property $prop does not exist");
    }

    /**
     * Set Dynamic Properties
     *
     * @param string $prop
     * @param string $val
     */
    public function __set($prop, $val)
    {
        $this->properties[$prop] = $val;
    }

    /**
     * set method auth
     * @param $class
     * @param $method_list
     * @return void
     */
    public function set_method_auth($class = __CLASS__, $method_list = true, $session_list = null, $auth_location = false)
    {
        $_list = [ // global functions
            '__construct',
            '__get',
            '__set',
            'out',
            'instance',
            'set_method_auth',
            'get_current_method'
        ];

        $clean_list = [];
        $disable_access = [];

        $current_method = $this->method = strtolower($this->get_current_method());

        if (is_array($method_list)) {

            $clean_list = get_class_methods($class);

            foreach ($method_list as $method) {
                $marker = substr($method, 0, 1);
                $exclude = substr($method, 1);

                switch ($marker) {
                    case '-':
                        $disable_access[] = $exclude;
                        break;

                    case '!':
                        if (class_exists($class) && method_exists($class, $exclude)) {
                            unset($clean_list[array_search($exclude, $clean_list, true)]);
                        }
                        break;
                }
            }
            // require auth for specific public method/functions
            $clean_method_list = array_filter($clean_list);
        } else {
            // require auth for all public method/functions
            // check exclude
            $marker = substr($method_list, 0, 1);
            $exclude = substr($method_list, 1);

            switch ($marker) {
                case '-':
                    $disable_access[] = $exclude;
                    break;

                case '!':
                    $clean_method_list = get_class_methods($class);
                    if (class_exists($class) && method_exists($class, $exclude)) {
                        unset($clean_method_list[array_search($exclude, $clean_method_list, true)]);
                    }
                    break;

                default:
                    $clean_method_list = get_class_methods($class);
                    break;
            }
        }

        // filter disabled access
        if (in_array($current_method, $disable_access, true)) {
            show_error('Access Denied',"Permission required to access page.",'error_restricted', 403);
        }

        foreach ($_list as $remove) {
            if (in_array($remove, $clean_method_list, true)) {
                unset($clean_method_list[array_search($remove, $clean_method_list, true)]);
            }
        }

        $clean_method_list = array_values($clean_method_list);

//        $this->out([
//            $class => $clean_method_list
//        ]);

        if (!class_exists('Sessions')) {
            load_class('sessions', 'libraries');
        }

        $session_list = is_array($session_list) ? array_filter($session_list) : array_filter([$session_list]);

        if (in_array($current_method, $clean_method_list, true) && count($session_list) > 0) {
            foreach ($session_list as $session_check) {
                if (is_null(Sessions::pull($session_check))) {
                    Sessions::push([$session_check => null]);
                    if ($auth_location) {
                        //                        Sessions::clear();
                        $current_url = $_SERVER['REQUEST_URI'];
                        Sessions::push(['next_url' => $current_url]);

                        switch ($auth_location) {
                            case 403:
                                switch (strtolower($_SERVER['REQUEST_METHOD'])) {
                                    case 'patch':
                                    case 'put':
                                    case 'post':
                                        $this->out(ucfirst('access denied, You must be logged-in to process this request'), true, 403, true);
                                        break;

                                    default:
                                        show_error('Access Denied','You must be logged-in to access this page','error_404', 403);
                                        break;
                                }
                                break;

                            default:

                                header("Location: {$auth_location}");
                                exit;
                                break;
                        }
                    } else {
                        $this->out('access denied', true, 403);
                    }
                }
            }
        }

        $this->require_auth = $clean_method_list;
    }

    /**
     * get current method from url
     * @return string
     */
    public function get_current_method($request_url = false)
    {

        if ($request_url) {
            return $_SERVER['REQUEST_URI'];
        }

        $method = array_values(array_filter(explode('/', strtok($_SERVER['REQUEST_URI'], '?'))));
        $method = (count($method) >= 2 ? $method[1] : (count($method) <= 0 ? '' : $method[0]));
        $method = str_replace(".", "", $method); // anti-dot (.) bypass
        return ucfirst($method);
    }

    public function read($file, $dir)
    {
        $f = $dir . $file . '.php';
        if (file_exists($f)) {
            return file_get_contents($f);
        }

        return false;
    }

    public function out($data, $error = false, $code = 0, $pretty = false, $header=false)
    {
        if ($code !== 0) {
            http_response_code($code);
        }

        $is_error = function ($data) use ($error, $code) {
            if ($error) {
                $err_data = [
                    'error' => [
                        'code' => $code,
                        'message' => null
                    ]
                ];
                if (is_array($data)) {
                    if (isset($data['message'])) {
                        $err_data['error']['message'] = $data['message'];
                        foreach ($data as $key => $val) {
                            if ($key === 'message') {
                                continue;
                            }
                            $err_data['error'][$key] = $val;
                        }
                    } else {
                        foreach ($data as $key => $val) {
                            $err_data['error'][$key] = $val;
                        }
                    }
                } else {
                    $err_data['error']['message'] = $data;
                }
                return $err_data;
            }

            return $data;
        };

        $output = "";
        $data = $is_error($data);

        if (is_array($data)) {
            if ($pretty) {
                $output = json_encode($data, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT);
            } else {
                $output = json_encode($data, JSON_THROW_ON_ERROR);
            }
            // set header
            header('Content-Type: application/json');
        } else {
            if (!$header) {
                header('Content-Type: text/plain');
            } else {
                header($header);
            }

            $output = $data;
        }

        echo $output;
        exit;
    }
}
