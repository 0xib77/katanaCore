<?php

if (!function_exists('accept_cookie')) {
    /**
     * accept cookie from headers
     *
     * @param string $name the cookie name
     */
    function accept_cookie($name)
    {
        $headerCookies = explode('; ', getallheaders()['Cookie']);
        $cookies = [];
        foreach ($headerCookies as $cookie) {
            list($key, $val) = explode('=', $cookie, 2);
            $cookies[$key] = urldecode($val);
        }

        return $cookies[$name] ?? null;
    }
}

if (!function_exists('set_cookie')) {
    /**
     * Setting up cookie in your application
     *
     * @param string $name the cookie name
     * @param string $value the cookie value
     * @param array $options other cookie options
     * @return void
     */
    function set_cookie($name, $value = '', $expiration = 0, $options = array())
    {
        katana_instance()->io->set_cookie($name, $value, $expiration, $options);
    }
}

if (!function_exists('get_cookie')) {
    /**
     * Fetch an item from the COOKIE array
     *
     * @param string $name name of the cookie
     * @return mixed
     */
    function get_cookie($name)
    {
        $prefix = isset($_COOKIE[$name]) ? '' : config_item('cookie_prefix');
        return katana_instance()->io->cookie($prefix . $name);
    }
}

if (!function_exists('delete_cookie')) {
    /**
     * Delete a cookie
     *
     * @param string $name
     * @param string $domain the cookie domain
     * @param string $path the cookie path
     * @param string $prefix the cookie prefix
     * @return void
     */
    function delete_cookie($name, $domain = '', $path = '/', $prefix = '')
    {
        katana_instance()->io->set_cookie($name, '', '', array('domain' => $domain, 'path' => $path, 'prefix' => $prefix));
    }
}