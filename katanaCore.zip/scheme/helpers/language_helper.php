<?php


if (!function_exists('lang')) {
    /**
     * Use to translate text on you app in different languages
     *
     * @param string $key
     * @param array $params
     * @param boolean $escape
     * @return void
     */
    function lang($key, $params = array(), $escape = FALSE)
    {
        $translated = katana_instance()->lang->translate($key, $params);

        if ($escape == TRUE)
            return html_escape($translated);
        else
            return $translated;
    }
}

if (!function_exists('language')) {
    /**
     * Use to select the Language to use
     *
     * @param string $lang
     * @return $this
     */
    function language($lang)
    {
        return katana_instance()->lang->language($lang);
    }
}
