<?php


if (!function_exists('write_file')) {
    /**
     * Undocumented function
     *
     * @param string $file
     * @param string $content
     * @param string $mode
     * @return void
     */
    function write_file($file, $content, $mode = 'w')
    {
        $fp = fopen($file, $mode);

        if (flock($fp, LOCK_EX)) {
            $result = fwrite($fp, $content);

            flock($fp, LOCK_UN);
            fclose($fp);

            return $result;
        }
    }
}

if (!function_exists('delete_files')) {
    /**
     * Delete Directory and Files
     *
     * @param string $dir_path
     * @param boolean $htdocs
     * @return void
     */
    function delete_files($dir_path, $del_dir = FALSE, $htdocs = FALSE)
    {
        if (!empty($dir_path) && is_dir($dir_path)) {
            $objects = scandir($dir_path);
            foreach ($objects as $object) {
                if ($object != '.' && $object != '..') {
                    if (filetype($dir_path . DIRECTORY_SEPARATOR . $object) == 'dir') {
                        delete_files($dir_path . DIRECTORY_SEPARATOR . $object, $htdocs);
                    } else if ($htdocs !== TRUE or !preg_match('/^(\.htaccess|index\.(html|htm|php)|web\.config)$/i', $object)) {
                        unlink($dir_path . DIRECTORY_SEPARATOR . $object);
                    }
                }
            }
            reset($objects);
            return ($del_dir) ?? rmdir($dir_path);
        }
    }
}

if (!function_exists('copy_file')) {
    /**
     * Copy or Move file to a new direcotry
     *
     * @param string $path
     * @param string $copy_path
     * @param boolean $remove_original
     * @return void
     */
    function copy_file($path, $copy_path, $remove_original = FALSE)
    {
        return $remove_original ? rename($path, $copy_path) : copy($path, $copy_path);
    }
}