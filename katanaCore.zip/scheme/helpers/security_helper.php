<?php


if (!function_exists('filter_io')) {
    /**
     * Filter variables
     *
     * @param string $type can be string, integer, etc...
     * @param string $var the data to be filtered
     * @return void
     */
    function filter_io($type, $var)
    {
        switch (strtolower($type)) {
            case 'string':
                return filter_var($var, FILTER_UNSAFE_RAW);
                break;
            case 'int':
            case 'integer':
                return filter_var($var, FILTER_SANITIZE_NUMBER_INT);
                break;
            case 'float':
                return filter_var($var, FILTER_SANITIZE_NUMBER_FLOAT);
                break;
            case 'url':
                return filter_var($var, FILTER_SANITIZE_URL);
                break;
            case 'email':
                return filter_var($var, FILTER_SANITIZE_EMAIL);
                break;
            default:
                return filter_var($var, FILTER_UNSAFE_RAW);
        }
    }
}

if (!function_exists('sanitize_filename')) {
    /**
     * Sanitize Filename
     *
     * @param string
     * @return    string
     */
    function sanitize_filename($filename)
    {
        return katana_instance()->security->sanitize_filename($filename);
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field()
    {
        /**
         * Katana2077 Super Object
         */
        $Katana =& katana_instance();

        if (FALSE !== ($noise = random_bytes(1))) {
            list(, $noise) = unpack('c', $noise);
        } else {
            $noise = mt_rand(-128, 127);
        }

        $prepend = $append = '';
        if ($noise < 0) {
            $prepend = str_repeat(" ", abs($noise));
        } elseif ($noise > 0) {
            $append = str_repeat(" ", $noise);
        }

        $form = sprintf(
            '%s<input type="hidden" name="%s" value="%s" />%s%s',
            $prepend,
            $Katana->security->get_csrf_token_name(),
            $Katana->security->get_csrf_hash(),
            $append,
            "\n"
        );
        return $form;
    }
}